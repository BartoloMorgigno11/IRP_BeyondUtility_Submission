"""Full corrected matched recovery for RQ5 utility.

This script materializes the 4,000-request corrected RQ5 universe, reuses only
terminal evidence that is exact under the frozen pilot-v2 contract, executes the
remaining local Ollama requests without retries or repair, and derives the final
matched HR@5/NDCG@5 deltas and figures.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from collections import Counter
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.analysis import reproduction_r5c_history_length_recovery as r5c  # noqa: E402
from src.analysis.rq5_corrected_matched_recovery import (  # noqa: E402
    DENOMINATOR_POLICY,
    PARSER_CONTRACT,
    PROMPT_TEMPLATE_ID,
    PROTECTED_GIT_PATHS,
    RQ5CorrectedRecoveryError,
    bool_text,
    build_profile_reuse_audit,
    candidate_signature,
    candidate_titles_from_request,
    extract_history_context,
    hr_at_5,
    load_f6l_manifest,
    load_f6l_parse,
    ndcg_at_5,
    normalize_rel,
    parse_bool,
    parse_corrected_response,
    profile_record,
    profile_text_from_raw,
    project_path,
    prompt_discloses_positive,
    protected_git_diff,
    raw_for_parse_row,
    raw_rel_for_request,
    raw_response_text,
    read_source_csv,
    read_source_json,
    render_corrected_prompt,
    resolve_source,
    sha256_file,
    sha256_text,
    sorted_users,
    stable_json,
    validity_class_from_status,
    write_csv,
    write_json,
)


PHASE_ID = "RQ5_CORRECTED_MATCHED_RECOVERY_FULL"
DEFAULT_CONFIG_PATH = Path("configs") / "rq5_corrected_matched_full_recovery.yaml"
VERDICT_READY = "RQ5_CORRECTED_MATCHED_RECOVERY_FINAL"
VERDICT_BACKEND = "RQ5_CORRECTED_MATCHED_RECOVERY_BLOCKED_BACKEND_UNAVAILABLE"
VERDICT_MATCHING = "RQ5_CORRECTED_MATCHED_RECOVERY_BLOCKED_MATCHING"
VERDICT_CONTRACT = "RQ5_CORRECTED_MATCHED_RECOVERY_BLOCKED_OUTPUT_CONTRACT"
VERDICT_VALIDITY = "RQ5_CORRECTED_MATCHED_RECOVERY_BLOCKED_VALIDITY"
VERDICT_COLLAPSE = "RQ5_CORRECTED_MATCHED_RECOVERY_BLOCKED_SUSPICIOUS_METRIC_COLLAPSE"

REUSE_PILOT = "REUSE_CORRECTED_PILOT_V2"
REUSE_G1 = "REUSE_G1_EXACT"
REUSE_G2 = "REUSE_G2_EXACT"
NEW_INFERENCE = "NEW_INFERENCE"
NOT_EXACT = "NOT_EXACTLY_REUSABLE"

DATASET_LABELS = {"beauty": "Beauty", "sports": "Sports"}
MODEL_LABELS = {"qwen2:7b-instruct": "Qwen2", "mistral:7b-instruct": "Mistral"}
MODEL_COLORS = {"qwen2:7b-instruct": "#1f77b4", "mistral:7b-instruct": "#d95f02"}
PROFILE_MARKERS = {"qwen2:7b-instruct": "s", "mistral:7b-instruct": "o"}
PROFILE_LINESTYLES = {"qwen2:7b-instruct": "--", "mistral:7b-instruct": "-"}
CONDITION_LABELS = {
    "history_only": "History",
    "profile_only": "Profile",
    "profile_plus_history": "History + Profile",
}
CONDITION_ORDER = {"history_only": 0, "profile_only": 1, "profile_plus_history": 2}
METRIC_LABELS = {"hr_at_5": "HR@5", "ndcg_at_5": "NDCG@5"}
DELTA_SPECS = [
    ("profile_only_vs_history_only", "PROFILE_MINUS_HISTORY", "profile_only", "Profile - History"),
    (
        "profile_plus_history_vs_history_only",
        "PROFILE_HISTORY_MINUS_HISTORY",
        "profile_plus_history",
        "History+Profile - History",
    ),
]


def load_config(path: Path | None = None) -> dict[str, Any]:
    config_path = path or DEFAULT_CONFIG_PATH
    with config_path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


def repository_root_from_arg(value: str | None, config: Mapping[str, Any]) -> Path:
    root = Path(value or str(config.get("project_root", "."))).resolve()
    if not (root / "src" / "analysis").exists():
        raise FileNotFoundError(f"Not a project root: {root}")
    return root


def output_path(root: Path, config: Mapping[str, Any], key: str) -> Path:
    return project_path(root, (config.get("outputs") or {})[key])


def parsed_source_row(
    parse: pd.DataFrame,
    *,
    dataset: str,
    user_id: str,
    recommender: str,
    condition: str,
    profile_generator: str = "",
) -> pd.Series:
    filters = {
        "dataset": dataset,
        "user_id": user_id,
        "recommender_model_name": recommender,
        "input_variant": condition,
    }
    filters["profile_generator_name"] = "" if condition == "history_only" else profile_generator
    mask = pd.Series([True] * len(parse), index=parse.index)
    for column, value in filters.items():
        mask &= parse[column].eq(str(value))
    subset = parse.loc[mask]
    if len(subset) != 1:
        raise RQ5CorrectedRecoveryError(f"Expected one F6L parse row for {filters}, found {len(subset)}")
    return subset.iloc[0]


def full_request_row(
    *,
    sequence: int,
    condition: str,
    source_row: Mapping[str, Any],
    recommender: str,
    profile_generator: str,
    profile_request_id: str,
    profile_hash: str,
    profile_text: str,
    candidate_ids: Sequence[str],
    candidate_titles: Sequence[str],
    prompt_render: str,
    history_context_hash: str,
    source_scope: str,
    output_namespace: Path,
) -> dict[str, Any]:
    positive_item_id = str(source_row["positive_item_id"])
    positive_position = str(source_row["positive_candidate_position"])
    return {
        "request_id": f"PENDING-FULL-{sequence:04d}",
        "sequence": sequence,
        "phase": PHASE_ID,
        "f6l_request_id": str(source_row["request_id"]),
        "dataset": str(source_row["dataset"]),
        "user_id": str(source_row["user_id"]),
        "model_name": recommender,
        "recommender_model_name": recommender,
        "profile_generator_name": profile_generator,
        "condition": condition,
        "input_variant": condition,
        "profile_request_id": profile_request_id,
        "profile_hash": profile_hash,
        "candidate_list_hash": str(source_row["candidate_list_hash"]),
        "candidate_item_ids_json": stable_json([str(item) for item in candidate_ids]),
        "candidate_item_titles_json": stable_json([str(item) for item in candidate_titles]),
        "candidate_count": len(candidate_ids),
        "positive_item_id": positive_item_id,
        "positive_candidate_position": positive_position,
        "prompt_template_id": PROMPT_TEMPLATE_ID,
        "parser_contract": PARSER_CONTRACT,
        "expected_output_schema": stable_json({"ranked_candidate_indices": list(range(1, 11))}),
        "expected_output_count": 10,
        "candidate_index_base": 1,
        "temperature": 0,
        "seed": 0,
        "max_new_tokens": 256,
        "prompt_render": prompt_render,
        "prompt_hash": sha256_text(prompt_render),
        "positive_label_hidden": bool_text(not prompt_discloses_positive(prompt_render, positive_item_id, positive_position)),
        "history_context_hash": history_context_hash,
        "profile_char_count": len(profile_text),
        "source_file": str(source_row["source_file"]),
        "source_scope": source_scope,
        "output_destination": normalize_rel(output_namespace / f"PENDING-FULL-{sequence:04d}.json"),
        "metric_denominator_policy": DENOMINATOR_POLICY,
    }


def build_full_request_universe(
    root: Path,
    config: Mapping[str, Any],
    parse: pd.DataFrame,
    profile_audit: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, list[str]]]:
    scope = config.get("scope") or {}
    outputs = config.get("outputs") or {}
    datasets = [str(value) for value in scope.get("datasets", [])]
    recommenders = [str(value) for value in scope.get("recommenders", [])]
    profile_generators = [str(value) for value in scope.get("profile_generators", [])]
    n_users = int(scope.get("full_users_per_dataset", 200))
    expected_count = int(scope.get("expected_output_count", 10))
    candidate_count = int(scope.get("candidate_count", 20))
    raw_namespace = Path(str(outputs["raw_namespace"]))

    reusable_users: dict[str, set[str]] = {}
    for dataset in datasets:
        sets = []
        for generator in profile_generators:
            subset = profile_audit[
                profile_audit["dataset"].eq(dataset)
                & profile_audit["profile_generator"].eq(generator)
                & profile_audit["status"].eq("REUSABLE")
            ]
            sets.append(set(subset["user_id"].astype(str)))
        reusable_users[dataset] = set.intersection(*sets) if sets else set()

    selected_users: dict[str, list[str]] = {}
    matching_rows: list[dict[str, Any]] = []
    request_rows: list[dict[str, Any]] = []
    sequence = 1

    for dataset in datasets:
        chosen: list[str] = []
        for user_id in sorted_users(reusable_users.get(dataset, set())):
            user_match_records: list[dict[str, Any]] = []
            try:
                for recommender in recommenders:
                    history_row = parsed_source_row(
                        parse,
                        dataset=dataset,
                        user_id=user_id,
                        recommender=recommender,
                        condition="history_only",
                    )
                    history_payload, _history_source = raw_for_parse_row(root, history_row)
                    history_context = extract_history_context(str(history_payload.get("rendered_prompt", "")))
                    history_ids, history_titles = candidate_signature(history_payload)
                    if len(history_ids) != candidate_count or len(history_titles) != candidate_count:
                        raise RQ5CorrectedRecoveryError("history candidate list is not length 20")
                    for generator in profile_generators:
                        prof = profile_record(
                            profile_audit,
                            dataset=dataset,
                            user_id=user_id,
                            profile_generator=generator,
                        )
                        profile_payload, _ = read_source_json(root, raw_rel_for_request(str(prof["profile_request_id"])))
                        profile_text = profile_text_from_raw(profile_payload)
                        if not profile_text:
                            raise RQ5CorrectedRecoveryError("empty profile text")
                        for condition in ["profile_only", "profile_plus_history"]:
                            condition_row = parsed_source_row(
                                parse,
                                dataset=dataset,
                                user_id=user_id,
                                recommender=recommender,
                                condition=condition,
                                profile_generator=generator,
                            )
                            condition_payload, _ = raw_for_parse_row(root, condition_row)
                            condition_ids, condition_titles = candidate_signature(condition_payload)
                            hashes_match = str(condition_row["candidate_list_hash"]) == str(history_row["candidate_list_hash"])
                            positives_match = (
                                str(condition_row["positive_item_id"]) == str(history_row["positive_item_id"])
                                and str(condition_row["positive_candidate_position"])
                                == str(history_row["positive_candidate_position"])
                            )
                            candidates_match = condition_ids == history_ids and condition_titles == history_titles
                            dependency_match = str(condition_row["dependency_request_id"]) == str(prof["profile_request_id"])
                            user_match_records.append(
                                {
                                    "dataset": dataset,
                                    "user_id": user_id,
                                    "recommender": recommender,
                                    "profile_generator": generator,
                                    "condition": condition,
                                    "history_request_id": str(history_row["request_id"]),
                                    "condition_request_id": str(condition_row["request_id"]),
                                    "profile_request_id": str(prof["profile_request_id"]),
                                    "candidate_list_hash": str(history_row["candidate_list_hash"]),
                                    "same_candidate_list_hash": bool_text(hashes_match),
                                    "same_candidate_order": bool_text(candidates_match),
                                    "same_positive_item": bool_text(positives_match),
                                    "same_positive_candidate_position": bool_text(
                                        str(condition_row["positive_candidate_position"])
                                        == str(history_row["positive_candidate_position"])
                                    ),
                                    "dependency_matches_profile": bool_text(dependency_match),
                                    "history_context_hash": sha256_text(history_context),
                                    "profile_hash": str(prof["profile_hash"]),
                                    "matching_status": "PASS"
                                    if hashes_match and positives_match and candidates_match and dependency_match
                                    else "FAIL",
                                    "details": "",
                                }
                            )
                if all(row["matching_status"] == "PASS" for row in user_match_records):
                    chosen.append(user_id)
                    matching_rows.extend(user_match_records)
            except Exception as exc:
                matching_rows.append(
                    {
                        "dataset": dataset,
                        "user_id": user_id,
                        "recommender": "",
                        "profile_generator": "",
                        "condition": "",
                        "history_request_id": "",
                        "condition_request_id": "",
                        "profile_request_id": "",
                        "candidate_list_hash": "",
                        "same_candidate_list_hash": "false",
                        "same_candidate_order": "false",
                        "same_positive_item": "false",
                        "same_positive_candidate_position": "false",
                        "dependency_matches_profile": "false",
                        "history_context_hash": "",
                        "profile_hash": "",
                        "matching_status": "FAIL",
                        "details": str(exc),
                    }
                )
            if len(chosen) == n_users:
                break
        selected_users[dataset] = chosen

        for user_id in chosen:
            for recommender in recommenders:
                history_row = parsed_source_row(
                    parse,
                    dataset=dataset,
                    user_id=user_id,
                    recommender=recommender,
                    condition="history_only",
                )
                history_payload, history_source = raw_for_parse_row(root, history_row)
                history_context = extract_history_context(str(history_payload.get("rendered_prompt", "")))
                history_ids, history_titles = candidate_signature(history_payload)
                history_prompt = render_corrected_prompt(
                    condition="history_only",
                    history_context=history_context,
                    profile_text="",
                    candidate_titles=history_titles,
                    expected_count=expected_count,
                    candidate_count=candidate_count,
                )
                request_rows.append(
                    full_request_row(
                        sequence=sequence,
                        condition="history_only",
                        source_row=history_row,
                        recommender=recommender,
                        profile_generator="none",
                        profile_request_id="",
                        profile_hash="",
                        profile_text="",
                        candidate_ids=history_ids,
                        candidate_titles=history_titles,
                        prompt_render=history_prompt,
                        history_context_hash=sha256_text(history_context),
                        source_scope=history_source.scope,
                        output_namespace=raw_namespace,
                    )
                )
                sequence += 1
                for generator in profile_generators:
                    prof = profile_record(profile_audit, dataset=dataset, user_id=user_id, profile_generator=generator)
                    profile_payload, _ = read_source_json(root, raw_rel_for_request(str(prof["profile_request_id"])))
                    profile_text = profile_text_from_raw(profile_payload)
                    for condition in ["profile_only", "profile_plus_history"]:
                        condition_row = parsed_source_row(
                            parse,
                            dataset=dataset,
                            user_id=user_id,
                            recommender=recommender,
                            condition=condition,
                            profile_generator=generator,
                        )
                        condition_payload, condition_source = raw_for_parse_row(root, condition_row)
                        condition_ids, condition_titles = candidate_signature(condition_payload)
                        prompt = render_corrected_prompt(
                            condition=condition,
                            history_context=history_context,
                            profile_text=profile_text,
                            candidate_titles=condition_titles,
                            expected_count=expected_count,
                            candidate_count=candidate_count,
                        )
                        request_rows.append(
                            full_request_row(
                                sequence=sequence,
                                condition=condition,
                                source_row=condition_row,
                                recommender=recommender,
                                profile_generator=generator,
                                profile_request_id=str(prof["profile_request_id"]),
                                profile_hash=str(prof["profile_hash"]),
                                profile_text=profile_text,
                                candidate_ids=condition_ids,
                                candidate_titles=condition_titles,
                                prompt_render=prompt,
                                history_context_hash=sha256_text(history_context),
                                source_scope=condition_source.scope,
                                output_namespace=raw_namespace,
                            )
                        )
                        sequence += 1

    requests = pd.DataFrame(request_rows)
    if not requests.empty:
        requests = requests.sort_values(
            ["dataset", "user_id", "recommender_model_name", "profile_generator_name", "condition"],
            kind="mergesort",
        ).reset_index(drop=True)
        requests["request_id"] = [f"RQ5CMR-FULL-REQ-{index:04d}" for index in range(1, len(requests) + 1)]
        requests["output_destination"] = requests["request_id"].map(
            lambda request_id: normalize_rel(raw_namespace / f"{request_id}.json")
        )
        requests["logical_key_sha256"] = requests.apply(
            lambda row: sha256_text(
                stable_json(
                    {
                        "dataset": row["dataset"],
                        "user_id": row["user_id"],
                        "recommender": row["recommender_model_name"],
                        "profile_generator": row["profile_generator_name"],
                        "condition": row["condition"],
                        "candidate_list_hash": row["candidate_list_hash"],
                        "positive_item_id": row["positive_item_id"],
                        "positive_candidate_position": row["positive_candidate_position"],
                        "prompt_hash": row["prompt_hash"],
                        "parser_contract": row["parser_contract"],
                    }
                )
            ),
            axis=1,
        )
    return requests, pd.DataFrame(matching_rows), selected_users


def pilot_manifest_records(root: Path, config: Mapping[str, Any]) -> dict[tuple[str, ...], dict[str, Any]]:
    source = (config.get("source_authority") or {}).get(
        "corrected_pilot_v2_manifest", "results/manifests/rq5_corrected_matched_recovery_pilot_v2.json"
    )
    payload, _source = read_source_json(root, source)
    records = payload.get("pilot_requests", [])
    if not isinstance(records, list):
        return {}
    by_key: dict[tuple[str, ...], dict[str, Any]] = {}
    for record in records:
        if not isinstance(record, Mapping):
            continue
        key = (
            str(record.get("dataset", "")),
            str(record.get("user_id", "")),
            str(record.get("recommender", "")),
            str(record.get("profile_generator", "")),
            str(record.get("condition", "")),
            str(record.get("f6l_request_id", "")),
            str(record.get("candidate_list_hash", "")),
            str(record.get("positive_item_id", "")),
            str(record.get("positive_candidate_position", "")),
            str(record.get("prompt_hash", "")),
        )
        by_key[key] = dict(record)
    return by_key


def request_exact_key(row: Mapping[str, Any]) -> tuple[str, ...]:
    return (
        str(row.get("dataset", "")),
        str(row.get("user_id", "")),
        str(row.get("recommender_model_name", row.get("model_name", ""))),
        str(row.get("profile_generator_name", "")),
        str(row.get("condition", "")),
        str(row.get("f6l_request_id", "")),
        str(row.get("candidate_list_hash", "")),
        str(row.get("positive_item_id", "")),
        str(row.get("positive_candidate_position", "")),
        str(row.get("prompt_hash", "")),
    )


def build_reuse_audit(root: Path, config: Mapping[str, Any], requests: pd.DataFrame) -> pd.DataFrame:
    pilot_records = pilot_manifest_records(root, config)
    rows: list[dict[str, Any]] = []
    for record in requests.to_dict("records"):
        pilot = pilot_records.get(request_exact_key(record))
        pilot_exact = False
        pilot_request_id = ""
        pilot_source_file = ""
        pilot_parse_valid = False
        if pilot:
            pilot_request_id = str(pilot.get("request_id", ""))
            pilot_source_file = str(pilot.get("output_destination", ""))
            path = project_path(root, pilot_source_file)
            if path.exists():
                payload = json.loads(path.read_text(encoding="utf-8"))
                parse_record = payload.get("parse") if isinstance(payload.get("parse"), Mapping) else {}
                pilot_parse_valid = parse_bool(parse_record.get("parse_valid", False))
                pilot_exact = (
                    str(payload.get("candidate_list_hash", "")) == str(record["candidate_list_hash"])
                    and str(payload.get("positive_item_id", "")) == str(record["positive_item_id"])
                    and str(payload.get("positive_candidate_position", "")) == str(record["positive_candidate_position"])
                    and str(payload.get("prompt_hash", "")) == str(record["prompt_hash"])
                    and str(payload.get("prompt_template_id", "")) == PROMPT_TEMPLATE_ID
                    and str(payload.get("parser_contract", "")) == PARSER_CONTRACT
                    and pilot_parse_valid
                )
        final_class = REUSE_PILOT if pilot_exact else NEW_INFERENCE
        rows.append(
            {
                "request_id": str(record["request_id"]),
                "dataset": str(record["dataset"]),
                "user_id": str(record["user_id"]),
                "recommender": str(record["recommender_model_name"]),
                "condition": str(record["condition"]),
                "profile_generator": str(record["profile_generator_name"]),
                "f6l_request_id": str(record["f6l_request_id"]),
                "candidate_list_hash": str(record["candidate_list_hash"]),
                "positive_item_id": str(record["positive_item_id"]),
                "positive_candidate_position": str(record["positive_candidate_position"]),
                "prompt_hash": str(record["prompt_hash"]),
                "final_reuse_class": final_class,
                "pilot_v2_candidate_request_id": pilot_request_id,
                "pilot_v2_exact_reusable": bool_text(pilot_exact),
                "pilot_v2_parse_valid": bool_text(pilot_parse_valid),
                "pilot_v2_source_file": pilot_source_file,
                "g1_candidate_status": NOT_EXACT,
                "g1_blocking_reason": (
                    "G1 prompt/runtime evidence is not materially identical to the corrected RQ5 v2 "
                    "profile-aware prompt/output contract for this logical request."
                ),
                "g2_candidate_status": NOT_EXACT,
                "g2_blocking_reason": (
                    "G2 history-length evidence uses a different history-length/prompt protocol and is not "
                    "the corrected RQ5 v2 profile-aware request."
                ),
                "new_inference_required": bool_text(final_class == NEW_INFERENCE),
            }
        )
    return pd.DataFrame(rows)


def build_backend_runtime(root: Path, config: Mapping[str, Any], *, run_preflight: bool) -> tuple[pd.DataFrame, bool, str]:
    scope = config.get("scope") or {}
    models = [str(value) for value in scope.get("recommenders", [])]
    if not run_preflight:
        return pd.DataFrame(
            [
                {
                    "model": model,
                    "backend_available": "false",
                    "model_available": "false",
                    "model_digest": "",
                    "ollama_version": "",
                    "preflight_run": "false",
                    "runtime_error": "preflight_not_requested",
                }
                for model in models
            ]
        ), False, "preflight_not_requested"
    available, error, tags = r5c.validate_runtime_available(config, models)
    version = r5c.ollama_version(config) if available else ""
    rows = []
    for model in models:
        details = tags.get(model, {})
        rows.append(
            {
                "model": model,
                "backend_available": bool_text(available),
                "model_available": bool_text(model in tags),
                "model_digest": str(details.get("digest", "")),
                "model_modified_at": str(details.get("modified_at", "")),
                "ollama_version": version,
                "preflight_run": "true",
                "runtime_error": error,
                "tags_endpoint": str((config.get("runtime") or {}).get("tags_endpoint", "")),
            }
        )
    return pd.DataFrame(rows), available, error


def build_canonical_contract_audit() -> pd.DataFrame:
    sample_row = {
        "candidate_item_ids_json": stable_json([f"item-{index}" for index in range(1, 21)]),
        "expected_output_count": 10,
        "positive_item_id": "item-3",
    }
    valid = parse_corrected_response(sample_row, '{"ranked_candidate_indices":[2,3,1,4,5,6,7,8,9,10]}')
    duplicate = parse_corrected_response(sample_row, '{"ranked_candidate_indices":[1,2,2,4,5,6,7,8,9,10]}')
    return pd.DataFrame(
        [
            {
                "check_id": "CANONICAL-STRICT-INDEX-PARSER",
                "status": "PASS" if valid["parse_valid"] and valid["positive_rank"] == 2 else "FAIL",
                "observed": stable_json(
                    {
                        "parser_contract": PARSER_CONTRACT,
                        "parse_valid": valid["parse_valid"],
                        "positive_rank": valid["positive_rank"],
                    }
                ),
                "details": "RQ5 corrected parser delegates to canonical strict indexed JSON parser.",
            },
            {
                "check_id": "NO-AUTO-REPAIR-DUPLICATES",
                "status": "PASS" if (not duplicate["parse_valid"] and duplicate["parse_status"] == "duplicate_indices") else "FAIL",
                "observed": stable_json(
                    {
                        "parse_valid": duplicate["parse_valid"],
                        "parse_status": duplicate["parse_status"],
                        "hr_at_5": duplicate["hr_at_5"],
                        "ndcg_at_5": duplicate["ndcg_at_5"],
                    }
                ),
                "details": "Duplicate candidate indices remain invalid and contribute zero.",
            },
            {
                "check_id": "FROZEN-V2-PROMPT-CONTRACT",
                "status": "PASS",
                "observed": PROMPT_TEMPLATE_ID,
                "details": "Full run uses the hardened pilot-v2 prompt/output behavior without refactoring the scientific contract.",
            },
        ]
    )


def build_full_raw_payload(
    row: Mapping[str, Any],
    *,
    execution_status: str,
    response_text: str,
    parse_record: Mapping[str, Any],
    raw_response: Mapping[str, Any],
    error: str,
    latency_seconds: float,
    runtime_model_id: str,
    done_reason: str,
    reuse_class: str,
    reuse_source_file: str = "",
    reuse_source_request_id: str = "",
) -> dict[str, Any]:
    return {
        "phase": PHASE_ID,
        "request_id": str(row["request_id"]),
        "f6l_request_id": str(row["f6l_request_id"]),
        "dataset": str(row["dataset"]),
        "user_id": str(row["user_id"]),
        "model_name": str(row["model_name"]),
        "profile_generator_name": str(row["profile_generator_name"]),
        "condition": str(row["condition"]),
        "execution_status": execution_status,
        "backend_complete": bool_text(execution_status == "SUCCEEDED"),
        "response_text": response_text,
        "parse": dict(parse_record),
        "candidate_item_ids": json.loads(str(row["candidate_item_ids_json"])),
        "candidate_item_titles": json.loads(str(row["candidate_item_titles_json"])),
        "candidate_list_hash": str(row["candidate_list_hash"]),
        "positive_item_id": str(row["positive_item_id"]),
        "positive_candidate_position": str(row["positive_candidate_position"]),
        "prompt_template_id": PROMPT_TEMPLATE_ID,
        "parser_contract": PARSER_CONTRACT,
        "prompt_hash": str(row["prompt_hash"]),
        "prompt_render": str(row["prompt_render"]),
        "metric_denominator_policy": DENOMINATOR_POLICY,
        "reuse_class": reuse_class,
        "reuse_source_file": reuse_source_file,
        "reuse_source_request_id": reuse_source_request_id,
        "runtime_backend": "local_ollama",
        "runtime_model_id": runtime_model_id,
        "ollama_done_reason": done_reason,
        "ollama_raw_response": dict(raw_response),
        "error": error,
        "latency_seconds": latency_seconds,
    }


def backend_failed_payload(row: Mapping[str, Any], error: str) -> dict[str, Any]:
    parse_record = {
        "parse_valid": False,
        "parse_status": "backend_failed",
        "parse_error": error,
        "validity_class": "BACKEND_FAILED",
        "ranked_candidate_indices": [],
        "ranked_item_ids": [],
        "duplicate_count": 0,
        "unknown_item_count": 0,
        "output_length": 0,
        "expected_output_count": int(row.get("expected_output_count", 10) or 10),
        "positive_rank": 0,
        "hr_at_5": 0.0,
        "ndcg_at_5": 0.0,
        "metric_ready": False,
    }
    return build_full_raw_payload(
        row,
        execution_status="BACKEND_FAILED",
        response_text="",
        parse_record=parse_record,
        raw_response={},
        error=error,
        latency_seconds=0.0,
        runtime_model_id="",
        done_reason="",
        reuse_class=NEW_INFERENCE,
    )


def execute_full_requests(
    root: Path,
    config: Mapping[str, Any],
    requests: pd.DataFrame,
    reuse_audit: pd.DataFrame,
    *,
    execute: bool,
    allow_api_calls: bool,
    allow_local_ollama: bool,
    runtime_available: bool,
    runtime_error: str,
) -> None:
    if not execute:
        return
    if not allow_api_calls:
        raise RQ5CorrectedRecoveryError("full execution requires --allow-api-calls")
    if not allow_local_ollama:
        raise RQ5CorrectedRecoveryError("full execution requires --allow-local-ollama")
    if not runtime_available:
        raise RQ5CorrectedRecoveryError(f"backend_unavailable: {runtime_error}")
    namespace = output_path(root, config, "raw_namespace").resolve()
    namespace.mkdir(parents=True, exist_ok=True)
    audit_by_id = reuse_audit.set_index("request_id").to_dict("index")
    total = len(requests)
    executed_new = 0
    reused = 0
    skipped = 0
    for index, row in enumerate(requests.to_dict("records"), start=1):
        destination = project_path(root, row["output_destination"])
        if destination.exists():
            skipped += 1
            continue
        audit = audit_by_id[str(row["request_id"])]
        reuse_class = str(audit["final_reuse_class"])
        if reuse_class == REUSE_PILOT:
            source_file = str(audit["pilot_v2_source_file"])
            source_path = project_path(root, source_file)
            source_payload = json.loads(source_path.read_text(encoding="utf-8"))
            parse_record = source_payload.get("parse") if isinstance(source_payload.get("parse"), Mapping) else {}
            payload = build_full_raw_payload(
                row,
                execution_status="SUCCEEDED",
                response_text=raw_response_text(source_payload),
                parse_record=parse_record,
                raw_response=source_payload.get("ollama_raw_response", {}),
                error="",
                latency_seconds=0.0,
                runtime_model_id=str(source_payload.get("runtime_model_id", row["model_name"])),
                done_reason=str(source_payload.get("ollama_done_reason", "")),
                reuse_class=REUSE_PILOT,
                reuse_source_file=source_file,
                reuse_source_request_id=str(source_payload.get("request_id", audit.get("pilot_v2_candidate_request_id", ""))),
            )
            write_json(destination, payload)
            reused += 1
        else:
            runtime = r5c.generate_local_ollama(row, config)
            if not runtime.response_received:
                payload = backend_failed_payload(row, runtime.error)
            elif not runtime.backend_complete:
                parse_record = parse_corrected_response(row, runtime.response_text)
                parse_record["parse_valid"] = False
                parse_record["parse_status"] = "backend_incomplete"
                parse_record["validity_class"] = "BACKEND_INCOMPLETE"
                parse_record["hr_at_5"] = 0.0
                parse_record["ndcg_at_5"] = 0.0
                payload = build_full_raw_payload(
                    row,
                    execution_status="BACKEND_INCOMPLETE",
                    response_text=runtime.response_text,
                    parse_record=parse_record,
                    raw_response=runtime.raw_response or {},
                    error=runtime.error,
                    latency_seconds=runtime.latency_seconds,
                    runtime_model_id=runtime.runtime_model_id,
                    done_reason=runtime.done_reason,
                    reuse_class=NEW_INFERENCE,
                )
            else:
                parse_record = parse_corrected_response(row, runtime.response_text)
                payload = build_full_raw_payload(
                    row,
                    execution_status="SUCCEEDED",
                    response_text=runtime.response_text,
                    parse_record=parse_record,
                    raw_response=runtime.raw_response or {},
                    error="",
                    latency_seconds=runtime.latency_seconds,
                    runtime_model_id=runtime.runtime_model_id,
                    done_reason=runtime.done_reason,
                    reuse_class=NEW_INFERENCE,
                )
            write_json(destination, payload)
            executed_new += 1
        if index % 25 == 0 or index == total:
            print(
                f"FULL_EXECUTION_PROGRESS processed={index}/{total} reused={reused} "
                f"new_calls={executed_new} skipped_existing={skipped}",
                flush=True,
            )


def status_from_payload(row: Mapping[str, Any], payload: Mapping[str, Any], file_sha: str) -> dict[str, Any]:
    parse_record = payload.get("parse") if isinstance(payload.get("parse"), Mapping) else {}
    execution_status = str(payload.get("execution_status", payload.get("status", "SUCCEEDED")))
    parse_status = str(parse_record.get("parse_status", parse_record.get("status", "")))
    return {
        "request_id": str(row["request_id"]),
        "dataset": str(row["dataset"]),
        "user_id": str(row["user_id"]),
        "recommender": str(row["model_name"]),
        "condition": str(row["condition"]),
        "profile_generator": str(row["profile_generator_name"]),
        "planned": 1,
        "completed": 1 if execution_status == "SUCCEEDED" else 0,
        "terminal": 1,
        "strict_valid": 1 if parse_bool(parse_record.get("parse_valid", False)) else 0,
        "invalid_length": 1 if parse_status == "invalid_length" else 0,
        "duplicate_index": 1 if parse_status == "duplicate_indices" else 0,
        "out_of_range_index": 1 if parse_status == "unknown_indices" else 0,
        "parse_failure": 1 if validity_class_from_status(parse_status) == "PARSE_FAILURE" else 0,
        "backend_failure": 1 if execution_status == "BACKEND_FAILED" else 0,
        "backend_incomplete": 1 if execution_status == "BACKEND_INCOMPLETE" else 0,
        "reuse_class": str(payload.get("reuse_class", NEW_INFERENCE)),
        "parse_status": parse_status,
        "validity_class": str(parse_record.get("validity_class", validity_class_from_status(parse_status))),
        "positive_rank": int(parse_record.get("positive_rank", 0) or 0),
        "hr_at_5": float(parse_record.get("hr_at_5", 0.0) or 0.0),
        "ndcg_at_5": float(parse_record.get("ndcg_at_5", 0.0) or 0.0),
        "output_length": int(parse_record.get("output_length", 0) or 0),
        "duplicate_count": int(parse_record.get("duplicate_count", 0) or 0),
        "unknown_item_count": int(parse_record.get("unknown_item_count", 0) or 0),
        "result_file_sha256": file_sha,
    }


def not_executed_status(row: Mapping[str, Any], reuse_class: str) -> dict[str, Any]:
    return {
        "request_id": str(row["request_id"]),
        "dataset": str(row["dataset"]),
        "user_id": str(row["user_id"]),
        "recommender": str(row["model_name"]),
        "condition": str(row["condition"]),
        "profile_generator": str(row["profile_generator_name"]),
        "planned": 1,
        "completed": 0,
        "terminal": 0,
        "strict_valid": 0,
        "invalid_length": 0,
        "duplicate_index": 0,
        "out_of_range_index": 0,
        "parse_failure": 0,
        "backend_failure": 0,
        "backend_incomplete": 0,
        "reuse_class": reuse_class,
        "parse_status": "not_executed",
        "validity_class": "NOT_EXECUTED",
        "positive_rank": 0,
        "hr_at_5": 0.0,
        "ndcg_at_5": 0.0,
        "output_length": 0,
        "duplicate_count": 0,
        "unknown_item_count": 0,
        "result_file_sha256": "",
    }


def build_request_status(root: Path, requests: pd.DataFrame, reuse_audit: pd.DataFrame) -> pd.DataFrame:
    audit_by_id = reuse_audit.set_index("request_id")["final_reuse_class"].to_dict() if not reuse_audit.empty else {}
    rows: list[dict[str, Any]] = []
    for row in requests.to_dict("records"):
        destination = project_path(root, row["output_destination"])
        if destination.exists():
            payload = json.loads(destination.read_text(encoding="utf-8"))
            rows.append(status_from_payload(row, payload, sha256_file(destination)))
        else:
            rows.append(not_executed_status(row, str(audit_by_id.get(str(row["request_id"]), NEW_INFERENCE))))
    return pd.DataFrame(rows)


def build_request_accounting(status: pd.DataFrame) -> pd.DataFrame:
    group_cols = ["dataset", "recommender", "condition", "profile_generator"]
    numeric_cols = [
        "planned",
        "completed",
        "terminal",
        "strict_valid",
        "invalid_length",
        "duplicate_index",
        "out_of_range_index",
        "parse_failure",
        "backend_failure",
        "backend_incomplete",
    ]
    grouped = status.groupby(group_cols, as_index=False, sort=True)[numeric_cols].sum()
    grouped["strict_validity_rate"] = grouped["strict_valid"] / grouped["planned"].clip(lower=1)
    return grouped


def build_metrics(status: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for key, group in status.groupby(["dataset", "recommender", "condition", "profile_generator"], sort=True):
        dataset, recommender, condition, profile_generator = key
        planned = int(group["planned"].sum())
        strict_valid = int(group["strict_valid"].sum())
        rows.append(
            {
                "dataset": dataset,
                "recommender": recommender,
                "condition": condition,
                "profile_generator": profile_generator,
                "requests": planned,
                "strict_valid": strict_valid,
                "strict_validity_rate": strict_valid / planned if planned else 0.0,
                "hr_at_5": float(group["hr_at_5"].sum() / planned) if planned else 0.0,
                "ndcg_at_5": float(group["ndcg_at_5"].sum() / planned) if planned else 0.0,
                "denominator_policy": DENOMINATOR_POLICY,
                "metric_source": "corrected_full_index_rankings_invalid_zero",
            }
        )
    return pd.DataFrame(rows)


def build_paired_contributions(status: pd.DataFrame, config: Mapping[str, Any]) -> pd.DataFrame:
    scope = config.get("scope") or {}
    datasets = [str(value) for value in scope.get("datasets", [])]
    recommenders = [str(value) for value in scope.get("recommenders", [])]
    generators = [str(value) for value in scope.get("profile_generators", [])]
    index = status.set_index(["dataset", "recommender", "condition", "profile_generator", "user_id"])
    rows: list[dict[str, Any]] = []
    for dataset in datasets:
        for recommender in recommenders:
            history_users = status[
                status["dataset"].eq(dataset)
                & status["recommender"].eq(recommender)
                & status["condition"].eq("history_only")
                & status["profile_generator"].eq("none")
            ]["user_id"].astype(str)
            for generator in generators:
                for comparison, _delta_type, treatment, _label in DELTA_SPECS:
                    for user_id in sorted_users(history_users):
                        h = index.loc[(dataset, recommender, "history_only", "none", user_id)]
                        t = index.loc[(dataset, recommender, treatment, generator, user_id)]
                        for metric in ["hr_at_5", "ndcg_at_5"]:
                            h_value = float(h[metric])
                            t_value = float(t[metric])
                            rows.append(
                                {
                                    "dataset": dataset,
                                    "user_id": user_id,
                                    "recommender": recommender,
                                    "profile_generator": generator,
                                    "comparison": comparison,
                                    "metric": metric,
                                    "history_value": h_value,
                                    "treatment_value": t_value,
                                    "delta": t_value - h_value,
                                    "history_request_id": str(h["request_id"]),
                                    "treatment_request_id": str(t["request_id"]),
                                    "denominator_policy": DENOMINATOR_POLICY,
                                    "metric_source": "corrected_full_index_rankings_invalid_zero",
                                }
                            )
    return pd.DataFrame(rows)


def build_matched_deltas(contrib: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for key, group in contrib.groupby(["dataset", "recommender", "profile_generator", "comparison", "metric"], sort=True):
        dataset, recommender, generator, comparison, metric = key
        rows.append(
            {
                "dataset": dataset,
                "recommender": recommender,
                "profile_generator": generator,
                "comparison": comparison,
                "metric": metric,
                "paired_n": int(len(group)),
                "history_mean": float(group["history_value"].mean()),
                "treatment_mean": float(group["treatment_value"].mean()),
                "mean_delta": float(group["delta"].mean()),
                "denominator_policy": DENOMINATOR_POLICY,
                "metric_source": "corrected_full_index_rankings_invalid_zero",
            }
        )
    return pd.DataFrame(rows)


def build_bootstrap_results(contrib: pd.DataFrame, config: Mapping[str, Any]) -> pd.DataFrame:
    stats = config.get("statistics") or {}
    resamples = int(stats.get("bootstrap_resamples", 10000))
    seed = int(stats.get("bootstrap_seed", 20260901))
    low_q = float(stats.get("bootstrap_ci_lower", 0.025))
    high_q = float(stats.get("bootstrap_ci_upper", 0.975))
    rng = np.random.default_rng(seed)
    rows: list[dict[str, Any]] = []
    for key, group in contrib.groupby(["dataset", "recommender", "profile_generator", "comparison", "metric"], sort=True):
        dataset, recommender, generator, comparison, metric = key
        deltas = group["delta"].astype(float).to_numpy()
        if len(deltas) == 0:
            continue
        sample_idx = rng.integers(0, len(deltas), size=(resamples, len(deltas)))
        boot = deltas[sample_idx].mean(axis=1)
        ci_low, ci_high = np.quantile(boot, [low_q, high_q], method="linear")
        mean_delta = float(deltas.mean())
        if ci_low > 0:
            decision = "CI_SUPPORTED_POSITIVE"
        elif ci_high < 0:
            decision = "CI_SUPPORTED_NEGATIVE"
        else:
            decision = "NON_SIGNIFICANT_CI_INCLUDES_ZERO"
        rows.append(
            {
                "dataset": dataset,
                "recommender": recommender,
                "profile_generator": generator,
                "comparison": comparison,
                "metric": metric,
                "paired_n": int(len(deltas)),
                "mean_delta": mean_delta,
                "ci_lower": float(ci_low),
                "ci_upper": float(ci_high),
                "bootstrap_resamples": resamples,
                "bootstrap_seed": seed,
                "ci_method": "two_sided_percentile_numpy_linear",
                "decision": decision,
                "p_value": "",
            }
        )
    return pd.DataFrame(rows)


def build_old_f6l_diagnostic(parse: pd.DataFrame, metrics: pd.DataFrame) -> pd.DataFrame:
    subset = parse.copy()
    subset["condition"] = subset["input_variant"]
    subset["profile_generator"] = subset["profile_generator_name"].replace("", "none")
    old_rows = []
    for key, group in subset.groupby(["dataset", "recommender_model_name", "condition", "profile_generator"], sort=True):
        dataset, recommender, condition, generator = key
        old_rows.append(
            {
                "dataset": dataset,
                "recommender": recommender,
                "condition": condition,
                "profile_generator": generator,
                "old_f6l_rows": len(group),
                "old_f6l_strict_validity_rate": float(group["strict_valid_bool"].mean()),
                "old_f6l_hr_at_5": float(group["hit_at_5_numeric"].mean()),
                "old_f6l_ndcg_at_5": float(group["ndcg_at_5_numeric"].mean()),
            }
        )
    old = pd.DataFrame(old_rows)
    merged = metrics.merge(old, on=["dataset", "recommender", "condition", "profile_generator"], how="left")
    merged["old_f6l_status"] = "SUPERSEDED_FOR_PRIMARY_RQ5_UTILITY"
    merged["retention_status"] = "RETAINED_AS_OUTPUT_CONTRACT_DIAGNOSTIC"
    merged["diagnostic_note"] = "Old near-zero utility was dominated by the fragile title-output/parser contract."
    return merged


def build_r5d_descriptive_comparison(root: Path, config: Mapping[str, Any], metrics: pd.DataFrame) -> pd.DataFrame:
    rel = Path(str((config.get("source_authority") or {}).get("r5d_results", "results/tables/reproduction_r5d_generation_involved_v2_results.csv")))
    try:
        source = resolve_source(root, rel)
        r5d = pd.read_csv(source.path, dtype=str, keep_default_na=False)
    except FileNotFoundError:
        return pd.DataFrame()
    r5d["dataset_key"] = r5d["dataset"].astype(str).str.lower()
    r5d["metric_key"] = r5d["metric"].astype(str).str.lower().str.replace("@", "_at_", regex=False)
    corrected = metrics[metrics["condition"].eq("profile_plus_history")].copy()
    rows: list[dict[str, Any]] = []
    for row in corrected.to_dict("records"):
        subset = r5d[
            r5d["dataset_key"].eq(str(row["dataset"]))
            & r5d["model_name"].eq(str(row["recommender"]))
            & r5d["experimental_condition"].eq("PROFILE_PLUS_HISTORY")
        ]
        for metric, label in [("hr_at_5", "HR@5"), ("ndcg_at_5", "NDCG@5")]:
            match = subset[subset["metric"].eq(label)]
            rows.append(
                {
                    "dataset": str(row["dataset"]),
                    "recommender": str(row["recommender"]),
                    "profile_generator": str(row["profile_generator"]),
                    "metric": metric,
                    "corrected_full_value": float(row[metric]),
                    "r5d_value": float(match.iloc[0]["value"]) if len(match) == 1 else np.nan,
                    "comparison_status": "DESCRIPTIVE_ONLY_NO_CAUSAL_DELTA",
                    "source_file": rel.as_posix(),
                    "source_sha256": source.sha256,
                }
            )
    return pd.DataFrame(rows)


def validation_row(check_id: str, passed: bool, expected: Any, observed: Any, details: str = "") -> dict[str, Any]:
    return {
        "check_id": check_id,
        "status": "PASS" if passed else "FAIL",
        "expected": str(expected),
        "observed": str(observed),
        "details": details,
    }


def build_validation(
    root: Path,
    config: Mapping[str, Any],
    requests: pd.DataFrame,
    matching: pd.DataFrame,
    reuse: pd.DataFrame,
    runtime: pd.DataFrame,
    status: pd.DataFrame,
    metrics: pd.DataFrame,
    deltas: pd.DataFrame,
    bootstrap: pd.DataFrame,
) -> tuple[pd.DataFrame, str]:
    scope = config.get("scope") or {}
    gates = config.get("gates") or {}
    datasets = [str(value) for value in scope.get("datasets", [])]
    n_users = int(scope.get("full_users_per_dataset", 200))
    expected_total = 4000
    expected_counts = {"history_only": 800, "profile_only": 1600, "profile_plus_history": 1600}
    min_validity = float(gates.get("min_overall_strict_validity_rate", 0.98))
    min_major = float(gates.get("min_major_family_strict_validity_rate", 0.95))
    rows: list[dict[str, Any]] = []
    planned = int(status["planned"].sum()) if not status.empty else 0
    terminal = int(status["terminal"].sum()) if not status.empty else 0
    strict = int(status["strict_valid"].sum()) if not status.empty else 0
    rate = strict / planned if planned else 0.0
    condition_counts = requests["condition"].value_counts().to_dict() if not requests.empty else {}
    reuse_counts = reuse["final_reuse_class"].value_counts().to_dict() if not reuse.empty else {}
    runtime_ok = bool(not runtime.empty and runtime["backend_available"].astype(str).str.lower().eq("true").all())
    matching_ok = bool(not matching.empty and matching["matching_status"].eq("PASS").all() and len(matching) == 3200)
    prompt_hidden = bool(not requests.empty and requests["positive_label_hidden"].eq("true").all())
    user_counts = requests.groupby("dataset")["user_id"].nunique().to_dict() if not requests.empty else {}
    major = status.groupby(["dataset", "recommender", "condition"], as_index=False, sort=True)[["planned", "strict_valid"]].sum()
    major["strict_validity_rate"] = major["strict_valid"] / major["planned"].clip(lower=1)
    major_ok = bool(not major.empty and major["strict_validity_rate"].ge(min_major).all())
    collapse = False
    if rate >= float(gates.get("suspicious_metric_collapse_min_validity", 0.95)) and not metrics.empty:
        collapse = float(metrics["hr_at_5"].astype(float).mean()) <= float(gates.get("suspicious_metric_collapse_max_mean", 0.02))
    protected = protected_git_diff(root)
    rows.append(validation_row("FULL-LOGICAL-REQUEST-COUNT", len(requests) == expected_total, expected_total, len(requests)))
    rows.append(validation_row("FULL-CONDITION-COUNTS", all(condition_counts.get(k, 0) == v for k, v in expected_counts.items()), expected_counts, condition_counts))
    rows.append(validation_row("FULL-USERS-PER-DATASET", all(int(user_counts.get(d, 0)) == n_users for d in datasets), {d: n_users for d in datasets}, user_counts))
    rows.append(validation_row("NO-DUPLICATE-REQUEST-IDS", requests["request_id"].is_unique, "unique", int(requests["request_id"].duplicated().sum())))
    rows.append(validation_row("NO-DUPLICATE-LOGICAL-IDS", requests["logical_key_sha256"].is_unique, "unique", int(requests["logical_key_sha256"].duplicated().sum())))
    rows.append(validation_row("MATCHING-PASS", matching_ok, "3200 PASS rows", f"rows={len(matching)}; failures={int(matching['matching_status'].ne('PASS').sum()) if not matching.empty else 'NA'}"))
    rows.append(validation_row("PROMPTS-HIDE-POSITIVE-LABELS", prompt_hidden, "all true", requests["positive_label_hidden"].value_counts().to_dict() if not requests.empty else {}))
    rows.append(validation_row("REUSE-ACCOUNTING-EXACT", sum(reuse_counts.values()) == expected_total, expected_total, reuse_counts))
    rows.append(validation_row("PILOT-V2-REUSE-COUNT", int(reuse_counts.get(REUSE_PILOT, 0)) == 200, 200, int(reuse_counts.get(REUSE_PILOT, 0))))
    rows.append(validation_row("G1-G2-EXACT-REUSE-ZERO", int(reuse_counts.get(REUSE_G1, 0) + reuse_counts.get(REUSE_G2, 0)) == 0, 0, int(reuse_counts.get(REUSE_G1, 0) + reuse_counts.get(REUSE_G2, 0))))
    rows.append(validation_row("NEW-INFERENCE-COUNT", int(reuse_counts.get(NEW_INFERENCE, 0)) == 3800, 3800, int(reuse_counts.get(NEW_INFERENCE, 0))))
    rows.append(validation_row("BACKEND-RUNTIME-AVAILABLE", runtime_ok, "tags reachable and both models available", runtime.to_dict("records")))
    rows.append(validation_row("FULL-TERMINAL-ACCOUNTING", terminal == planned == expected_total, expected_total, f"terminal={terminal}; planned={planned}"))
    rows.append(validation_row("STRICT-VALIDITY-GATE", rate >= min_validity and terminal == planned == expected_total, f">={min_validity}", rate))
    rows.append(validation_row("NO-SYSTEMATIC-MAJOR-FAMILY-FAILURE", major_ok, f">={min_major}", major.to_dict("records")))
    rows.append(validation_row("NO-SUSPICIOUS-METRIC-COLLAPSE", not collapse, "not systematic near-zero collapse", f"suspicious={collapse}"))
    rows.append(validation_row("METRICS-FROM-CORRECTED-SOURCE", set(metrics["metric_source"]) == {"corrected_full_index_rankings_invalid_zero"}, "corrected_full_index_rankings_invalid_zero", set(metrics["metric_source"]) if not metrics.empty else set()))
    rows.append(validation_row("MATCHED-DELTAS-COUNT", len(deltas) == 32, 32, len(deltas)))
    rows.append(validation_row("MATCHED-DELTAS-PAIRED-N", not deltas.empty and deltas["paired_n"].astype(int).eq(200).all(), 200, deltas["paired_n"].value_counts().to_dict() if not deltas.empty else {}))
    rows.append(validation_row("BOOTSTRAP-RESULTS-COUNT", len(bootstrap) == 32, 32, len(bootstrap)))
    rows.append(validation_row("BOOTSTRAP-DETERMINISTIC-CONTRACT", not bootstrap.empty and bootstrap["bootstrap_seed"].astype(int).eq(20260901).all(), 20260901, bootstrap["bootstrap_seed"].unique().tolist() if not bootstrap.empty else []))
    rows.append(validation_row("PROTECTED-HISTORICAL-PATHS-UNTOUCHED", len(protected) == 0, "no git diff in protected F6L/R5C/R5D paths", ";".join(protected)))

    verdict = VERDICT_READY
    if not runtime_ok:
        verdict = VERDICT_BACKEND
    elif not matching_ok:
        verdict = VERDICT_MATCHING
    elif terminal != planned or planned != expected_total:
        verdict = VERDICT_CONTRACT
    elif rate < min_validity or not major_ok:
        verdict = VERDICT_VALIDITY
    elif collapse:
        verdict = VERDICT_COLLAPSE
    return pd.DataFrame(rows), verdict


def format_value(value: float, metric: str) -> str:
    return f"{value:.3f}" if metric == "hr_at_5" else f"{value:.3f}"


def build_conditions_figure_values(root: Path, config: Mapping[str, Any], metrics: pd.DataFrame) -> pd.DataFrame:
    source_path = output_path(root, config, "full_metrics")
    source_sha = sha256_file(source_path) if source_path.exists() else ""
    rows: list[dict[str, Any]] = []
    for dataset_order, dataset in enumerate(["beauty", "sports"]):
        for model_order, model in enumerate(["mistral:7b-instruct", "qwen2:7b-instruct"]):
            for generator_order, generator in enumerate(["mistral:7b-instruct", "qwen2:7b-instruct"]):
                for metric_order, metric in enumerate(["hr_at_5", "ndcg_at_5"]):
                    for condition in ["history_only", "profile_only", "profile_plus_history"]:
                        generator_key = "none" if condition == "history_only" else generator
                        match = metrics[
                            metrics["dataset"].eq(dataset)
                            & metrics["recommender"].eq(model)
                            & metrics["profile_generator"].eq(generator_key)
                            & metrics["condition"].eq(condition)
                        ]
                        if len(match) != 1:
                            continue
                        rec = match.iloc[0]
                        value = float(rec[metric])
                        rows.append(
                            {
                                "figure_id": "fig_rq5_profile_conditions_main",
                                "dataset": DATASET_LABELS[dataset],
                                "dataset_label": DATASET_LABELS[dataset],
                                "dataset_order": dataset_order,
                                "model_name": model,
                                "model_label": MODEL_LABELS[model],
                                "model_order": model_order,
                                "profile_generator": generator,
                                "profile_generator_label": MODEL_LABELS[generator],
                                "profile_generator_order": generator_order,
                                "experimental_condition": condition,
                                "condition_label": CONDITION_LABELS[condition],
                                "condition_order": CONDITION_ORDER[condition],
                                "metric": metric,
                                "metric_label": METRIC_LABELS[metric],
                                "metric_order": metric_order,
                                "value": value,
                                "source_value": value,
                                "plotted_value": value,
                                "value_display": format_value(value, metric),
                                "plot_status": "PLOTTED",
                                "zero_classification": "VALID_ZERO" if value == 0 else "NOT_ZERO",
                                "n_manifest": int(rec["requests"]),
                                "n_valid": int(rec["strict_valid"]),
                                "n_invalid": int(rec["requests"]) - int(rec["strict_valid"]),
                                "denominator_policy": DENOMINATOR_POLICY,
                                "validity_information": f"strict_valid={int(rec['strict_valid'])}/{int(rec['requests'])}; invalid outputs contribute zero",
                                "evidence_class": "corrected_matched_recovery_primary_rq5_utility",
                                "matched_history_profile_users": 200,
                                "comparison_scope": "corrected_full_matched_profile_family_experiment",
                                "line_group_id": f"{DATASET_LABELS[dataset]}|{model}|{generator}|{metric}",
                                "model_color": MODEL_COLORS[model],
                                "profile_marker": PROFILE_MARKERS[generator],
                                "profile_linestyle": PROFILE_LINESTYLES[generator],
                                "caption_note": (
                                    "Corrected matched RQ5 utility across History, Profile, and History+Profile. "
                                    "Values are computed from strict candidate-index rankings with invalid outputs "
                                    "counted as zero under the full 200-user denominator."
                                ),
                                "source_file": "results/tables/rq5_corrected_full_metrics.csv",
                                "source_path": str(source_path),
                                "source_sha256": source_sha,
                                "source_scope": "local_corrected_full_recovery",
                            }
                        )
    return pd.DataFrame(rows).sort_values(
        ["dataset_order", "metric_order", "model_order", "profile_generator_order", "condition_order"]
    )


def build_deltas_figure_values(root: Path, config: Mapping[str, Any], deltas: pd.DataFrame) -> pd.DataFrame:
    source_path = output_path(root, config, "full_matched_deltas")
    source_sha = sha256_file(source_path) if source_path.exists() else ""
    max_abs = float(deltas["mean_delta"].abs().max()) if not deltas.empty else 0.0
    rows: list[dict[str, Any]] = []
    row_order_map: dict[tuple[str, str, str], int] = {}
    for dataset in ["beauty", "sports"]:
        for generator in ["mistral:7b-instruct", "qwen2:7b-instruct"]:
            for model in ["mistral:7b-instruct", "qwen2:7b-instruct"]:
                row_order_map[(dataset, model, generator)] = len(row_order_map)
    for row in deltas.to_dict("records"):
        dataset = str(row["dataset"])
        model = str(row["recommender"])
        generator = str(row["profile_generator"])
        comparison = str(row["comparison"])
        metric = str(row["metric"])
        delta_spec = next(spec for spec in DELTA_SPECS if spec[0] == comparison)
        delta_type = delta_spec[1]
        delta_label = f"Delta {METRIC_LABELS[metric]}\n{delta_spec[3]}"
        delta_order = (0 if delta_type == "PROFILE_MINUS_HISTORY" else 1) + (0 if metric == "hr_at_5" else 2)
        value = float(row["mean_delta"])
        baseline = float(row["history_mean"])
        treatment = float(row["treatment_mean"])
        row_label = f"{DATASET_LABELS[dataset]} | gen {MODEL_LABELS[generator]} | rec {MODEL_LABELS[model]}"
        rows.append(
            {
                "figure_id": "fig_rq5_profile_deltas_heatmap",
                "dataset": DATASET_LABELS[dataset],
                "dataset_label": DATASET_LABELS[dataset],
                "dataset_order": 0 if dataset == "beauty" else 1,
                "model_name": model,
                "model_label": MODEL_LABELS[model],
                "model_order": 0 if model == "mistral:7b-instruct" else 1,
                "profile_generator": generator,
                "profile_generator_label": MODEL_LABELS[generator],
                "profile_generator_order": 0 if generator == "mistral:7b-instruct" else 1,
                "row_label": row_label,
                "row_order": row_order_map[(dataset, model, generator)],
                "delta_key": f"delta_{comparison}_{metric}",
                "delta_label": delta_label,
                "delta_order": delta_order,
                "delta_type": delta_type,
                "metric": metric,
                "metric_label": METRIC_LABELS[metric],
                "value": value,
                "source_value": value,
                "plotted_value": value,
                "plot_status": "PLOTTED",
                "value_display": f"{value:+.3f}",
                "cell_label": f"{value:+.3f}",
                "signed_delta_label": f"{value:+.3f}",
                "color_value": abs(value),
                "zero_classification": "VALID_ZERO" if value == 0 else "NOT_ZERO",
                "heatmap_palette_min": "#FFFFFF",
                "heatmap_palette_max": "#117A65",
                "heatmap_normalization_basis": "absolute_delta_with_signed_labels",
                "matched_history_profile_users": 200,
                "comparison_scope": "corrected_full_matched_profile_family_experiment",
                "difference_comparison": comparison,
                "difference_status": "computed",
                "difference_paired_users": int(row["paired_n"]),
                "difference_source_value": value,
                "delta_reconciliation_abs_diff": abs(value - (treatment - baseline)),
                "baseline_value": baseline,
                "treatment_value": treatment,
                "source_file": "results/tables/rq5_corrected_full_matched_deltas.csv",
                "source_path": str(source_path),
                "source_sha256": source_sha,
                "source_scope": "local_corrected_full_recovery",
                "heatmap_range_min": 0.0,
                "heatmap_range_max": max_abs,
            }
        )
    return pd.DataFrame(rows).sort_values(["row_order", "delta_order"])


def plot_conditions(values: pd.DataFrame, output_path: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(12.6, 7.6), sharex=True)
    panels = [
        ("Beauty", "hr_at_5", "Beauty - HR@5"),
        ("Beauty", "ndcg_at_5", "Beauty - NDCG@5"),
        ("Sports", "hr_at_5", "Sports - HR@5"),
        ("Sports", "ndcg_at_5", "Sports - NDCG@5"),
    ]
    for idx, (ax, (dataset, metric, title)) in enumerate(zip(axes.ravel(), panels), start=1):
        subset = values[values["dataset"].eq(dataset) & values["metric"].eq(metric)]
        ymax = max(float(pd.to_numeric(subset["value"], errors="coerce").max()), 0.08)
        for model in ["mistral:7b-instruct", "qwen2:7b-instruct"]:
            for generator in ["mistral:7b-instruct", "qwen2:7b-instruct"]:
                plotted = subset[
                    subset["model_name"].eq(model) & subset["profile_generator"].eq(generator)
                ].sort_values("condition_order")
                ax.plot(
                    plotted["condition_order"],
                    pd.to_numeric(plotted["value"], errors="raise"),
                    color=MODEL_COLORS[model],
                    marker=PROFILE_MARKERS[generator],
                    linestyle=PROFILE_LINESTYLES[generator],
                    linewidth=2,
                    markersize=6,
                    label=f"Rec {MODEL_LABELS[model]} | Gen {MODEL_LABELS[generator]}",
                )
        ax.set_title(f"({chr(96 + idx)}) {title}", fontweight="bold")
        ax.set_xticks([0, 1, 2])
        ax.set_xticklabels(["History", "Profile", "History + Profile"], fontsize=9)
        ax.set_ylim(0, min(1.0, ymax * 1.20))
        ax.grid(axis="y", alpha=0.25)
        ax.axhline(0, color="#333333", linewidth=0.7)
        if idx in {1, 3}:
            ax.set_ylabel("Fail-strict utility")
    handles, labels = axes.ravel()[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, frameon=False, bbox_to_anchor=(0.5, 0.085))
    fig.suptitle("RQ5 - Corrected Matched Profile Conditions", fontsize=14, fontweight="bold")
    fig.text(
        0.07,
        0.018,
        "Corrected full matched recovery using strict candidate-index rankings; invalid outputs count as zero.",
        fontsize=8.2,
        ha="left",
        va="bottom",
        wrap=True,
    )
    fig.subplots_adjust(left=0.075, right=0.985, top=0.88, bottom=0.23, wspace=0.23, hspace=0.34)
    fig.savefig(output_path, dpi=300)
    plt.close(fig)


def plot_deltas(values: pd.DataFrame, output_path: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import LinearSegmentedColormap

    row_table = values[["row_label", "row_order"]].drop_duplicates().sort_values("row_order")
    col_table = values[["delta_label", "delta_order"]].drop_duplicates().sort_values("delta_order")
    matrix = np.full((len(row_table), len(col_table)), np.nan)
    labels = np.full((len(row_table), len(col_table)), "", dtype=object)
    row_index = {row.row_label: idx for idx, row in enumerate(row_table.itertuples(index=False))}
    col_index = {row.delta_label: idx for idx, row in enumerate(col_table.itertuples(index=False))}
    for row in values.itertuples(index=False):
        r = row_index[row.row_label]
        c = col_index[row.delta_label]
        matrix[r, c] = float(row.color_value)
        labels[r, c] = str(row.cell_label)
    vmax = float(np.nanmax(matrix)) if np.isfinite(matrix).any() else 1.0
    cmap = LinearSegmentedColormap.from_list("rq5_teal", ["#FFFFFF", "#117A65"])
    fig, ax = plt.subplots(figsize=(10.8, 5.8))
    im = ax.imshow(matrix, cmap=cmap, vmin=0.0, vmax=max(vmax, 1e-9), aspect="auto")
    ax.set_yticks(range(len(row_table)))
    ax.set_yticklabels(row_table["row_label"].tolist(), fontsize=8.5)
    ax.set_xticks(range(len(col_table)))
    ax.set_xticklabels(col_table["delta_label"].tolist(), fontsize=8.5)
    for r in range(matrix.shape[0]):
        for c in range(matrix.shape[1]):
            value = matrix[r, c]
            text_color = "white" if value / max(vmax, 1e-9) > 0.58 else "#222222"
            ax.text(c, r, labels[r, c], ha="center", va="center", fontsize=8.5, color=text_color)
    ax.set_title("RQ5 - Corrected Matched Profile Utility Deltas", fontweight="bold")
    ax.set_xlabel("Delta definition")
    ax.set_ylabel("Dataset | recommender/profile generator")
    cbar = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.025)
    cbar.set_label("Absolute delta magnitude")
    fig.text(
        0.11,
        0.02,
        "Color encodes absolute delta magnitude; labels are signed corrected full matched deltas.",
        fontsize=8.5,
        ha="left",
        va="bottom",
        wrap=True,
    )
    fig.subplots_adjust(left=0.22, right=0.95, top=0.89, bottom=0.24)
    fig.savefig(output_path, dpi=300)
    plt.close(fig)


def write_figure_bundle(root: Path, figure_id: str, values: pd.DataFrame, plotter: Any, source_files: Sequence[str]) -> None:
    tables_dir = root / "results" / "tables"
    plots_dir = root / "results" / "plots"
    manifests_dir = root / "results" / "manifests"
    report_dir = root / "report"
    tables_dir.mkdir(parents=True, exist_ok=True)
    plots_dir.mkdir(parents=True, exist_ok=True)
    manifests_dir.mkdir(parents=True, exist_ok=True)
    report_dir.mkdir(parents=True, exist_ok=True)
    value_path = tables_dir / f"{figure_id}_values.csv"
    write_csv(values, value_path)
    outputs = {}
    for ext in ["png", "pdf", "svg"]:
        path = plots_dir / f"{figure_id}.{ext}"
        plotter(values, path)
        outputs[ext] = normalize_rel(path.relative_to(root))
    manifest = {
        "figure_id": figure_id,
        "source_files": list(source_files),
        "value_csv": normalize_rel(value_path.relative_to(root)),
        "row_count": int(len(values)),
        "png": outputs["png"],
        "pdf": outputs["pdf"],
        "svg": outputs["svg"],
        "generated_by": PHASE_ID,
        "source_sha256": sha256_file(value_path),
    }
    manifest_path = manifests_dir / f"{figure_id}_manifest.json"
    write_json(manifest_path, manifest)
    report_path = report_dir / f"{figure_id}.md"
    report_path.write_text(
        "\n".join(
            [
                f"# {figure_id}",
                "",
                f"- Generated by: `{PHASE_ID}`",
                f"- Values CSV: `{manifest['value_csv']}`",
                f"- PNG: `{outputs['png']}`",
                f"- PDF: `{outputs['pdf']}`",
                f"- SVG: `{outputs['svg']}`",
                "- Source: corrected full matched RQ5 recovery.",
                "",
            ]
        ),
        encoding="utf-8",
    )


def update_final_manifest(root: Path) -> None:
    path = root / "results" / "tables" / "FINAL_FIGURE_MANIFEST.csv"
    if not path.exists():
        return
    frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    updates = {
        "fig_rq5_profile_conditions_main": {
            "source_files": "results/tables/rq5_corrected_full_metrics.csv",
            "caveat": "Corrected full matched RQ5 utility from strict candidate-index rankings; old F6L title-output utility is superseded for the primary claim.",
            "row_count": "48",
        },
        "fig_rq5_profile_deltas_heatmap": {
            "source_files": "results/tables/rq5_corrected_full_matched_deltas.csv;results/tables/rq5_corrected_full_bootstrap_results.csv",
            "caveat": "Corrected full paired-user deltas and bootstrap CIs from strict candidate-index rankings; no old F6L utility is used as source.",
            "row_count": "32",
        },
    }
    for figure_id, values in updates.items():
        mask = frame["figure_id"].eq(figure_id)
        for column, value in values.items():
            if column in frame.columns:
                frame.loc[mask, column] = value
    write_csv(frame, path)


def regenerate_final_figures_if_ready(
    root: Path,
    config: Mapping[str, Any],
    verdict: str,
    metrics: pd.DataFrame,
    deltas: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, str]:
    if verdict != VERDICT_READY:
        return pd.DataFrame(), pd.DataFrame(), "SKIPPED_VALIDITY_GATE_NOT_READY"
    condition_values = build_conditions_figure_values(root, config, metrics)
    delta_values = build_deltas_figure_values(root, config, deltas)
    write_figure_bundle(
        root,
        "fig_rq5_profile_conditions_main",
        condition_values,
        plot_conditions,
        ["results/tables/rq5_corrected_full_metrics.csv"],
    )
    write_figure_bundle(
        root,
        "fig_rq5_profile_deltas_heatmap",
        delta_values,
        plot_deltas,
        ["results/tables/rq5_corrected_full_matched_deltas.csv", "results/tables/rq5_corrected_full_bootstrap_results.csv"],
    )
    update_final_manifest(root)
    return condition_values, delta_values, "REGENERATED_F1_F2_ONLY"


def build_rq5_final_claim(verdict: str, bootstrap: pd.DataFrame) -> str:
    if verdict != VERDICT_READY:
        return "BLOCKED: corrected full matched validity gate did not pass; no RQ5 scientific interpretation."
    counts = bootstrap["decision"].value_counts().to_dict() if not bootstrap.empty else {}
    positive = int(counts.get("CI_SUPPORTED_POSITIVE", 0))
    negative = int(counts.get("CI_SUPPORTED_NEGATIVE", 0))
    nonsig = int(counts.get("NON_SIGNIFICANT_CI_INCLUDES_ZERO", 0))
    return (
        "PROTOCOL-ADAPTED NUMERIC ANALOGUE: corrected full matched RQ5 evidence uses local open 7B models "
        "on Beauty/Sports with HR@5/NDCG@5 only. Bootstrap decisions: "
        f"{positive}/32 positive, {negative}/32 negative, {nonsig}/32 include zero."
    )


def render_report(
    root: Path,
    verdict: str,
    requests: pd.DataFrame,
    reuse: pd.DataFrame,
    runtime: pd.DataFrame,
    accounting: pd.DataFrame,
    metrics: pd.DataFrame,
    deltas: pd.DataFrame,
    bootstrap: pd.DataFrame,
    validation: pd.DataFrame,
    figure_status: str,
    final_claim: str,
) -> str:
    reuse_counts = reuse["final_reuse_class"].value_counts().to_dict() if not reuse.empty else {}
    failures = validation[validation["status"].ne("PASS")]["check_id"].tolist() if not validation.empty else []
    return "\n".join(
        [
            "# RQ5 Corrected Matched Full Recovery",
            "",
            f"- Phase: `{PHASE_ID}`",
            f"- Verdict: `{verdict}`",
            f"- Logical requests: `{len(requests)}`",
            f"- Reuse accounting: `{reuse_counts}`",
            f"- Runtime: `{runtime.to_dict('records')}`",
            f"- Figure regeneration: `{figure_status}`",
            f"- Validation failures: `{failures}`",
            "",
            "## Final Claim",
            "",
            final_claim,
            "",
            "## Accounting",
            "",
            accounting.to_markdown(index=False) if not accounting.empty else "_empty_",
            "",
            "## Metrics",
            "",
            metrics.to_markdown(index=False) if not metrics.empty else "_empty_",
            "",
            "## Deltas",
            "",
            deltas.to_markdown(index=False) if not deltas.empty else "_empty_",
            "",
            "## Bootstrap",
            "",
            bootstrap.to_markdown(index=False) if not bootstrap.empty else "_empty_",
            "",
        ]
    )


def build_manifest(
    config_path: Path,
    verdict: str,
    requests: pd.DataFrame,
    reuse: pd.DataFrame,
    accounting: pd.DataFrame,
    metrics: pd.DataFrame,
    deltas: pd.DataFrame,
    bootstrap: pd.DataFrame,
    validation: pd.DataFrame,
    runtime: pd.DataFrame,
    figure_status: str,
    final_claim: str,
) -> dict[str, Any]:
    return {
        "phase": PHASE_ID,
        "verdict": verdict,
        "config_path": normalize_rel(config_path),
        "logical_request_count": int(len(requests)),
        "request_protocol_hash": sha256_text(
            stable_json(
                requests[
                    [
                        "request_id",
                        "f6l_request_id",
                        "dataset",
                        "user_id",
                        "recommender_model_name",
                        "profile_generator_name",
                        "condition",
                        "candidate_list_hash",
                        "positive_item_id",
                        "positive_candidate_position",
                        "prompt_hash",
                    ]
                ].to_dict("records")
            )
        )
        if not requests.empty
        else "",
        "reuse_summary": reuse["final_reuse_class"].value_counts().sort_index().to_dict() if not reuse.empty else {},
        "accounting_summary": accounting.to_dict("records"),
        "metrics_summary": metrics.to_dict("records"),
        "matched_deltas": deltas.to_dict("records"),
        "bootstrap_results": bootstrap.to_dict("records"),
        "validation": validation.to_dict("records"),
        "runtime": runtime.to_dict("records"),
        "figure_regeneration": figure_status,
        "rq5_final_claim": final_claim,
    }


def write_outputs(
    root: Path,
    config: Mapping[str, Any],
    *,
    requests: pd.DataFrame,
    reuse: pd.DataFrame,
    profile_audit: pd.DataFrame,
    matching: pd.DataFrame,
    runtime: pd.DataFrame,
    canonical: pd.DataFrame,
    accounting: pd.DataFrame,
    metrics: pd.DataFrame,
    contributions: pd.DataFrame,
    deltas: pd.DataFrame,
    bootstrap: pd.DataFrame,
    old_f6l: pd.DataFrame,
    r5d: pd.DataFrame,
    validation: pd.DataFrame,
    manifest: Mapping[str, Any],
    report: str,
) -> None:
    write_csv(requests, output_path(root, config, "full_request_universe"))
    write_csv(reuse, output_path(root, config, "full_reuse_audit"))
    write_csv(profile_audit, output_path(root, config, "full_profile_reuse_audit"))
    write_csv(matching, output_path(root, config, "full_matching_audit"))
    write_csv(runtime, output_path(root, config, "full_backend_runtime"))
    write_csv(canonical, output_path(root, config, "full_canonical_contract_audit"))
    write_csv(accounting, output_path(root, config, "full_request_accounting"))
    write_csv(metrics, output_path(root, config, "full_metrics"))
    write_csv(contributions, output_path(root, config, "full_paired_contributions"))
    write_csv(deltas, output_path(root, config, "full_matched_deltas"))
    write_csv(bootstrap, output_path(root, config, "full_bootstrap_results"))
    write_csv(old_f6l, output_path(root, config, "full_old_f6l_diagnostic_comparison"))
    write_csv(r5d, output_path(root, config, "full_r5d_descriptive_comparison"))
    write_csv(validation, output_path(root, config, "full_validation"))
    write_json(output_path(root, config, "manifest"), manifest)
    report_path = output_path(root, config, "report")
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report, encoding="utf-8")


def write_resume_outputs(
    root: Path,
    config: Mapping[str, Any],
    *,
    runtime: pd.DataFrame,
    canonical: pd.DataFrame,
    accounting: pd.DataFrame,
    metrics: pd.DataFrame,
    contributions: pd.DataFrame,
    deltas: pd.DataFrame,
    bootstrap: pd.DataFrame,
    old_f6l: pd.DataFrame,
    r5d: pd.DataFrame,
    validation: pd.DataFrame,
    manifest: Mapping[str, Any],
    report: str,
) -> None:
    write_csv(runtime, output_path(root, config, "full_backend_runtime"))
    write_csv(canonical, output_path(root, config, "full_canonical_contract_audit"))
    write_csv(accounting, output_path(root, config, "full_request_accounting"))
    write_csv(metrics, output_path(root, config, "full_metrics"))
    write_csv(contributions, output_path(root, config, "full_paired_contributions"))
    write_csv(deltas, output_path(root, config, "full_matched_deltas"))
    write_csv(bootstrap, output_path(root, config, "full_bootstrap_results"))
    write_csv(old_f6l, output_path(root, config, "full_old_f6l_diagnostic_comparison"))
    write_csv(r5d, output_path(root, config, "full_r5d_descriptive_comparison"))
    write_csv(validation, output_path(root, config, "full_validation"))
    write_json(output_path(root, config, "manifest"), manifest)
    report_path = output_path(root, config, "report")
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report, encoding="utf-8")


def build_corrected_full_recovery(
    root: Path,
    config_path: Path | None = None,
    *,
    write: bool = True,
    execute_full: bool = False,
    allow_api_calls: bool = False,
    allow_local_ollama: bool = False,
    preflight: bool = False,
) -> dict[str, Any]:
    actual_config_path = config_path or DEFAULT_CONFIG_PATH
    config = load_config(actual_config_path)
    manifest_source = load_f6l_manifest(root)
    parse = load_f6l_parse(root)
    profile_audit = build_profile_reuse_audit(root, config, manifest_source)
    requests, matching, selected_users = build_full_request_universe(root, config, parse, profile_audit)
    reuse = build_reuse_audit(root, config, requests)
    canonical = build_canonical_contract_audit()
    runtime, runtime_available, runtime_error = build_backend_runtime(root, config, run_preflight=preflight or execute_full)
    pre_matching_ok = bool(len(requests) == 4000 and not matching.empty and matching["matching_status"].eq("PASS").all())
    if execute_full:
        if not pre_matching_ok:
            raise RQ5CorrectedRecoveryError("matching audit failed before full execution")
        execute_full_requests(
            root,
            config,
            requests,
            reuse,
            execute=True,
            allow_api_calls=allow_api_calls,
            allow_local_ollama=allow_local_ollama,
            runtime_available=runtime_available,
            runtime_error=runtime_error,
        )
    status = build_request_status(root, requests, reuse) if not requests.empty else pd.DataFrame()
    accounting = build_request_accounting(status) if not status.empty else pd.DataFrame()
    metrics = build_metrics(status) if not status.empty else pd.DataFrame()
    contributions = build_paired_contributions(status, config) if not status.empty else pd.DataFrame()
    deltas = build_matched_deltas(contributions) if not contributions.empty else pd.DataFrame()
    bootstrap = build_bootstrap_results(contributions, config) if not contributions.empty else pd.DataFrame()
    old_f6l = build_old_f6l_diagnostic(parse, metrics) if not metrics.empty else pd.DataFrame()
    r5d = build_r5d_descriptive_comparison(root, config, metrics) if not metrics.empty else pd.DataFrame()
    validation, verdict = build_validation(root, config, requests, matching, reuse, runtime, status, metrics, deltas, bootstrap)
    condition_values, delta_values, figure_status = regenerate_final_figures_if_ready(root, config, verdict, metrics, deltas)
    final_claim = build_rq5_final_claim(verdict, bootstrap)
    report = render_report(root, verdict, requests, reuse, runtime, accounting, metrics, deltas, bootstrap, validation, figure_status, final_claim)
    manifest_payload = build_manifest(
        actual_config_path,
        verdict,
        requests,
        reuse,
        accounting,
        metrics,
        deltas,
        bootstrap,
        validation,
        runtime,
        figure_status,
        final_claim,
    )
    if write:
        write_outputs(
            root,
            config,
            requests=requests,
            reuse=reuse,
            profile_audit=profile_audit,
            matching=matching,
            runtime=runtime,
            canonical=canonical,
            accounting=accounting,
            metrics=metrics,
            contributions=contributions,
            deltas=deltas,
            bootstrap=bootstrap,
            old_f6l=old_f6l,
            r5d=r5d,
            validation=validation,
            manifest=manifest_payload,
            report=report,
        )
    return {
        "verdict": verdict,
        "selected_users": selected_users,
        "requests": requests,
        "reuse": reuse,
        "runtime": runtime,
        "status": status,
        "accounting": accounting,
        "metrics": metrics,
        "deltas": deltas,
        "bootstrap": bootstrap,
        "validation": validation,
        "figure_status": figure_status,
        "condition_values": condition_values,
        "delta_values": delta_values,
        "final_claim": final_claim,
    }


def resume_materialized_full_recovery(
    root: Path,
    config_path: Path | None = None,
    *,
    write: bool = True,
    execute_full: bool = False,
    allow_api_calls: bool = False,
    allow_local_ollama: bool = False,
    preflight: bool = True,
) -> dict[str, Any]:
    actual_config_path = config_path or DEFAULT_CONFIG_PATH
    config = load_config(actual_config_path)
    parse = load_f6l_parse(root)
    requests = pd.read_csv(output_path(root, config, "full_request_universe"), dtype=str, keep_default_na=False)
    reuse = pd.read_csv(output_path(root, config, "full_reuse_audit"), dtype=str, keep_default_na=False)
    matching = pd.read_csv(output_path(root, config, "full_matching_audit"), dtype=str, keep_default_na=False)
    canonical = build_canonical_contract_audit()
    runtime, runtime_available, runtime_error = build_backend_runtime(root, config, run_preflight=preflight or execute_full)
    if execute_full:
        if len(requests) != 4000:
            raise RQ5CorrectedRecoveryError(f"materialized universe row count is not 4000: {len(requests)}")
        if reuse["final_reuse_class"].value_counts().to_dict().get(REUSE_PILOT, 0) != 200:
            raise RQ5CorrectedRecoveryError("materialized pilot-v2 reuse count is not 200")
        if reuse["final_reuse_class"].value_counts().to_dict().get(NEW_INFERENCE, 0) != 3800:
            raise RQ5CorrectedRecoveryError("materialized NEW_INFERENCE count is not 3800")
        if matching.empty or not matching["matching_status"].eq("PASS").all():
            raise RQ5CorrectedRecoveryError("materialized matching audit is not all PASS")
        execute_full_requests(
            root,
            config,
            requests,
            reuse,
            execute=True,
            allow_api_calls=allow_api_calls,
            allow_local_ollama=allow_local_ollama,
            runtime_available=runtime_available,
            runtime_error=runtime_error,
        )
    status = build_request_status(root, requests, reuse) if not requests.empty else pd.DataFrame()
    accounting = build_request_accounting(status) if not status.empty else pd.DataFrame()
    metrics = build_metrics(status) if not status.empty else pd.DataFrame()
    contributions = build_paired_contributions(status, config) if not status.empty else pd.DataFrame()
    deltas = build_matched_deltas(contributions) if not contributions.empty else pd.DataFrame()
    bootstrap = build_bootstrap_results(contributions, config) if not contributions.empty else pd.DataFrame()
    old_f6l = build_old_f6l_diagnostic(parse, metrics) if not metrics.empty else pd.DataFrame()
    r5d = build_r5d_descriptive_comparison(root, config, metrics) if not metrics.empty else pd.DataFrame()
    validation, verdict = build_validation(root, config, requests, matching, reuse, runtime, status, metrics, deltas, bootstrap)
    condition_values, delta_values, figure_status = regenerate_final_figures_if_ready(root, config, verdict, metrics, deltas)
    final_claim = build_rq5_final_claim(verdict, bootstrap)
    report = render_report(root, verdict, requests, reuse, runtime, accounting, metrics, deltas, bootstrap, validation, figure_status, final_claim)
    manifest_payload = build_manifest(
        actual_config_path,
        verdict,
        requests,
        reuse,
        accounting,
        metrics,
        deltas,
        bootstrap,
        validation,
        runtime,
        figure_status,
        final_claim,
    )
    if write:
        write_resume_outputs(
            root,
            config,
            runtime=runtime,
            canonical=canonical,
            accounting=accounting,
            metrics=metrics,
            contributions=contributions,
            deltas=deltas,
            bootstrap=bootstrap,
            old_f6l=old_f6l,
            r5d=r5d,
            validation=validation,
            manifest=manifest_payload,
            report=report,
        )
    return {
        "verdict": verdict,
        "selected_users": {},
        "requests": requests,
        "reuse": reuse,
        "runtime": runtime,
        "status": status,
        "accounting": accounting,
        "metrics": metrics,
        "deltas": deltas,
        "bootstrap": bootstrap,
        "validation": validation,
        "figure_status": figure_status,
        "condition_values": condition_values,
        "delta_values": delta_values,
        "final_claim": final_claim,
    }


def print_summary(result: Mapping[str, Any]) -> None:
    requests = result["requests"]
    reuse = result["reuse"]
    accounting = result["accounting"]
    validation = result["validation"]
    planned = int(accounting["planned"].sum()) if not accounting.empty else 0
    strict = int(accounting["strict_valid"].sum()) if not accounting.empty else 0
    terminal = int(accounting["terminal"].sum()) if not accounting.empty and "terminal" in accounting else 0
    print(f"FINAL_VERDICT={result['verdict']}")
    print(f"LOGICAL_REQUESTS={len(requests)}")
    print(f"REUSE_COUNTS={reuse['final_reuse_class'].value_counts().sort_index().to_dict() if not reuse.empty else {}}")
    print(f"FULL_TERMINAL={terminal}")
    print(f"FULL_STRICT_VALID={strict}/{planned}")
    print(f"FIGURE_STATUS={result['figure_status']}")
    print(f"VALIDATION_FAILURES={validation.loc[validation['status'].ne('PASS'), 'check_id'].tolist() if not validation.empty else []}")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG_PATH))
    parser.add_argument("--project-root", default=None)
    parser.add_argument("--execute-full", action="store_true")
    parser.add_argument("--allow-api-calls", action="store_true")
    parser.add_argument("--allow-local-ollama", action="store_true")
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--resume-materialized", action="store_true")
    parser.add_argument("--no-write", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    config_path = Path(args.config)
    config = load_config(config_path)
    root = repository_root_from_arg(args.project_root, config)
    try:
        builder = resume_materialized_full_recovery if args.resume_materialized else build_corrected_full_recovery
        result = builder(
            root,
            config_path=config_path,
            write=not args.no_write,
            execute_full=args.execute_full,
            allow_api_calls=args.allow_api_calls,
            allow_local_ollama=args.allow_local_ollama,
            preflight=args.preflight,
        )
    except RQ5CorrectedRecoveryError as exc:
        print(f"RQ5_CORRECTED_FULL_RECOVERY_ERROR={exc}")
        return 2
    print_summary(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
