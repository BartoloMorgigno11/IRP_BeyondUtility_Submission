"""Build the post-hoc RQ5 profile-family statistical audit offline.

This script reads the frozen F6L profile-family outputs, reconstructs paired
user-level utility contributions, and writes only derived audit tables/report
artifacts. It does not call model backends and it does not regenerate figure
images or canonical scientific outputs.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.metrics.canonical_metric_contract import build_metric_registry  # noqa: E402


PHASE_ID = "rq5_profile_scientific_audit"
TOP_K = 5
BOOTSTRAP_RESAMPLES = 10_000
BOOTSTRAP_SEED = 20260901
BOOTSTRAP_CI_LEVEL = 0.95
BOOTSTRAP_QUANTILE_METHOD = "linear"

DATASETS = ["beauty", "sports"]
MODELS = ["qwen2:7b-instruct", "mistral:7b-instruct"]
PROFILE_GENERATORS = ["qwen2:7b-instruct", "mistral:7b-instruct"]
CONDITIONS = ["history_only", "profile_only", "profile_plus_history"]
METRICS = {
    "hr_at_5": "HR@5",
    "ndcg_at_5": "NDCG@5",
}
COMPARISONS = {
    "profile_only_vs_history_only": ("history_only", "profile_only"),
    "profile_plus_history_vs_history_only": ("history_only", "profile_plus_history"),
}
SOURCE_RELS = {
    "parse_results": Path("results/tables/phase_f6l_profile_parse_results.csv"),
    "metrics": Path("results/tables/phase_f6l_profile_metrics.csv"),
    "metric_differences": Path("results/tables/phase_f6l_profile_metric_differences.csv"),
    "recommendation_rows": Path("results/tables/phase_f6l_profile_recommendation_rows.csv"),
    "request_manifest": Path("results/tables/phase_f6l_profile_request_manifest.csv"),
}
OUTPUTS = {
    "paired_contributions": Path("results/tables/rq5_profile_statistical_paired_contributions.csv"),
    "statistical_results": Path("results/tables/rq5_profile_statistical_results.csv"),
    "validation": Path("results/tables/rq5_profile_statistical_validation.csv"),
    "strict_validity_sensitivity": Path("results/tables/rq5_profile_strict_validity_sensitivity.csv"),
    "aplt_audit": Path("results/tables/rq5_aplt_calculability_audit.csv"),
    "serendipity_audit": Path("results/tables/rq5_serendipity_calculability_audit.csv"),
    "paper_figure6_coverage": Path("results/tables/rq5_paper_figure6_metric_coverage.csv"),
    "report": Path("report/rq5_profile_statistical_analysis.md"),
}
PROTECTED_GIT_PATHS = [
    "original_repo",
    "data/raw",
    "paper",
    "configs",
    "results/llm",
    "results/recovery",
    "results/tables/phase_f6l_profile_parse_results.csv",
    "results/tables/phase_f6l_profile_metrics.csv",
    "results/tables/phase_f6l_profile_metric_differences.csv",
    "results/tables/phase_f6l_profile_recommendation_rows.csv",
    "results/tables/phase_f6l_profile_request_manifest.csv",
    "results/tables/reproduction_r5c_profile_conditions_comparison.csv",
    "results/tables/reproduction_r5d_profile_plus_history_results.csv",
]


@dataclass(frozen=True)
class SourcePath:
    rel_path: Path
    path: Path
    scope: str
    sha256: str


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build RQ5 profile-family statistical audit tables.")
    parser.add_argument("--output-root", default=".", help="Project root; defaults to the current working tree.")
    parser.add_argument("--no-write", action="store_true", help="Build and validate without writing outputs.")
    return parser.parse_args(argv)


def repository_root_from_arg(value: str) -> Path:
    root = Path(value).resolve()
    if not (root / "src" / "analysis").exists():
        raise FileNotFoundError(f"Not a project root: {root}")
    return root


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"))


def stable_id(prefix: str, *parts: Any) -> str:
    payload = stable_json([str(part) for part in parts])
    return f"{prefix}-{hashlib.sha256(payload.encode('utf-8')).hexdigest()[:24].upper()}"


def parse_bool(value: Any) -> bool:
    if isinstance(value, (bool, np.bool_)):
        return bool(value)
    if value is None:
        return False
    if isinstance(value, float) and math.isnan(value):
        return False
    text = str(value).strip().lower()
    if text in {"true", "1", "yes", "y", "t"}:
        return True
    if text in {"false", "0", "no", "n", "f", ""}:
        return False
    raise ValueError(f"Unrecognized boolean value: {value!r}")


def format_float(value: Any, digits: int = 12) -> str:
    if value is None:
        return ""
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return str(value)
    if math.isnan(numeric):
        return ""
    return f"{numeric:.{digits}g}"


def source_candidates(root: Path, rel_path: Path) -> list[tuple[Path, str]]:
    candidates: list[tuple[Path, str]] = [(root / rel_path, "local_current_worktree")]
    for sibling in sorted(root.parent.glob("IRP_BeyondUtility*")):
        if sibling.resolve() == root.resolve():
            continue
        candidates.append((sibling / rel_path, "external_read_only"))
    return candidates


def resolve_source(root: Path, rel_path: Path) -> SourcePath:
    searched: list[str] = []
    for path, scope in source_candidates(root, rel_path):
        searched.append(str(path))
        if path.exists():
            return SourcePath(rel_path=rel_path, path=path, scope=scope, sha256=sha256_file(path))
    raise FileNotFoundError(f"Missing required source {rel_path}; searched: {searched}")


def read_source_csv(root: Path, rel_path: Path) -> pd.DataFrame:
    path = resolve_source(root, rel_path).path
    return pd.read_csv(path, dtype=str, keep_default_na=False, low_memory=False)


def source_metadata(root: Path) -> pd.DataFrame:
    rows = []
    for name, rel_path in SOURCE_RELS.items():
        source = resolve_source(root, rel_path)
        rows.append(
            {
                "source_name": name,
                "source_file": source.rel_path.as_posix(),
                "source_path": str(source.path),
                "source_scope": source.scope,
                "source_sha256": source.sha256,
            }
        )
    return pd.DataFrame(rows)


def source_file_string(root: Path, names: Iterable[str]) -> str:
    parts = []
    for name in names:
        source = resolve_source(root, SOURCE_RELS[name])
        parts.append(f"{source.rel_path.as_posix()}[{source.scope}:{source.sha256}]")
    return ";".join(parts)


def load_parse_results(root: Path) -> pd.DataFrame:
    parse = read_source_csv(root, SOURCE_RELS["parse_results"]).copy()
    for column in ["hit_at_5", "ndcg_at_5", "positive_candidate_position"]:
        parse[column] = pd.to_numeric(parse[column], errors="raise")
    parse["strict_valid_bool"] = parse["strict_valid"].map(parse_bool)
    parse["profile_generator_key"] = parse["profile_generator_name"].replace("", "none")
    parse["dataset"] = parse["dataset"].astype(str)
    parse["user_id"] = parse["user_id"].astype(str)
    parse["model_name"] = parse["model_name"].astype(str)
    parse["recommender_model_name"] = parse["recommender_model_name"].astype(str)
    parse["input_variant"] = parse["input_variant"].astype(str)
    return parse


def load_metrics(root: Path) -> pd.DataFrame:
    metrics = read_source_csv(root, SOURCE_RELS["metrics"]).copy()
    metrics["profile_generator"] = metrics["profile_generator"].replace("", "none")
    metrics["value_numeric"] = pd.to_numeric(metrics["value"], errors="coerce")
    metrics["denominator_numeric"] = pd.to_numeric(metrics["denominator"], errors="coerce")
    return metrics


def load_differences(root: Path) -> pd.DataFrame:
    diffs = read_source_csv(root, SOURCE_RELS["metric_differences"]).copy()
    for column in ["baseline_value", "treatment_value", "absolute_difference", "relative_difference", "paired_users"]:
        diffs[f"{column}_numeric"] = pd.to_numeric(diffs[column], errors="coerce")
    return diffs


def group_subset(
    parse: pd.DataFrame,
    *,
    dataset: str,
    recommender: str,
    profile_generator: str,
    condition: str,
) -> pd.DataFrame:
    if condition == "history_only":
        mask = (
            parse["dataset"].eq(dataset)
            & parse["recommender_model_name"].eq(recommender)
            & parse["input_variant"].eq("history_only")
        )
    else:
        mask = (
            parse["dataset"].eq(dataset)
            & parse["recommender_model_name"].eq(recommender)
            & parse["profile_generator_key"].eq(profile_generator)
            & parse["input_variant"].eq(condition)
        )
    subset = parse.loc[mask].copy()
    if subset.empty:
        raise ValueError(f"Missing F6L rows for {dataset}/{recommender}/{profile_generator}/{condition}")
    if subset["user_id"].duplicated().any():
        raise ValueError(f"Duplicate users in {dataset}/{recommender}/{profile_generator}/{condition}")
    return subset


def contribution_value(row: pd.Series, metric: str, *, strict_invalid_zero: bool = False) -> float:
    if strict_invalid_zero and not bool(row["strict_valid_bool"]):
        return 0.0
    if metric == "hr_at_5":
        return float(row["hit_at_5"])
    if metric == "ndcg_at_5":
        return float(row["ndcg_at_5"])
    raise KeyError(metric)


def merge_pair(
    baseline: pd.DataFrame,
    treatment: pd.DataFrame,
    *,
    dataset: str,
    recommender: str,
    profile_generator: str,
    comparison: str,
) -> pd.DataFrame:
    pair_keys = ["user_id", "candidate_list_hash", "positive_item_id", "positive_candidate_position"]
    left_cols = [
        "request_id",
        "user_id",
        "candidate_list_hash",
        "positive_item_id",
        "positive_candidate_position",
        "parser_contract",
        "parser_status",
        "strict_valid_bool",
        "hit_at_5",
        "ndcg_at_5",
        "source_file",
    ]
    right_cols = left_cols.copy()
    joined = baseline[left_cols].merge(
        treatment[right_cols],
        on=pair_keys,
        how="inner",
        validate="one_to_one",
        suffixes=("_baseline", "_treatment"),
    )
    if len(joined) != 200:
        raise ValueError(
            f"Expected 200 paired users for {dataset}/{recommender}/{profile_generator}/{comparison}, found {len(joined)}"
        )
    return joined.sort_values("user_id", kind="mergesort").reset_index(drop=True)


def build_paired_contributions(root: Path) -> pd.DataFrame:
    parse = load_parse_results(root)
    rows: list[dict[str, Any]] = []
    source_file = source_file_string(root, ["parse_results", "metrics", "metric_differences"])
    for dataset in DATASETS:
        for recommender in MODELS:
            for profile_generator in PROFILE_GENERATORS:
                baseline_by_condition = {
                    condition: group_subset(
                        parse,
                        dataset=dataset,
                        recommender=recommender,
                        profile_generator=profile_generator,
                        condition=condition,
                    )
                    for condition in CONDITIONS
                }
                for comparison, (baseline_condition, treatment_condition) in COMPARISONS.items():
                    paired = merge_pair(
                        baseline_by_condition[baseline_condition],
                        baseline_by_condition[treatment_condition],
                        dataset=dataset,
                        recommender=recommender,
                        profile_generator=profile_generator,
                        comparison=comparison,
                    )
                    for _, pair in paired.iterrows():
                        for metric in METRICS:
                            baseline_value = contribution_value(
                                pair.rename(lambda name: name.replace("_baseline", "")),
                                metric,
                            )
                            treatment_value = contribution_value(
                                pair.rename(lambda name: name.replace("_treatment", "")),
                                metric,
                            )
                            baseline_strict_value = 0.0 if not bool(pair["strict_valid_bool_baseline"]) else baseline_value
                            treatment_strict_value = (
                                0.0 if not bool(pair["strict_valid_bool_treatment"]) else treatment_value
                            )
                            rows.append(
                                {
                                    "pair_id": stable_id(
                                        "RQ5PAIR",
                                        dataset,
                                        recommender,
                                        profile_generator,
                                        comparison,
                                        metric,
                                        pair["user_id"],
                                        pair["candidate_list_hash"],
                                    ),
                                    "dataset": dataset,
                                    "user_id": str(pair["user_id"]),
                                    "recommender_model": recommender,
                                    "profile_generator": profile_generator,
                                    "comparison": comparison,
                                    "metric": metric,
                                    "metric_label": METRICS[metric],
                                    "baseline_condition": baseline_condition,
                                    "treatment_condition": treatment_condition,
                                    "baseline_request_id": str(pair["request_id_baseline"]),
                                    "treatment_request_id": str(pair["request_id_treatment"]),
                                    "candidate_list_hash": str(pair["candidate_list_hash"]),
                                    "positive_item_id": str(pair["positive_item_id"]),
                                    "positive_candidate_position": int(pair["positive_candidate_position"]),
                                    "baseline_parser_contract": str(pair["parser_contract_baseline"]),
                                    "treatment_parser_contract": str(pair["parser_contract_treatment"]),
                                    "baseline_parser_status": str(pair["parser_status_baseline"]),
                                    "treatment_parser_status": str(pair["parser_status_treatment"]),
                                    "baseline_strict_valid": bool(pair["strict_valid_bool_baseline"]),
                                    "treatment_strict_valid": bool(pair["strict_valid_bool_treatment"]),
                                    "baseline_value": baseline_value,
                                    "treatment_value": treatment_value,
                                    "paired_delta": treatment_value - baseline_value,
                                    "baseline_strict_invalid_zero_value": baseline_strict_value,
                                    "treatment_strict_invalid_zero_value": treatment_strict_value,
                                    "paired_delta_strict_invalid_zero": treatment_strict_value - baseline_strict_value,
                                    "estimator": "canonical_f6l_fail_strict_parsed_output",
                                    "sensitivity_estimator": "strict_invalid_zero",
                                    "bootstrap_unit": "paired_user",
                                    "source_file": source_file,
                                    "comparison_scope": "matched_f6l_profile_family_experiment",
                                }
                            )
    contributions = pd.DataFrame(rows)
    contributions = contributions.sort_values(
        ["dataset", "recommender_model", "profile_generator", "comparison", "metric", "user_id"],
        kind="mergesort",
    ).reset_index(drop=True)
    return contributions


def paired_bootstrap_mean_delta_ci(
    deltas: Iterable[float],
    *,
    seed: int = BOOTSTRAP_SEED,
    resamples: int = BOOTSTRAP_RESAMPLES,
) -> tuple[float, float, int]:
    arr = np.asarray(list(deltas), dtype=float)
    if arr.size == 0:
        raise ValueError("empty paired delta vector")
    unique, counts = np.unique(arr, return_counts=True)
    if unique.size == 1:
        samples = np.repeat(unique[0], int(resamples))
    else:
        rng = np.random.default_rng(int(seed))
        probabilities = counts.astype(float) / float(arr.size)
        weights = rng.multinomial(int(arr.size), probabilities, size=int(resamples))
        samples = weights @ unique.astype(float) / float(arr.size)
    low, high = np.quantile(samples, [0.025, 0.975], method=BOOTSTRAP_QUANTILE_METHOD)
    return float(low), float(high), int(unique.size)


def ci_decision(ci_low: float, ci_high: float) -> str:
    if ci_low > 0.0:
        return "CI_SUPPORTED_POSITIVE"
    if ci_high < 0.0:
        return "CI_SUPPORTED_NEGATIVE"
    return "NON_SIGNIFICANT_CI_INCLUDES_ZERO"


def sign_label(value: float) -> str:
    if value > 0.0:
        return "positive"
    if value < 0.0:
        return "negative"
    return "zero"


def build_statistical_results(root: Path, contributions: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    source_file = source_file_string(root, ["parse_results", "metrics", "metric_differences"])
    group_cols = ["dataset", "recommender_model", "profile_generator", "comparison", "metric"]
    for key, group in contributions.groupby(group_cols, sort=True):
        dataset, recommender, profile_generator, comparison, metric = key
        deltas = pd.to_numeric(group["paired_delta"], errors="raise").to_numpy(dtype=float)
        ci_low, ci_high, unique_delta_count = paired_bootstrap_mean_delta_ci(deltas)
        ci_low_2, ci_high_2, unique_delta_count_2 = paired_bootstrap_mean_delta_ci(deltas)
        bootstrap_reproducible = (
            ci_low == ci_low_2 and ci_high == ci_high_2 and unique_delta_count == unique_delta_count_2
        )
        rows.append(
            {
                "result_id": stable_id("RQ5STAT", dataset, recommender, profile_generator, comparison, metric),
                "dataset": dataset,
                "recommender_model": recommender,
                "profile_generator": profile_generator,
                "comparison": comparison,
                "metric": metric,
                "metric_label": METRICS[metric],
                "paired_users": int(len(group)),
                "baseline_mean": float(pd.to_numeric(group["baseline_value"], errors="raise").mean()),
                "treatment_mean": float(pd.to_numeric(group["treatment_value"], errors="raise").mean()),
                "mean_delta": float(deltas.mean()),
                "ci_low": ci_low,
                "ci_high": ci_high,
                "ci_level": BOOTSTRAP_CI_LEVEL,
                "primary_ci_decision": ci_decision(ci_low, ci_high),
                "bootstrap_method": "paired_user_bootstrap_mean_delta",
                "bootstrap_unit": "paired_user",
                "bootstrap_resamples": BOOTSTRAP_RESAMPLES,
                "bootstrap_seed": BOOTSTRAP_SEED,
                "bootstrap_quantile_method": BOOTSTRAP_QUANTILE_METHOD,
                "unique_delta_count": unique_delta_count,
                "bootstrap_reproducible": bootstrap_reproducible,
                "p_value": "",
                "significance_test": "not_computed_no_frozen_pvalue_method",
                "multiplicity_correction": "not_computed_no_frozen_pvalue_method",
                "inference_scope": "post_hoc_exploratory_ci_only",
                "estimator": "canonical_f6l_fail_strict_parsed_output",
                "source_file": source_file,
                "notes": "Paired user bootstrap over treatment-minus-baseline contributions; no p-values or Holm correction are fabricated.",
            }
        )
    return pd.DataFrame(rows).sort_values(group_cols, kind="mergesort").reset_index(drop=True)


def build_strict_validity_sensitivity(contributions: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    group_cols = ["dataset", "recommender_model", "profile_generator", "comparison", "metric"]
    for key, group in contributions.groupby(group_cols, sort=True):
        dataset, recommender, profile_generator, comparison, metric = key
        original_delta = float(pd.to_numeric(group["paired_delta"], errors="raise").mean())
        strict_deltas = pd.to_numeric(group["paired_delta_strict_invalid_zero"], errors="raise").to_numpy(dtype=float)
        strict_delta = float(strict_deltas.mean())
        ci_low, ci_high, unique_delta_count = paired_bootstrap_mean_delta_ci(strict_deltas)
        absolute_change = strict_delta - original_delta
        relative_change = "" if original_delta == 0.0 else absolute_change / abs(original_delta)
        original_sign = sign_label(original_delta)
        strict_sign = sign_label(strict_delta)
        rows.append(
            {
                "sensitivity_id": stable_id("RQ5STRICT", dataset, recommender, profile_generator, comparison, metric),
                "dataset": dataset,
                "recommender_model": recommender,
                "profile_generator": profile_generator,
                "comparison": comparison,
                "metric": metric,
                "metric_label": METRICS[metric],
                "paired_users": int(len(group)),
                "original_baseline_mean": float(pd.to_numeric(group["baseline_value"], errors="raise").mean()),
                "original_treatment_mean": float(pd.to_numeric(group["treatment_value"], errors="raise").mean()),
                "strict_baseline_mean": float(
                    pd.to_numeric(group["baseline_strict_invalid_zero_value"], errors="raise").mean()
                ),
                "strict_treatment_mean": float(
                    pd.to_numeric(group["treatment_strict_invalid_zero_value"], errors="raise").mean()
                ),
                "original_value": original_delta,
                "strict_invalid_zero_value": strict_delta,
                "absolute_change": absolute_change,
                "relative_change": relative_change,
                "sign_of_profile_effect_original": original_sign,
                "sign_of_profile_effect_sensitivity": strict_sign,
                "sign_stable": original_sign == strict_sign,
                "strict_ci_low": ci_low,
                "strict_ci_high": ci_high,
                "strict_ci_decision": ci_decision(ci_low, ci_high),
                "bootstrap_method": "paired_user_bootstrap_mean_delta",
                "bootstrap_unit": "paired_user",
                "bootstrap_resamples": BOOTSTRAP_RESAMPLES,
                "bootstrap_seed": BOOTSTRAP_SEED,
                "bootstrap_quantile_method": BOOTSTRAP_QUANTILE_METHOD,
                "unique_delta_count": unique_delta_count,
                "estimator": "strict_invalid_zero",
                "notes": "Separate sensitivity estimator: strict-invalid request contributions are set to zero; canonical F6L values are not modified.",
            }
        )
    return pd.DataFrame(rows).sort_values(group_cols, kind="mergesort").reset_index(drop=True)


def lookup_metric_row(
    metrics: pd.DataFrame,
    *,
    dataset: str,
    recommender: str,
    profile_generator: str,
    condition: str,
    metric: str,
) -> pd.Series:
    source_profile_generator = "none" if condition == "history_only" else profile_generator
    rows = metrics.loc[
        metrics["dataset"].eq(dataset)
        & metrics["recommender_model"].eq(recommender)
        & metrics["profile_generator"].eq(source_profile_generator)
        & metrics["input_variant"].eq(condition)
        & metrics["metric"].eq(METRICS[metric])
    ]
    if len(rows) != 1:
        raise ValueError(f"Expected one metric row, found {len(rows)} for {dataset}/{recommender}/{profile_generator}/{condition}/{metric}")
    return rows.iloc[0]


def condition_metric_reconciliation(root: Path) -> pd.DataFrame:
    parse = load_parse_results(root)
    metrics = load_metrics(root)
    rows: list[dict[str, Any]] = []
    for dataset in DATASETS:
        for recommender in MODELS:
            for profile_generator in PROFILE_GENERATORS:
                for condition in CONDITIONS:
                    subset = group_subset(
                        parse,
                        dataset=dataset,
                        recommender=recommender,
                        profile_generator=profile_generator,
                        condition=condition,
                    )
                    for metric in METRICS:
                        metric_row = lookup_metric_row(
                            metrics,
                            dataset=dataset,
                            recommender=recommender,
                            profile_generator=profile_generator,
                            condition=condition,
                            metric=metric,
                        )
                        column = "hit_at_5" if metric == "hr_at_5" else "ndcg_at_5"
                        computed = float(pd.to_numeric(subset[column], errors="raise").mean())
                        source = float(metric_row["value_numeric"])
                        rows.append(
                            {
                                "dataset": dataset,
                                "recommender_model": recommender,
                                "profile_generator": profile_generator,
                                "condition": condition,
                                "metric": metric,
                                "computed_mean_from_parse": computed,
                                "frozen_metric_value": source,
                                "abs_delta": abs(computed - source),
                                "paired_users": int(len(subset)),
                            }
                        )
    return pd.DataFrame(rows)


def delta_reconciliation(root: Path, statistical_results: pd.DataFrame) -> pd.DataFrame:
    diffs = load_differences(root)
    diffs = diffs.loc[diffs["comparison"].isin(COMPARISONS)].copy()
    rows: list[dict[str, Any]] = []
    for stat in statistical_results.itertuples(index=False):
        source = diffs.loc[
            diffs["dataset"].eq(stat.dataset)
            & diffs["profile_generator"].eq(stat.profile_generator)
            & diffs["recommender_model"].eq(stat.recommender_model)
            & diffs["comparison"].eq(stat.comparison)
            & diffs["metric"].eq(METRICS[stat.metric])
        ]
        if len(source) != 1:
            raise ValueError(
                f"Expected one difference row, found {len(source)} for "
                f"{stat.dataset}/{stat.recommender_model}/{stat.profile_generator}/{stat.comparison}/{stat.metric}"
            )
        source_row = source.iloc[0]
        rows.append(
            {
                "dataset": stat.dataset,
                "recommender_model": stat.recommender_model,
                "profile_generator": stat.profile_generator,
                "comparison": stat.comparison,
                "metric": stat.metric,
                "computed_mean_delta": float(stat.mean_delta),
                "frozen_absolute_difference": float(source_row["absolute_difference_numeric"]),
                "abs_delta": abs(float(stat.mean_delta) - float(source_row["absolute_difference_numeric"])),
                "paired_users": int(stat.paired_users),
                "source_paired_users": int(float(source_row["paired_users_numeric"])),
            }
        )
    return pd.DataFrame(rows)


def detect_file(root: Path, rel_path: str) -> tuple[bool, str, str]:
    try:
        source = resolve_source(root, Path(rel_path))
    except FileNotFoundError:
        return False, rel_path, ""
    return True, source.rel_path.as_posix(), source.scope


def apl_t_contract_summary() -> Mapping[str, str]:
    registry = {contract.metric_id: contract for contract in build_metric_registry()}
    contract = registry["long_tail_rate_at_5"]
    return {
        "local_metric": contract.metric_id,
        "display_name": "APLT@5 / " + contract.display_name,
        "formula": contract.mathematical_formula,
        "popularity_source_policy": contract.popularity_source_policy,
        "long_tail_policy": contract.long_tail_policy,
        "local_code_source": contract.local_code_source + "; src/extension/f1a_offline_metric_closure.py:long_tail_rate_at_k",
        "paper_alignment": contract.paper_alignment,
    }


def build_aplt_calculability_audit(root: Path) -> pd.DataFrame:
    contract = apl_t_contract_summary()
    metrics = load_metrics(root)
    apl_t_rows = metrics.loc[metrics["metric"].eq("APLT")].copy()
    f6l_statuses = sorted(set(apl_t_rows["status"].astype(str)))
    f6l_notes = sorted(set(apl_t_rows["notes"].astype(str)))
    files = {
        "f6l_top5_recommendation_lists": "results/tables/phase_f6l_profile_recommendation_rows.csv",
        "f6l_parse_results": "results/tables/phase_f6l_profile_parse_results.csv",
        "f6l_request_manifest": "results/tables/phase_f6l_profile_request_manifest.csv",
        "candidate_popularity_audit": "results/tables/canonical_metric_popularity_input_audit.csv",
        "candidate_f5c_policy": "results/tables/finalization_f5c_item_popularity_policy.csv",
        "candidate_f6f_popularity": "results/tables/phase_f6f1_popularity_novelty_results.csv",
    }
    detected = {name: detect_file(root, rel_path) for name, rel_path in files.items()}
    rows = [
        {
            "requirement": "metric_contract",
            "required_input": "APLT contract and threshold semantics",
            "status": "AVAILABLE",
            "available_source": contract["local_code_source"],
            "exactness": "EXACT_LOCAL_CONTRACT",
            "blocking_reason": "",
            "notes": (
                f"{contract['formula']}; {contract['popularity_source_policy']}; "
                f"{contract['long_tail_policy']}"
            ),
        },
        {
            "requirement": "f6l_top5_lists",
            "required_input": "F6L top-5 recommendation item ids for every condition/user",
            "status": "AVAILABLE",
            "available_source": files["f6l_top5_recommendation_lists"],
            "exactness": "MATCHED_F6L_SOURCE",
            "blocking_reason": "",
            "notes": "Top-5 rows are present as parsed recommendation rows.",
        },
        {
            "requirement": "train_popularity_counts",
            "required_input": "train-only raw interaction counts for the exact F6L train split",
            "status": "BLOCKED_MISSING_F6L_TRAIN_POPULARITY",
            "available_source": ";".join(
                source for _, source, scope in [detected["candidate_popularity_audit"], detected["candidate_f5c_policy"]] if source
            ),
            "exactness": "MISMATCHED_OR_UNPROVEN_F6L_TRAIN_SPLIT",
            "blocking_reason": "F6L metrics table freezes APLT as unsupported_missing_train_popularity.",
            "notes": f"F6L APLT statuses: {','.join(f6l_statuses)}; notes: {' | '.join(f6l_notes)}",
        },
        {
            "requirement": "long_tail_threshold",
            "required_input": "strict less-than 80th percentile threshold from exact F6L train counts",
            "status": "BLOCKED_DEPENDS_ON_MISSING_F6L_TRAIN_POPULARITY",
            "available_source": files["candidate_f5c_policy"] if detected["candidate_f5c_policy"][0] else "",
            "exactness": "MISMATCHED_OR_UNPROVEN_F6L_TRAIN_SPLIT",
            "blocking_reason": "F5C/other popularity policies are not proven to be the exact F6L profile-family train universe.",
            "notes": "No threshold is computed for RQ5 F6L to avoid cross-protocol substitution.",
        },
        {
            "requirement": "denominator_policy",
            "required_input": "top-5 positions over matched profile-family rows with invalid handling declared",
            "status": "AVAILABLE",
            "available_source": "results/tables/phase_f6l_profile_metrics.csv",
            "exactness": "MATCHED_F6L_DENOMINATOR_FOR_UTILITY_ONLY",
            "blocking_reason": "",
            "notes": "Utility denominator is frozen at 200 users per cell; APLT remains unsupported in F6L.",
        },
        {
            "requirement": "overall_decision",
            "required_input": "all APLT primitives jointly available and aligned",
            "status": "BLOCKED_MISSING_F6L_TRAIN_POPULARITY",
            "available_source": "",
            "exactness": "NOT_CALCULABLE_WITHOUT_UNPROVEN_SUBSTITUTION",
            "blocking_reason": "Exact train popularity source and q80 threshold for F6L profile-family execution are not frozen.",
            "notes": "No RQ5 APLT result table is generated.",
        },
    ]
    return pd.DataFrame(rows)


def build_serendipity_calculability_audit(root: Path) -> pd.DataFrame:
    files = {
        "f6l_parse_results": "results/tables/phase_f6l_profile_parse_results.csv",
        "f6l_request_manifest": "results/tables/phase_f6l_profile_request_manifest.csv",
        "f6l_recommendation_rows": "results/tables/phase_f6l_profile_recommendation_rows.csv",
        "f1bx_mostpop_recommendations": "results/raw_outputs/f1bx_baseline_recommendations.csv",
        "audit_figure2_serendipity_cells": "results/tables/audit_figure2_serendipity_cells.csv",
    }
    detected = {name: detect_file(root, rel_path) for name, rel_path in files.items()}
    candidate_sources = [
        files["f1bx_mostpop_recommendations"] if detected["f1bx_mostpop_recommendations"][0] else "",
        files["audit_figure2_serendipity_cells"] if detected["audit_figure2_serendipity_cells"][0] else "",
    ]
    candidate_sources = [source for source in candidate_sources if source]
    rows = [
        {
            "requirement": "metric_contract",
            "required_input": "mean(llm_hit_at_5 * (1 - mostpop_hit_at_5)) over matched users",
            "status": "AVAILABLE",
            "available_source": "src/analysis/audit_figure2_reconstruction.py; src/analysis/g1_serendipity_bugfix.py",
            "exactness": "EXACT_LOCAL_FORMULA",
            "blocking_reason": "",
            "notes": "Formula is known; the missing primitive is an aligned MostPop hit for the F6L candidate universe.",
        },
        {
            "requirement": "f6l_llm_hits",
            "required_input": "F6L per-user HR@5 hits for history/profile/profile+history",
            "status": "AVAILABLE",
            "available_source": files["f6l_parse_results"],
            "exactness": "MATCHED_F6L_SOURCE",
            "blocking_reason": "",
            "notes": "F6L hit_at_5 is available for every matched utility row.",
        },
        {
            "requirement": "aligned_mostpop_hit",
            "required_input": "MostPop hit_at_5 trained/evaluated on the same F6L train data, users, and candidate lists",
            "status": "BLOCKED_MISSING_ALIGNED_MOSTPOP",
            "available_source": ";".join(candidate_sources),
            "exactness": "MISMATCHED_OR_UNPROVEN_F6L_CANDIDATE_UNIVERSE",
            "blocking_reason": "Candidate MostPop artifacts are from F1BX/G1-style protocols, not frozen F6L profile-family candidate rows.",
            "notes": "No F6L-aligned MostPop primitive is present in the profile metrics, parse results, or request manifest.",
        },
        {
            "requirement": "candidate_alignment",
            "required_input": "MostPop candidate list hash equals F6L candidate_list_hash for each user",
            "status": "BLOCKED_MISSING_ALIGNED_MOSTPOP",
            "available_source": ";".join(candidate_sources),
            "exactness": "UNPROVEN_HASH_ALIGNMENT",
            "blocking_reason": "No one-to-one F6L candidate hash join key is available for the candidate MostPop sources.",
            "notes": "Cross-protocol substitution would risk fabricating serendipity.",
        },
        {
            "requirement": "overall_decision",
            "required_input": "all serendipity primitives jointly available and aligned",
            "status": "BLOCKED_MISSING_ALIGNED_MOSTPOP",
            "available_source": "",
            "exactness": "NOT_CALCULABLE_WITHOUT_UNPROVEN_SUBSTITUTION",
            "blocking_reason": "Aligned MostPop hit primitive is absent for the F6L profile-family universe.",
            "notes": "No RQ5 serendipity result table is generated.",
        },
    ]
    return pd.DataFrame(rows)


def build_paper_figure6_coverage(
    apl_t_audit: pd.DataFrame,
    ser_audit: pd.DataFrame,
) -> pd.DataFrame:
    apl_t_status = str(apl_t_audit.loc[apl_t_audit["requirement"].eq("overall_decision"), "status"].iloc[0])
    apl_t_reason = str(apl_t_audit.loc[apl_t_audit["requirement"].eq("overall_decision"), "blocking_reason"].iloc[0])
    ser_status = str(ser_audit.loc[ser_audit["requirement"].eq("overall_decision"), "status"].iloc[0])
    ser_reason = str(ser_audit.loc[ser_audit["requirement"].eq("overall_decision"), "blocking_reason"].iloc[0])
    return pd.DataFrame(
        [
            {
                "paper_metric": "HR@5",
                "local_metric": "hr_at_5",
                "matched_f6l_available": True,
                "exactness_class": "MATCHED_F6L_FAIL_STRICT_PARSED_OUTPUT_ESTIMATOR",
                "source": "results/tables/phase_f6l_profile_parse_results.csv;results/tables/phase_f6l_profile_metrics.csv",
                "can_plot": True,
                "scientific_limitation": "Post-hoc CI only; low strict validity remains a limitation.",
            },
            {
                "paper_metric": "NDCG@5",
                "local_metric": "ndcg_at_5",
                "matched_f6l_available": True,
                "exactness_class": "MATCHED_F6L_FAIL_STRICT_PARSED_OUTPUT_ESTIMATOR",
                "source": "results/tables/phase_f6l_profile_parse_results.csv;results/tables/phase_f6l_profile_metrics.csv",
                "can_plot": True,
                "scientific_limitation": "Post-hoc CI only; low strict validity remains a limitation.",
            },
            {
                "paper_metric": "APLT@5 / Popularity",
                "local_metric": "long_tail_rate_at_5",
                "matched_f6l_available": False,
                "exactness_class": apl_t_status,
                "source": "results/tables/rq5_aplt_calculability_audit.csv",
                "can_plot": False,
                "scientific_limitation": apl_t_reason,
            },
            {
                "paper_metric": "Serendipity@5",
                "local_metric": "serendipity_at_5",
                "matched_f6l_available": False,
                "exactness_class": ser_status,
                "source": "results/tables/rq5_serendipity_calculability_audit.csv",
                "can_plot": False,
                "scientific_limitation": ser_reason,
            },
        ]
    )


def protected_git_diff(root: Path) -> list[str]:
    command = ["git", "diff", "--name-only", "--", *PROTECTED_GIT_PATHS]
    result = subprocess.run(command, cwd=root, check=True, capture_output=True, text=True)
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def add_validation(
    rows: list[dict[str, Any]],
    check_id: str,
    passed: bool,
    expected: Any,
    observed: Any,
    details: str = "",
    *,
    max_abs_delta: Any = "",
) -> None:
    rows.append(
        {
            "check_id": check_id,
            "status": "PASS" if passed else "FAIL",
            "expected": str(expected),
            "observed": str(observed),
            "max_abs_delta": max_abs_delta,
            "details": details,
        }
    )


def build_validation(
    root: Path,
    contributions: pd.DataFrame,
    stats: pd.DataFrame,
    strict: pd.DataFrame,
    apl_t: pd.DataFrame,
    ser: pd.DataFrame,
    coverage: pd.DataFrame,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    group_cols = ["dataset", "recommender_model", "profile_generator", "comparison", "metric"]
    trajectory_cols = ["dataset", "recommender_model", "profile_generator"]
    metric_recon = condition_metric_reconciliation(root)
    delta_recon = delta_reconciliation(root, stats)
    protected = protected_git_diff(root)
    row_source_delta = max(
        float(
            (
                pd.to_numeric(contributions["treatment_value"], errors="raise")
                - pd.to_numeric(contributions["baseline_value"], errors="raise")
                - pd.to_numeric(contributions["paired_delta"], errors="raise")
            )
            .abs()
            .max()
        ),
        float(
            (
                pd.to_numeric(contributions["treatment_strict_invalid_zero_value"], errors="raise")
                - pd.to_numeric(contributions["baseline_strict_invalid_zero_value"], errors="raise")
                - pd.to_numeric(contributions["paired_delta_strict_invalid_zero"], errors="raise")
            )
            .abs()
            .max()
        ),
    )
    group_sizes = contributions.groupby(group_cols, sort=False).size()
    add_validation(
        rows,
        "RQ5-STATISTICAL-MATCHED-TRAJECTORIES",
        contributions.drop_duplicates(trajectory_cols).shape[0] == 8,
        "8 matched trajectories",
        contributions.drop_duplicates(trajectory_cols).shape[0],
    )
    add_validation(
        rows,
        "RQ5-STATISTICAL-PRIMARY-UTILITY-COMPARISONS",
        len(stats) == 32,
        "32 comparisons",
        len(stats),
    )
    add_validation(
        rows,
        "RQ5-STATISTICAL-EVERY-COMPARISON-200-PAIRED-USERS",
        bool(group_sizes.eq(200).all()),
        "all 32 groups have 200 paired users",
        group_sizes.value_counts().to_dict(),
    )
    add_validation(
        rows,
        "RQ5-STATISTICAL-ROW-LEVEL-DELTA-IDENTITY",
        row_source_delta == 0.0,
        "0.0",
        row_source_delta,
        "Row-level deltas are exact treatment-minus-baseline arithmetic from copied F6L contributions.",
        max_abs_delta=row_source_delta,
    )
    metric_max = float(metric_recon["abs_delta"].max())
    add_validation(
        rows,
        "RQ5-STATISTICAL-AGGREGATE-MEANS-REPRODUCE-F6L-METRICS",
        metric_max <= 5.1e-7,
        "<= 5.1e-7 source precision",
        metric_max,
        "F6L metrics are stored to six decimals.",
        max_abs_delta=metric_max,
    )
    delta_max = float(delta_recon["abs_delta"].max())
    add_validation(
        rows,
        "RQ5-STATISTICAL-AGGREGATE-DELTAS-REPRODUCE-F6L-DIFFERENCES",
        delta_max <= 1.1e-6,
        "<= 1.1e-6 documented rounding tolerance",
        delta_max,
        "Frozen differences table is six-decimal rounded.",
        max_abs_delta=delta_max,
    )
    add_validation(
        rows,
        "RQ5-STATISTICAL-BOOTSTRAP-PAIRED-USERS",
        set(stats["bootstrap_unit"]) == {"paired_user"} and set(stats["bootstrap_method"]) == {"paired_user_bootstrap_mean_delta"},
        "paired_user bootstrap",
        f"{sorted(set(stats['bootstrap_method']))}/{sorted(set(stats['bootstrap_unit']))}",
    )
    settings_pass = (
        pd.to_numeric(stats["bootstrap_resamples"], errors="raise").eq(BOOTSTRAP_RESAMPLES).all()
        and pd.to_numeric(stats["bootstrap_seed"], errors="raise").eq(BOOTSTRAP_SEED).all()
        and set(stats["bootstrap_quantile_method"]) == {BOOTSTRAP_QUANTILE_METHOD}
        and pd.to_numeric(stats["ci_level"], errors="raise").eq(BOOTSTRAP_CI_LEVEL).all()
    )
    add_validation(
        rows,
        "RQ5-STATISTICAL-BOOTSTRAP-SETTINGS-EXACT",
        bool(settings_pass),
        f"resamples={BOOTSTRAP_RESAMPLES};seed={BOOTSTRAP_SEED};ci=0.95;quantile=linear",
        "settings recorded in statistical results",
    )
    add_validation(
        rows,
        "RQ5-STATISTICAL-BOOTSTRAP-DETERMINISTIC-REPRODUCIBILITY",
        stats["bootstrap_reproducible"].astype(bool).all(),
        "all true",
        stats["bootstrap_reproducible"].value_counts().to_dict(),
    )
    add_validation(
        rows,
        "RQ5-STATISTICAL-NO-P-VALUES-FABRICATED",
        stats["p_value"].fillna("").eq("").all()
        and set(stats["significance_test"]) == {"not_computed_no_frozen_pvalue_method"},
        "no p-values",
        f"p_value_nonempty={(~stats['p_value'].fillna('').eq('')).sum()}",
    )
    add_validation(
        rows,
        "RQ5-STRICT-INVALID-ZERO-SEPARATE-SENSITIVITY",
        len(strict) == 32 and set(strict["estimator"]) == {"strict_invalid_zero"},
        "32 separate strict-invalid-zero rows",
        f"rows={len(strict)}; estimators={sorted(set(strict['estimator']))}",
    )
    apl_t_blocked = str(apl_t.loc[apl_t["requirement"].eq("overall_decision"), "status"].iloc[0]).startswith("BLOCKED")
    add_validation(
        rows,
        "RQ5-APLT-ONLY-PROVEN-TRAIN-POPULARITY-SOURCE",
        apl_t_blocked and not (root / "results/tables/rq5_profile_aplt_results.csv").exists(),
        "blocked without exact F6L train popularity; no result table",
        str(apl_t.loc[apl_t["requirement"].eq("overall_decision"), "status"].iloc[0]),
    )
    ser_blocked = str(ser.loc[ser["requirement"].eq("overall_decision"), "status"].iloc[0]).startswith("BLOCKED")
    add_validation(
        rows,
        "RQ5-SERENDIPITY-ONLY-ALIGNED-MOSTPOP-HITS",
        ser_blocked and not (root / "results/tables/rq5_profile_serendipity_results.csv").exists(),
        "blocked without aligned MostPop primitive; no result table",
        str(ser.loc[ser["requirement"].eq("overall_decision"), "status"].iloc[0]),
    )
    combined_sources = " ".join(contributions["source_file"].astype(str).tolist() + stats["source_file"].astype(str).tolist())
    add_validation(
        rows,
        "RQ5-NO-CROSS-PROTOCOL-R5C-R5D-DELTAS",
        "reproduction_r5c" not in combined_sources.lower() and "reproduction_r5d" not in combined_sources.lower(),
        "no R5C/R5D source in paired deltas",
        "R5C/R5D absent" if "reproduction_r5" not in combined_sources.lower() else "R5 source present",
    )
    add_validation(
        rows,
        "RQ5-NO-OLLAMA-API",
        True,
        "offline-only audit",
        "no model backend/API function is invoked by this script",
    )
    add_validation(
        rows,
        "RQ5-PAPER-FIGURE6-COVERAGE-TWO-METRIC-ANALOGUE",
        coverage["can_plot"].astype(bool).sum() == 2,
        "HR/NDCG can_plot; APLT/Serendipity blocked",
        coverage[["paper_metric", "can_plot"]].to_dict("records"),
    )
    add_validation(
        rows,
        "RQ5-PROTECTED-SCIENTIFIC-FILES-UNTOUCHED",
        len(protected) == 0,
        "no git diff in protected scientific paths",
        ";".join(protected),
    )
    return pd.DataFrame(rows)


def decision_counts(stats: pd.DataFrame) -> pd.DataFrame:
    return (
        stats.groupby(["metric", "primary_ci_decision"], as_index=False)
        .size()
        .rename(columns={"size": "count"})
        .sort_values(["metric", "primary_ci_decision"], kind="mergesort")
    )


def sensitivity_counts(strict: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": int(len(strict)),
        "sign_stable": int(strict["sign_stable"].astype(bool).sum()),
        "sign_changed": int((~strict["sign_stable"].astype(bool)).sum()),
        "decision_counts": strict["strict_ci_decision"].value_counts().sort_index().to_dict(),
    }


def render_report(
    root: Path,
    sources: pd.DataFrame,
    contributions: pd.DataFrame,
    stats: pd.DataFrame,
    strict: pd.DataFrame,
    apl_t: pd.DataFrame,
    ser: pd.DataFrame,
    coverage: pd.DataFrame,
    validation: pd.DataFrame,
) -> str:
    counts = decision_counts(stats)
    strict_summary = sensitivity_counts(strict)
    source_lines = [
        f"- `{row.source_file}` ({row.source_scope}, sha256 `{row.source_sha256}`)"
        for row in sources.itertuples(index=False)
    ]
    count_lines = [
        f"- {row.metric} / {row.primary_ci_decision}: {int(row.count)}"
        for row in counts.itertuples(index=False)
    ]
    coverage_lines = [
        f"- {row.paper_metric}: can_plot={bool(row.can_plot)}; {row.exactness_class}"
        for row in coverage.itertuples(index=False)
    ]
    validation_failures = validation.loc[validation["status"].ne("PASS"), "check_id"].tolist()
    return "\n".join(
        [
            "# RQ5 Profile Statistical Analysis",
            "",
            "This audit is post-hoc and exploratory. It reconstructs paired user-level HR@5 and NDCG@5 contributions from the matched F6L profile-family outputs. No p-values, Holm correction, API calls, or new model outputs are produced.",
            "",
            "## Sources",
            *source_lines,
            "",
            "## Statistical Universe",
            f"- Matched trajectories: {contributions.drop_duplicates(['dataset', 'recommender_model', 'profile_generator']).shape[0]}",
            f"- Primary utility comparisons: {len(stats)}",
            "- Paired users per comparison: 200",
            "- Bootstrap: paired_user_bootstrap_mean_delta, 10000 resamples, seed 20260901, two-sided 95 percent percentile CI, numpy linear quantile.",
            "",
            "## CI Decisions",
            *count_lines,
            "",
            "## Strict-Validity Sensitivity",
            f"- Rows: {strict_summary['rows']}",
            f"- Sign stable: {strict_summary['sign_stable']}",
            f"- Sign changed: {strict_summary['sign_changed']}",
            f"- Strict CI decisions: {strict_summary['decision_counts']}",
            "",
            "## APLT Calculability",
            f"- Overall status: {apl_t.loc[apl_t['requirement'].eq('overall_decision'), 'status'].iloc[0]}",
            f"- Reason: {apl_t.loc[apl_t['requirement'].eq('overall_decision'), 'blocking_reason'].iloc[0]}",
            "",
            "## Serendipity Calculability",
            f"- Overall status: {ser.loc[ser['requirement'].eq('overall_decision'), 'status'].iloc[0]}",
            f"- Reason: {ser.loc[ser['requirement'].eq('overall_decision'), 'blocking_reason'].iloc[0]}",
            "",
            "## Paper Figure 6 Coverage",
            *coverage_lines,
            "",
            "## Recommendation",
            "Retain the current two-metric RQ5 Figure 6 analogue for HR@5/NDCG@5. If markers are later added to the delta heatmap, use CI markers derived from this audit (+, -, o) and keep APLT/Serendipity out until their primitives are proven aligned.",
            "",
            "## Validation",
            f"- Checks: {len(validation)}",
            f"- Failures: {validation_failures}",
            "",
            f"Generated by `{PHASE_ID}` in `{root}`.",
            "",
        ]
    )


def build_outputs(root: Path) -> Mapping[str, pd.DataFrame | str]:
    sources = source_metadata(root)
    contributions = build_paired_contributions(root)
    stats = build_statistical_results(root, contributions)
    strict = build_strict_validity_sensitivity(contributions)
    apl_t = build_aplt_calculability_audit(root)
    ser = build_serendipity_calculability_audit(root)
    coverage = build_paper_figure6_coverage(apl_t, ser)
    validation = build_validation(root, contributions, stats, strict, apl_t, ser, coverage)
    report = render_report(root, sources, contributions, stats, strict, apl_t, ser, coverage, validation)
    return {
        "sources": sources,
        "paired_contributions": contributions,
        "statistical_results": stats,
        "strict_validity_sensitivity": strict,
        "aplt_audit": apl_t,
        "serendipity_audit": ser,
        "paper_figure6_coverage": coverage,
        "validation": validation,
        "report": report,
    }


def write_outputs(root: Path, outputs: Mapping[str, pd.DataFrame | str]) -> None:
    for key, path in OUTPUTS.items():
        target = root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        if key == "report":
            value = outputs[key]
            if not isinstance(value, str):
                raise TypeError("report output is not text")
            target.write_text(value, encoding="utf-8")
        else:
            value = outputs[key]
            if not isinstance(value, pd.DataFrame):
                raise TypeError(f"{key} output is not a DataFrame")
            value.to_csv(target, index=False, lineterminator="\n")


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    root = repository_root_from_arg(args.output_root)
    outputs = build_outputs(root)
    validation = outputs["validation"]
    if not isinstance(validation, pd.DataFrame):
        raise TypeError("validation output is not a DataFrame")
    if not args.no_write:
        write_outputs(root, outputs)
    failures = validation.loc[validation["status"].ne("PASS"), "check_id"].tolist()
    if failures:
        print(f"{PHASE_ID}: validation failed: {failures}")
        return 1
    stats = outputs["statistical_results"]
    if not isinstance(stats, pd.DataFrame):
        raise TypeError("statistical_results output is not a DataFrame")
    coverage = outputs["paper_figure6_coverage"]
    if not isinstance(coverage, pd.DataFrame):
        raise TypeError("paper_figure6_coverage output is not a DataFrame")
    print(f"{PHASE_ID}: wrote={not args.no_write}")
    print(f"paired_contribution_rows={len(outputs['paired_contributions'])}")
    print(f"statistical_comparisons={len(stats)}")
    print(f"can_plot_metrics={int(coverage['can_plot'].astype(bool).sum())}")
    print("verdict=RQ5_TWO_METRIC_ANALOGUE_ONLY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
