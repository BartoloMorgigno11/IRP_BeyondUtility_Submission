from __future__ import annotations

from pathlib import Path
import subprocess

import numpy as np
import pandas as pd

from src.analysis.rq5_profile_scientific_audit import (
    BOOTSTRAP_QUANTILE_METHOD,
    BOOTSTRAP_RESAMPLES,
    BOOTSTRAP_SEED,
    PROTECTED_GIT_PATHS,
    paired_bootstrap_mean_delta_ci,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
TABLES = PROJECT_ROOT / "results" / "tables"


def table(name: str, **kwargs) -> pd.DataFrame:
    return pd.read_csv(TABLES / name, **kwargs)


def test_rq5_statistical_universe_and_pairing_contract() -> None:
    rows = table("rq5_profile_statistical_paired_contributions.csv")
    group_cols = ["dataset", "recommender_model", "profile_generator", "comparison", "metric"]

    assert len(rows) == 6400
    assert rows["pair_id"].is_unique
    assert rows.drop_duplicates(["dataset", "recommender_model", "profile_generator"]).shape[0] == 8
    assert rows.drop_duplicates(group_cols).shape[0] == 32
    assert rows.groupby(group_cols).size().eq(200).all()
    assert set(rows["comparison"]) == {"profile_only_vs_history_only", "profile_plus_history_vs_history_only"}
    assert set(rows["metric"]) == {"hr_at_5", "ndcg_at_5"}
    assert set(rows["bootstrap_unit"]) == {"paired_user"}
    assert not rows["source_file"].str.contains("reproduction_r5c|reproduction_r5d", case=False, regex=True).any()


def test_rq5_statistical_results_bootstrap_contract_and_ci_counts() -> None:
    stats = table("rq5_profile_statistical_results.csv", keep_default_na=False)

    assert len(stats) == 32
    assert pd.to_numeric(stats["paired_users"], errors="raise").eq(200).all()
    assert set(stats["bootstrap_method"]) == {"paired_user_bootstrap_mean_delta"}
    assert set(stats["bootstrap_unit"]) == {"paired_user"}
    assert pd.to_numeric(stats["bootstrap_resamples"], errors="raise").eq(BOOTSTRAP_RESAMPLES).all()
    assert pd.to_numeric(stats["bootstrap_seed"], errors="raise").eq(BOOTSTRAP_SEED).all()
    assert set(stats["bootstrap_quantile_method"]) == {BOOTSTRAP_QUANTILE_METHOD}
    assert pd.to_numeric(stats["ci_level"], errors="raise").eq(0.95).all()
    assert stats["bootstrap_reproducible"].astype(str).str.lower().eq("true").all()
    assert stats["p_value"].eq("").all()
    assert set(stats["significance_test"]) == {"not_computed_no_frozen_pvalue_method"}
    assert set(stats["inference_scope"]) == {"post_hoc_exploratory_ci_only"}
    assert stats.groupby(["metric", "primary_ci_decision"]).size().to_dict() == {
        ("hr_at_5", "CI_SUPPORTED_NEGATIVE"): 5,
        ("hr_at_5", "NON_SIGNIFICANT_CI_INCLUDES_ZERO"): 11,
        ("ndcg_at_5", "CI_SUPPORTED_NEGATIVE"): 8,
        ("ndcg_at_5", "NON_SIGNIFICANT_CI_INCLUDES_ZERO"): 8,
    }


def test_rq5_bootstrap_recomputes_deterministically_from_paired_users() -> None:
    rows = table("rq5_profile_statistical_paired_contributions.csv")
    stats = table("rq5_profile_statistical_results.csv")
    first = stats.sort_values(["dataset", "recommender_model", "profile_generator", "comparison", "metric"]).iloc[0]
    subset = rows[
        rows["dataset"].eq(first["dataset"])
        & rows["recommender_model"].eq(first["recommender_model"])
        & rows["profile_generator"].eq(first["profile_generator"])
        & rows["comparison"].eq(first["comparison"])
        & rows["metric"].eq(first["metric"])
    ]
    deltas = pd.to_numeric(subset["paired_delta"], errors="raise").to_numpy(dtype=float)

    ci_a = paired_bootstrap_mean_delta_ci(deltas)
    ci_b = paired_bootstrap_mean_delta_ci(deltas)

    assert ci_a == ci_b
    assert ci_a[0] == float(first["ci_low"])
    assert ci_a[1] == float(first["ci_high"])
    assert ci_a[2] == int(first["unique_delta_count"])
    assert float(first["mean_delta"]) == np.mean(deltas)


def test_rq5_strict_validity_sensitivity_is_separate() -> None:
    strict = table("rq5_profile_strict_validity_sensitivity.csv", keep_default_na=False)

    assert len(strict) == 32
    assert set(strict["estimator"]) == {"strict_invalid_zero"}
    assert pd.to_numeric(strict["paired_users"], errors="raise").eq(200).all()
    assert pd.to_numeric(strict["bootstrap_resamples"], errors="raise").eq(BOOTSTRAP_RESAMPLES).all()
    assert pd.to_numeric(strict["bootstrap_seed"], errors="raise").eq(BOOTSTRAP_SEED).all()
    assert set(strict["bootstrap_quantile_method"]) == {BOOTSTRAP_QUANTILE_METHOD}
    assert set(strict["strict_ci_decision"]) == {"NON_SIGNIFICANT_CI_INCLUDES_ZERO"}
    assert strict["sign_stable"].astype(str).str.lower().value_counts().to_dict() == {"false": 21, "true": 11}
    assert (
        pd.to_numeric(strict["original_value"], errors="raise")
        - pd.to_numeric(strict["strict_invalid_zero_value"], errors="raise")
    ).abs().gt(0).any()


def test_rq5_aplt_and_serendipity_are_blocked_without_unproven_tables() -> None:
    apl_t = table("rq5_aplt_calculability_audit.csv")
    ser = table("rq5_serendipity_calculability_audit.csv")
    coverage = table("rq5_paper_figure6_metric_coverage.csv")

    assert apl_t.loc[apl_t["requirement"].eq("overall_decision"), "status"].iloc[0] == (
        "BLOCKED_MISSING_F6L_TRAIN_POPULARITY"
    )
    assert ser.loc[ser["requirement"].eq("overall_decision"), "status"].iloc[0] == "BLOCKED_MISSING_ALIGNED_MOSTPOP"
    assert not (TABLES / "rq5_profile_aplt_results.csv").exists()
    assert not (TABLES / "rq5_profile_serendipity_results.csv").exists()

    by_metric = coverage.set_index("paper_metric")
    assert by_metric.loc["HR@5", "can_plot"].astype(bool)
    assert by_metric.loc["NDCG@5", "can_plot"].astype(bool)
    assert by_metric.loc["APLT@5 / Popularity", "exactness_class"] == "BLOCKED_MISSING_F6L_TRAIN_POPULARITY"
    assert by_metric.loc["Serendipity@5", "exactness_class"] == "BLOCKED_MISSING_ALIGNED_MOSTPOP"
    assert by_metric["can_plot"].astype(bool).sum() == 2


def test_rq5_statistical_validation_passes_numeric_reconciliation() -> None:
    validation = table("rq5_profile_statistical_validation.csv", keep_default_na=False)

    assert len(validation) == 17
    assert validation["status"].eq("PASS").all()
    by_check = validation.set_index("check_id")
    assert float(by_check.loc["RQ5-STATISTICAL-ROW-LEVEL-DELTA-IDENTITY", "max_abs_delta"]) == 0.0
    assert float(by_check.loc["RQ5-STATISTICAL-AGGREGATE-MEANS-REPRODUCE-F6L-METRICS", "max_abs_delta"]) <= 5.1e-7
    assert float(by_check.loc["RQ5-STATISTICAL-AGGREGATE-DELTAS-REPRODUCE-F6L-DIFFERENCES", "max_abs_delta"]) <= 1.1e-6
    assert by_check.loc["RQ5-PROTECTED-SCIENTIFIC-FILES-UNTOUCHED", "observed"] == ""


def test_rq5_protected_scientific_paths_have_no_git_diff() -> None:
    changed = subprocess.run(
        ["git", "diff", "--name-only", "--", *PROTECTED_GIT_PATHS],
        cwd=PROJECT_ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    assert changed == ""
