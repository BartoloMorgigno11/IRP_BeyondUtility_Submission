"""Primary systematic RQ5 extension runner.

This runner keeps the corrected RQ5 V2 ranking contract fixed while extending
the primary profile-family matrix to five datasets, three recommenders, and one
fixed Qwen profile generator.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import subprocess
import sys
import time
import urllib.request
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml

PROJECT_ROOT_FOR_IMPORTS = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT_FOR_IMPORTS) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT_FOR_IMPORTS))

from src.analysis import rq5_corrected_matched_recovery as corrected
from src.extension import g1_primary_ranking_execution as g1
from src.extension.g0_canonical_llm_canary import RequestResult, call_ollama_generate, title_for_item, utc_now
from src.extension.f0_final_extension_freeze import sha256_file


DEFAULT_CONFIG = Path("configs/rq5_primary_systematic_extension.yaml")
PHASE_ID = "PRIMARY_SYSTEMATIC_RQ5_EXTENSION"
PROFILE_GENERATOR = "qwen2:7b-instruct"
REUSE_PROFILE = "REUSE_CORRECTED_QWEN_PROFILE"
NEW_PROFILE = "NEW_PROFILE_INFERENCE"
REUSE_RANKING = "REUSE_CORRECTED_RQ5_FULL"
NEW_RANKING = "NEW_RANKING_INFERENCE"
NO_REUSE = "NO_EXACT_REUSE"
DENOMINATOR_POLICY = "FAIL_STRICT_ALL_MANIFEST_REQUESTS_INVALID_ZERO"
RANKING_PROMPT_TEMPLATE_ID = "rq5_corrected_matched_json_index_exact10_hardened_v2"
RANKING_PARSER_CONTRACT = "r5d_ranked_index_json_top10_v1"
PROFILE_PROMPT_TEMPLATE_ID = "template_user_profile_generate_index3_free_text_retained"
PROFILE_PARSER_CONTRACT = "free_text_profile_retained"
HISTORY_CONTEXT_TEMPLATE_ID = "template_index1_history_context"

DATASET_LABELS = {
    "beauty": "Beauty",
    "sports": "Sports",
    "ml1m": "ML-1M",
    "lastfm": "LastFM",
    "foodcom": "FoodCom",
}

CONDITIONS = ("history_only", "profile_only", "profile_plus_history")
TREATMENT_SPECS = (
    ("profile_only_vs_history_only", "profile_only"),
    ("profile_plus_history_vs_history_only", "profile_plus_history"),
)
METRICS = ("hr_at_5", "ndcg_at_5")
DECISIONS = {
    "CI_SUPPORTED_POSITIVE",
    "CI_SUPPORTED_NEGATIVE",
    "NON_SIGNIFICANT_CI_INCLUDES_ZERO",
}
PROTECTED_PREFIXES = (
    "results/tables/g1_",
    "results/tables/g2_",
    "results/tables/g3_",
    "results/tables/g4_",
    "results/manifests/g1_",
    "results/manifests/g2_",
    "results/manifests/g3_",
    "results/manifests/g4_",
    "results/llm/extension_canonical/g1_",
    "results/llm/extension_canonical/g2_",
    "results/llm/extension_canonical/g3_",
    "results/llm/extension_canonical/g4_",
    "report/g1_",
    "report/g2_",
    "report/g3_",
    "report/g4_",
    "report/supporting/g1_",
    "report/supporting/g2_",
    "report/supporting/g3_",
    "report/supporting/g4_",
)


@dataclass(frozen=True)
class SourcePath:
    rel_path: Path
    path: Path
    scope: str
    sha256: str


def load_config(path: Path) -> dict[str, Any]:
    loaded = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(loaded, dict):
        raise ValueError(f"config must be a mapping: {path}")
    return loaded


def project_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def output_path(root: Path, config: Mapping[str, Any], key: str) -> Path:
    return project_path(root, (config.get("outputs") or {})[key])


def write_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, lineterminator="\n")


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def stable_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"))


def sha256_text(value: str) -> str:
    return corrected.sha256_text(value)


def stable_id(prefix: str, *parts: Any, length: int = 20) -> str:
    return f"{prefix}-{sha256_text(stable_json([str(part) for part in parts]))[:length]}"


def bool_text(value: bool) -> str:
    return "true" if value else "false"


def parse_bool(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def sorted_users(values: Iterable[str]) -> list[str]:
    return corrected.sorted_users(values)


def source_roots(root: Path) -> list[tuple[Path, str]]:
    seen: set[Path] = set()
    rows: list[tuple[Path, str]] = []
    for path, scope in [(root, "local_current_worktree"), *[(p, "external_read_only") for p in sorted(root.parent.glob("IRP_BeyondUtility*"))]]:
        resolved = path.resolve()
        if resolved in seen:
            continue
        seen.add(resolved)
        rows.append((path, scope))
    return rows


def resolve_source(root: Path, rel_path: str | Path) -> SourcePath:
    rel = Path(rel_path)
    searched: list[str] = []
    for candidate_root, scope in source_roots(root):
        candidate = candidate_root / rel
        searched.append(str(candidate))
        if candidate.exists() and candidate.is_file():
            return SourcePath(rel, candidate, scope, sha256_file(candidate))
    raise FileNotFoundError(f"missing source {rel.as_posix()}; searched={searched}")


def read_source_csv(root: Path, rel_path: str | Path) -> pd.DataFrame:
    return pd.read_csv(resolve_source(root, rel_path).path, dtype=str, keep_default_na=False, low_memory=False)


def read_source_json(root: Path, rel_path: str | Path) -> tuple[dict[str, Any], SourcePath]:
    source = resolve_source(root, rel_path)
    payload = json.loads(source.path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"source JSON is not an object: {source.path}")
    return payload, source


def find_source_root(root: Path) -> Path:
    required = [
        Path("data"),
        Path("configs/g1_primary_ranking_execution.yaml"),
        Path("results/tables/g1_primary_ranking_request_universe.csv"),
    ]
    for candidate, _scope in source_roots(root):
        if all((candidate / rel).exists() for rel in required):
            return candidate
    raise FileNotFoundError("could not locate source root with data and G1 material")


def http_json(method: str, url: str, *, timeout: int) -> dict[str, Any]:
    request = urllib.request.Request(url, headers={"Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            parsed = json.loads(response.read().decode("utf-8"))
    except Exception as exc:
        return {"_error": f"{type(exc).__name__}: {exc}", "models": []}
    return parsed if isinstance(parsed, dict) else {"_error": "non-object JSON response", "models": []}


def backend_preflight(config: Mapping[str, Any]) -> pd.DataFrame:
    runtime = config.get("runtime") or {}
    models = [PROFILE_GENERATOR, *[str(value) for value in (config.get("scope") or {}).get("recommenders", [])]]
    required_models = sorted(set(models))
    version = http_json("GET", str(runtime["version_endpoint"]), timeout=5)
    tags = http_json("GET", str(runtime["tags_endpoint"]), timeout=10)
    model_rows = tags.get("models", []) if isinstance(tags.get("models", []), list) else []
    by_name: dict[str, Mapping[str, Any]] = {}
    for row in model_rows:
        if isinstance(row, Mapping):
            for key in ("name", "model"):
                name = str(row.get(key, "")).strip()
                if name:
                    by_name[name] = row
    rows: list[dict[str, Any]] = []
    backend_ok = not str(version.get("_error", "")) and not str(tags.get("_error", ""))
    for model in required_models:
        tag = by_name.get(model, {})
        details = tag.get("details", {}) if isinstance(tag.get("details", {}), Mapping) else {}
        rows.append(
            {
                "model": model,
                "backend_available": bool_text(backend_ok),
                "model_available": bool_text(bool(tag)),
                "model_digest": str(tag.get("digest", "")),
                "model_modified_at": str(tag.get("modified_at", "")),
                "ollama_version": str(version.get("version", "")),
                "parameter_size": str(details.get("parameter_size", "")),
                "quantization_level": str(details.get("quantization_level", "")),
                "context_length": str(details.get("context_length", "")),
                "capabilities": stable_json(tag.get("capabilities", [])),
                "preflight_run": "true",
                "runtime_error": str(version.get("_error", "") or tags.get("_error", "")),
                "tags_endpoint": str(runtime["tags_endpoint"]),
                "status": "PASS" if backend_ok and bool(tag) else "FAIL",
            }
        )
    return pd.DataFrame(rows)


def require_preflight(preflight: pd.DataFrame) -> None:
    if preflight.empty or not preflight["status"].eq("PASS").all():
        raise RuntimeError("backend/model preflight failed; stopping before inference")


def json_list(value: Any) -> list[str]:
    return corrected.json_list(value)


def extract_v2_history_context(prompt: str) -> str:
    text = str(prompt or "")
    marker = "User interaction history:\n"
    if marker not in text:
        return corrected.extract_history_context(text)
    rest = text.split(marker, 1)[1]
    stop = "\n\nUse only the train-history"
    if stop in rest:
        return rest.split(stop, 1)[0].strip()
    return rest.strip()


def history_context_from_titles(dataset_label: str, user_id: str, history_titles: Sequence[str]) -> str:
    return (
        f"Here is the purchase history of {dataset_label} user {user_id} "
        f"(from the earlier to the later): {dataset_label} item {list(history_titles)} ."
    )


def profile_prompt_from_titles(dataset_label: str, user_id: str, history_titles: Sequence[str]) -> str:
    return (
        f"The {dataset_label} user {user_id} has bought items (from the earlier to the later): "
        f"{dataset_label} items {list(history_titles)}. From the user history interaction list above, "
        "give us your guess about the user's personality, preference and shopping tendency."
    )


def candidate_hash(ids: Sequence[str]) -> str:
    return corrected.sha256_text(stable_json([str(value) for value in ids]))


def model_digest(preflight: pd.DataFrame, model: str) -> str:
    subset = preflight.loc[preflight["model"].eq(model), "model_digest"]
    return str(subset.iloc[0]) if not subset.empty else ""


def load_g1_inputs_from_source(root: Path) -> tuple[Path, dict[str, Any], Any]:
    source_root = find_source_root(root)
    cfg = g1.load_config(source_root, Path("configs/g1_primary_ranking_execution.yaml"))
    inputs = g1.load_inputs(source_root, cfg)
    return source_root, cfg, inputs


def extra_dataset_contexts(root: Path, datasets: Sequence[str], users_per_dataset: int) -> tuple[Path, dict[str, dict[str, Any]]]:
    source_root, _cfg, inputs = load_g1_inputs_from_source(root)
    contexts: dict[str, dict[str, Any]] = {}
    for dataset in datasets:
        candidate_frame = inputs.ranking_candidates[dataset]
        users = sorted_users(candidate_frame["user_id"].astype(str).unique())[:users_per_dataset]
        if len(users) != users_per_dataset:
            raise RuntimeError(f"{dataset} has fewer than {users_per_dataset} G1 candidate users")
        for user_id in users:
            base = g1.build_ranking_user_context(inputs, dataset, user_id)
            history_items = list(base["history_items"])
            history_titles = [str(item["title"]) for item in history_items]
            history_ids = [str(item["item_id"]) for item in history_items]
            candidate_items = list(base["ranking_candidates"])
            candidate_ids = [str(item["item_id"]) for item in candidate_items]
            candidate_titles = [str(item["title"]) for item in candidate_items]
            contexts[f"{dataset}::{user_id}"] = {
                "dataset": dataset,
                "dataset_label": DATASET_LABELS.get(dataset, dataset),
                "user_id": str(user_id),
                "candidate_item_ids": candidate_ids,
                "candidate_item_titles": candidate_titles,
                "candidate_list_hash": str(base["candidate_hash"]),
                "positive_item_id": str(base["positive_item_id"]),
                "positive_candidate_position": str(candidate_ids.index(str(base["positive_item_id"])) + 1),
                "history_item_ids": history_ids,
                "history_item_titles": history_titles,
                "history_length": len(history_ids),
                "full_history_length": int(base["full_history_length"]),
                "history_context": history_context_from_titles(DATASET_LABELS.get(dataset, dataset), str(user_id), history_titles),
                "candidate_source": str(base["candidate_source"]),
                "source_scope": "external_read_only",
                "source_root": str(source_root),
            }
    return source_root, contexts


def corrected_contexts(root: Path, users_per_dataset: int) -> dict[str, dict[str, Any]]:
    requests = read_source_csv(root, "results/tables/rq5_corrected_full_request_universe.csv")
    profiles = read_source_csv(root, "results/tables/rq5_corrected_full_profile_reuse_audit.csv")
    qwen_profiles = profiles.loc[
        profiles["profile_generator"].eq(PROFILE_GENERATOR) & profiles["status"].eq("REUSABLE")
    ].copy()
    contexts: dict[str, dict[str, Any]] = {}
    for dataset in ("beauty", "sports"):
        dataset_profiles = qwen_profiles.loc[qwen_profiles["dataset"].eq(dataset)].copy()
        users = sorted_users(dataset_profiles["user_id"].astype(str).unique())
        if len(users) != users_per_dataset:
            raise RuntimeError(f"{dataset} corrected Qwen profile users != {users_per_dataset}: {len(users)}")
        for user_id in users:
            profile_row = dataset_profiles.loc[dataset_profiles["user_id"].eq(user_id)].iloc[0]
            profile_payload, profile_source = read_source_json(root, profile_row["raw_source_file"])
            profile_text = corrected.profile_text_from_raw(profile_payload)
            if not profile_text:
                raise RuntimeError(f"empty reusable profile: {dataset}/{user_id}")
            history_subset = requests.loc[
                requests["dataset"].eq(dataset)
                & requests["user_id"].eq(user_id)
                & requests["recommender_model_name"].eq(PROFILE_GENERATOR)
                & requests["condition"].eq("history_only")
            ].copy()
            if history_subset.empty:
                history_subset = requests.loc[requests["dataset"].eq(dataset) & requests["user_id"].eq(user_id) & requests["condition"].eq("history_only")].copy()
            if history_subset.empty:
                raise RuntimeError(f"missing corrected history row: {dataset}/{user_id}")
            history_row = history_subset.iloc[0]
            candidate_ids = json_list(history_row["candidate_item_ids_json"])
            candidate_titles = json_list(history_row["candidate_item_titles_json"])
            contexts[f"{dataset}::{user_id}"] = {
                "dataset": dataset,
                "dataset_label": DATASET_LABELS[dataset],
                "user_id": user_id,
                "candidate_item_ids": candidate_ids,
                "candidate_item_titles": candidate_titles,
                "candidate_list_hash": str(history_row["candidate_list_hash"]),
                "positive_item_id": str(history_row["positive_item_id"]),
                "positive_candidate_position": str(history_row["positive_candidate_position"]),
                "history_item_ids": [],
                "history_item_titles": [],
                "history_length": 10,
                "full_history_length": 10,
                "history_context": extract_v2_history_context(str(history_row["prompt_render"])),
                "candidate_source": str(history_row["source_file"]),
                "source_scope": str(history_row["source_scope"]),
                "profile_text": profile_text,
                "profile_hash": sha256_text(profile_text),
                "source_profile_request_id": str(profile_row["profile_request_id"]),
                "source_profile_file": str(profile_row["raw_source_file"]),
                "source_profile_scope": str(profile_source.scope),
                "source_profile_sha256": str(profile_source.sha256),
            }
    return contexts


def build_all_contexts(root: Path, config: Mapping[str, Any]) -> tuple[dict[str, dict[str, Any]], str]:
    scope = config.get("scope") or {}
    users_per_dataset = int(scope.get("users_per_dataset", 200))
    contexts = corrected_contexts(root, users_per_dataset)
    source_root, extra = extra_dataset_contexts(root, ["ml1m", "lastfm", "foodcom"], users_per_dataset)
    contexts.update(extra)
    return contexts, str(source_root)


def profile_destination(config: Mapping[str, Any], profile_id: str) -> str:
    return (Path(str((config.get("outputs") or {})["profile_namespace"])) / f"{profile_id}.json").as_posix()


def ranking_destination(config: Mapping[str, Any], request_id: str) -> str:
    return (Path(str((config.get("outputs") or {})["ranking_namespace"])) / f"{request_id}.json").as_posix()


def build_profile_manifest(root: Path, config: Mapping[str, Any], contexts: Mapping[str, Mapping[str, Any]], preflight: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for key in sorted(contexts, key=lambda value: (list(DATASET_LABELS).index(value.split("::", 1)[0]), corrected.sorted_users([value.split("::", 1)[1]])[0])):
        context = contexts[key]
        dataset = str(context["dataset"])
        user_id = str(context["user_id"])
        profile_id = stable_id("RQ5PSE-PROF", dataset, user_id, PROFILE_GENERATOR, context.get("history_context", ""))
        reuse_class = REUSE_PROFILE if dataset in {"beauty", "sports"} else NEW_PROFILE
        profile_text = str(context.get("profile_text", ""))
        rendered_prompt = profile_prompt_from_titles(str(context["dataset_label"]), user_id, [str(x) for x in context.get("history_item_titles", [])])
        if dataset in {"beauty", "sports"}:
            rendered_prompt = str(read_source_json(root, str(context["source_profile_file"]))[0].get("rendered_prompt", rendered_prompt))
        rows.append(
            {
                "phase": PHASE_ID,
                "dataset": dataset,
                "user_id": user_id,
                "profile_generator": PROFILE_GENERATOR,
                "profile_request_id": profile_id,
                "profile_reuse_class": reuse_class,
                "new_profile_call_required": bool_text(reuse_class == NEW_PROFILE),
                "source_profile_request_id": str(context.get("source_profile_request_id", "")),
                "source_profile_file": str(context.get("source_profile_file", "")),
                "source_profile_scope": str(context.get("source_profile_scope", "")),
                "source_profile_sha256": str(context.get("source_profile_sha256", "")),
                "output_destination": profile_destination(config, profile_id),
                "model_digest": model_digest(preflight, PROFILE_GENERATOR),
                "prompt_template_id": PROFILE_PROMPT_TEMPLATE_ID,
                "parser_contract": PROFILE_PARSER_CONTRACT,
                "response_format": "text",
                "temperature": 0,
                "seed": 0,
                "max_new_tokens": int((config.get("runtime") or {}).get("max_new_tokens_profile", 256)),
                "history_length": int(context.get("history_length", 0)),
                "full_history_length": int(context.get("full_history_length", context.get("history_length", 0))),
                "history_context_hash": sha256_text(str(context["history_context"])),
                "history_context_template_id": HISTORY_CONTEXT_TEMPLATE_ID,
                "history_item_ids_json": stable_json([str(x) for x in context.get("history_item_ids", [])]),
                "history_item_titles_json": stable_json([str(x) for x in context.get("history_item_titles", [])]),
                "rendered_prompt": rendered_prompt,
                "rendered_prompt_hash": sha256_text(rendered_prompt),
                "profile_hash": sha256_text(profile_text) if profile_text else "",
                "profile_char_count": len(profile_text),
                "profile_dependency_status": "PRESENT_REUSED" if profile_text else "PENDING_GENERATION",
                "source_root": str(context.get("source_root", "")),
            }
        )
    frame = pd.DataFrame(rows).sort_values(["dataset", "user_id"], key=lambda col: col.map(lambda value: (DATASET_LABELS.get(str(value), str(value)), str(value))) if col.name == "dataset" else col, kind="mergesort")
    if len(frame) != int((config.get("frozen_accounting") or {})["target_profiles"]):
        raise RuntimeError(f"profile manifest count mismatch: {len(frame)}")
    if frame["profile_request_id"].nunique() != len(frame):
        raise RuntimeError("duplicate profile request ids")
    return frame.reset_index(drop=True)


def profile_text_from_primary_payload(payload: Mapping[str, Any]) -> str:
    value = payload.get("profile_text")
    if isinstance(value, str) and value.strip():
        return value.strip()
    return corrected.profile_text_from_raw(payload)


def build_profile_payload(
    row: Mapping[str, Any],
    *,
    execution_status: str,
    response_text: str,
    raw_response: Mapping[str, Any],
    error: str,
    latency_seconds: float,
    reuse_source_payload: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    profile_text = response_text.strip()
    return {
        "phase": PHASE_ID,
        "task": "profile_generation",
        "request_id": str(row["profile_request_id"]),
        "dataset": str(row["dataset"]),
        "user_id": str(row["user_id"]),
        "model_name": PROFILE_GENERATOR,
        "profile_generator_name": PROFILE_GENERATOR,
        "execution_status": execution_status,
        "backend_complete": bool_text(execution_status == "SUCCEEDED"),
        "response_text": response_text,
        "raw_response": response_text,
        "profile_text": profile_text,
        "profile_hash": sha256_text(profile_text) if profile_text else "",
        "profile_char_count": len(profile_text),
        "rendered_prompt": str(row["rendered_prompt"]),
        "rendered_prompt_hash": str(row["rendered_prompt_hash"]),
        "prompt_template_id": PROFILE_PROMPT_TEMPLATE_ID,
        "parser_contract": PROFILE_PARSER_CONTRACT,
        "generation_parameters": {
            "temperature": int(row["temperature"]),
            "seed": int(row["seed"]),
            "num_predict": int(row["max_new_tokens"]),
            "response_format": "text",
            "scientific_retry_count": 0,
            "infrastructure_retry_count": 0,
        },
        "reuse_class": str(row["profile_reuse_class"]),
        "reuse_source_file": str(row.get("source_profile_file", "")),
        "reuse_source_request_id": str(row.get("source_profile_request_id", "")),
        "reuse_source_sha256": str(row.get("source_profile_sha256", "")),
        "ollama_raw_response": dict(raw_response),
        "ollama_done_reason": str(raw_response.get("done_reason", "")),
        "runtime_model_id": str(raw_response.get("model", PROFILE_GENERATOR)),
        "error": error,
        "latency_seconds": latency_seconds,
        "raw_output_recorded_before_profile_validation": True,
        "source_reuse_payload_status": "AVAILABLE" if reuse_source_payload is not None else "",
    }


def profile_payload_from_result(row: Mapping[str, Any], result: RequestResult) -> dict[str, Any]:
    status = "SUCCEEDED" if result.backend_success else "BACKEND_FAILED"
    return build_profile_payload(
        row,
        execution_status=status,
        response_text=result.response_text,
        raw_response=result.raw_backend_response,
        error=result.backend_error_message,
        latency_seconds=result.duration_seconds,
    )


def execute_profiles(root: Path, config: Mapping[str, Any], manifest: pd.DataFrame, *, execute: bool) -> int:
    if not execute:
        return 0
    runtime = config.get("runtime") or {}
    sent = 0
    for index, row in enumerate(manifest.to_dict("records"), start=1):
        destination = project_path(root, row["output_destination"])
        if destination.exists():
            continue
        if str(row["profile_reuse_class"]) == REUSE_PROFILE:
            source_payload, _source = read_source_json(root, str(row["source_profile_file"]))
            profile_text = corrected.profile_text_from_raw(source_payload)
            payload = build_profile_payload(
                row,
                execution_status="SUCCEEDED",
                response_text=profile_text,
                raw_response=source_payload.get("ollama_response", {}) if isinstance(source_payload.get("ollama_response"), Mapping) else {},
                error="",
                latency_seconds=0.0,
                reuse_source_payload=source_payload,
            )
            write_json(destination, payload)
            continue
        call_payload = {
            "model": PROFILE_GENERATOR,
            "prompt": str(row["rendered_prompt"]),
            "stream": False,
            "options": {
                "temperature": float(row["temperature"]),
                "seed": int(row["seed"]),
                "num_predict": int(row["max_new_tokens"]),
            },
        }
        raw_capture = destination.with_name(destination.stem + ".raw_capture.json")
        if raw_capture.exists():
            raw_payload = json.loads(raw_capture.read_text(encoding="utf-8"))
            result = RequestResult(
                backend_success=bool(raw_payload.get("backend_success", False)),
                response_text=str(raw_payload.get("response_text", "")),
                raw_backend_response=raw_payload.get("raw_backend_response", {}),
                backend_error_type=str(raw_payload.get("backend_error_type", "")),
                backend_error_message=str(raw_payload.get("backend_error_message", "")),
                started_at=str(raw_payload.get("started_at", "")),
                completed_at=str(raw_payload.get("completed_at", "")),
                duration_seconds=float(raw_payload.get("duration_seconds", 0.0) or 0.0),
            )
        else:
            result = call_ollama_generate(str(runtime["base_url"]), call_payload, int(runtime["timeout_seconds"]))
            write_json(
                raw_capture,
                {
                    "phase": PHASE_ID,
                    "task": "profile_generation",
                    "request_id": str(row["profile_request_id"]),
                    "backend_success": result.backend_success,
                    "response_text": result.response_text,
                    "raw_backend_response": result.raw_backend_response,
                    "backend_error_type": result.backend_error_type,
                    "backend_error_message": result.backend_error_message,
                    "started_at": result.started_at,
                    "completed_at": result.completed_at,
                    "duration_seconds": result.duration_seconds,
                    "raw_response_hash": sha256_text(result.response_text),
                    "raw_output_recorded_before_parse": True,
                },
            )
            sent += 1
        payload = profile_payload_from_result(row, result)
        write_json(destination, payload)
        if not result.backend_success or not result.response_text.strip():
            raise RuntimeError(f"profile generation failed: {row['profile_request_id']} {result.backend_error_message}")
        if sent and sent % 25 == 0:
            print(f"RQ5_PROFILE_PROGRESS new_profile_calls={sent} manifest_row={index}/{len(manifest)}", flush=True)
    return sent


def profile_status(root: Path, manifest: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for row in manifest.to_dict("records"):
        destination = project_path(root, row["output_destination"])
        payload: dict[str, Any] = {}
        if destination.exists():
            payload = json.loads(destination.read_text(encoding="utf-8"))
        profile_text = profile_text_from_primary_payload(payload) if payload else ""
        expected_hash = str(row.get("profile_hash", ""))
        observed_hash = sha256_text(profile_text) if profile_text else ""
        hash_ok = (not expected_hash) or expected_hash == observed_hash
        rows.append(
            {
                "dataset": str(row["dataset"]),
                "user_id": str(row["user_id"]),
                "profile_generator": PROFILE_GENERATOR,
                "profile_request_id": str(row["profile_request_id"]),
                "profile_reuse_class": str(row["profile_reuse_class"]),
                "planned": 1,
                "terminal": 1 if payload else 0,
                "profile_present": 1 if profile_text else 0,
                "new_profile_call_required": 1 if str(row["profile_reuse_class"]) == NEW_PROFILE else 0,
                "reused_profile": 1 if str(row["profile_reuse_class"]) == REUSE_PROFILE else 0,
                "profile_hash": observed_hash,
                "profile_hash_matches_manifest": bool_text(hash_ok),
                "profile_char_count": len(profile_text),
                "execution_status": str(payload.get("execution_status", "not_executed")) if payload else "not_executed",
                "backend_failure": 1 if str(payload.get("execution_status", "")) == "BACKEND_FAILED" else 0,
                "output_destination": str(row["output_destination"]),
            }
        )
    return pd.DataFrame(rows)


def completed_profiles(root: Path, manifest: pd.DataFrame) -> dict[str, dict[str, str]]:
    by_id: dict[str, dict[str, str]] = {}
    for row in manifest.to_dict("records"):
        destination = project_path(root, row["output_destination"])
        if not destination.exists():
            continue
        payload = json.loads(destination.read_text(encoding="utf-8"))
        text = profile_text_from_primary_payload(payload)
        if text:
            by_id[str(row["profile_request_id"])] = {
                "profile_text": text,
                "profile_hash": sha256_text(text),
                "profile_file": str(row["output_destination"]),
            }
    return by_id


def require_profiles_complete(status: pd.DataFrame, expected: int) -> None:
    if int(status["terminal"].sum()) != expected or int(status["profile_present"].sum()) != expected:
        raise RuntimeError("profile completion gate failed")
    if not status["profile_hash_matches_manifest"].eq("true").all():
        raise RuntimeError("profile hash mismatch gate failed")
    if int(status["backend_failure"].sum()) != 0:
        raise RuntimeError("profile backend failure gate failed")


def materialize_profile_manifest_hashes(profile_manifest: pd.DataFrame, status: pd.DataFrame) -> pd.DataFrame:
    observed = status.set_index("profile_request_id").to_dict("index")
    rows: list[dict[str, Any]] = []
    for row in profile_manifest.to_dict("records"):
        current = observed.get(str(row["profile_request_id"]), {})
        updated = dict(row)
        updated["profile_hash"] = str(current.get("profile_hash", row.get("profile_hash", "")))
        updated["profile_char_count"] = int(current.get("profile_char_count", row.get("profile_char_count", 0)) or 0)
        updated["profile_dependency_status"] = "PRESENT"
        rows.append(updated)
    return pd.DataFrame(rows)


def build_corrected_ranking_lookup(root: Path) -> dict[tuple[str, str, str, str], dict[str, Any]]:
    requests = read_source_csv(root, "results/tables/rq5_corrected_full_request_universe.csv")
    lookup: dict[tuple[str, str, str, str], dict[str, Any]] = {}
    for row in requests.to_dict("records"):
        dataset = str(row["dataset"])
        recommender = str(row["recommender_model_name"])
        condition = str(row["condition"])
        profile_generator = str(row["profile_generator_name"])
        if dataset not in {"beauty", "sports"} or recommender not in {"qwen2:7b-instruct", "mistral:7b-instruct"}:
            continue
        if condition == "history_only":
            generator_key = "none"
        elif profile_generator == PROFILE_GENERATOR:
            generator_key = PROFILE_GENERATOR
        else:
            continue
        lookup[(dataset, str(row["user_id"]), recommender, condition)] = dict(row, primary_profile_generator=generator_key)
    return lookup


def context_to_ranking_base(context: Mapping[str, Any], profile: Mapping[str, str]) -> dict[str, Any]:
    candidate_ids = [str(value) for value in context["candidate_item_ids"]]
    candidate_titles = [str(value) for value in context["candidate_item_titles"]]
    return {
        "candidate_item_ids_json": stable_json(candidate_ids),
        "candidate_item_titles_json": stable_json(candidate_titles),
        "candidate_list_hash": str(context["candidate_list_hash"]),
        "candidate_count": len(candidate_ids),
        "positive_item_id": str(context["positive_item_id"]),
        "positive_candidate_position": str(context["positive_candidate_position"]),
        "history_context": str(context["history_context"]),
        "history_context_hash": sha256_text(str(context["history_context"])),
        "history_item_ids_json": stable_json([str(x) for x in context.get("history_item_ids", [])]),
        "history_item_titles_json": stable_json([str(x) for x in context.get("history_item_titles", [])]),
        "history_length": int(context.get("history_length", 0)),
        "full_history_length": int(context.get("full_history_length", context.get("history_length", 0))),
        "profile_text": profile["profile_text"],
        "profile_hash": profile["profile_hash"],
        "profile_file": profile["profile_file"],
    }


def render_ranking_prompt(condition: str, base: Mapping[str, Any]) -> str:
    return corrected.render_corrected_prompt(
        condition=condition,
        history_context=str(base["history_context"]),
        profile_text=str(base["profile_text"]),
        candidate_titles=json_list(base["candidate_item_titles_json"]),
        expected_count=10,
        candidate_count=20,
    )


def build_ranking_universe(
    root: Path,
    config: Mapping[str, Any],
    contexts: Mapping[str, Mapping[str, Any]],
    profile_manifest: pd.DataFrame,
    profile_by_id: Mapping[str, Mapping[str, str]],
    preflight: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    scope = config.get("scope") or {}
    datasets = [str(value) for value in scope["datasets"]]
    recommenders = [str(value) for value in scope["recommenders"]]
    profiles_by_user = profile_manifest.set_index(["dataset", "user_id"]).to_dict("index")
    corrected_lookup = build_corrected_ranking_lookup(root)
    rows: list[dict[str, Any]] = []
    reuse_rows: list[dict[str, Any]] = []
    sequence = 1
    for dataset in datasets:
        keys = [key for key in contexts if key.startswith(dataset + "::")]
        users = sorted_users([key.split("::", 1)[1] for key in keys])
        for user_id in users:
            context = contexts[f"{dataset}::{user_id}"]
            profile_row = profiles_by_user[(dataset, user_id)]
            profile_id = str(profile_row["profile_request_id"])
            profile = profile_by_id[profile_id]
            base = context_to_ranking_base(context, profile)
            for recommender in recommenders:
                for condition in CONDITIONS:
                    source_row = corrected_lookup.get((dataset, user_id, recommender, condition), {})
                    exact_reuse = bool(source_row) and recommender in {"qwen2:7b-instruct", "mistral:7b-instruct"}
                    if exact_reuse:
                        prompt_render = str(source_row["prompt_render"])
                        prompt_hash = str(source_row["prompt_hash"])
                        candidate_ids_json = str(source_row["candidate_item_ids_json"])
                        candidate_titles_json = str(source_row["candidate_item_titles_json"])
                        candidate_list = str(source_row["candidate_list_hash"])
                        positive = str(source_row["positive_item_id"])
                        positive_position = str(source_row["positive_candidate_position"])
                        history_hash = str(source_row["history_context_hash"])
                        source_output = str(source_row["output_destination"])
                    else:
                        prompt_render = render_ranking_prompt(condition, base)
                        prompt_hash = sha256_text(prompt_render)
                        candidate_ids_json = str(base["candidate_item_ids_json"])
                        candidate_titles_json = str(base["candidate_item_titles_json"])
                        candidate_list = str(base["candidate_list_hash"])
                        positive = str(base["positive_item_id"])
                        positive_position = str(base["positive_candidate_position"])
                        history_hash = str(base["history_context_hash"])
                        source_output = ""
                    profile_generator_name = "none" if condition == "history_only" else PROFILE_GENERATOR
                    request_id = stable_id(
                        "RQ5PSE-RANK",
                        dataset,
                        user_id,
                        recommender,
                        condition,
                        profile_generator_name,
                        candidate_list,
                        prompt_hash,
                    )
                    prompt_hidden = not corrected.prompt_discloses_positive(prompt_render, positive, positive_position)
                    row = {
                        "request_id": request_id,
                        "sequence": sequence,
                        "phase": PHASE_ID,
                        "dataset": dataset,
                        "user_id": user_id,
                        "model_name": recommender,
                        "recommender_model_name": recommender,
                        "model_digest": model_digest(preflight, recommender),
                        "profile_generator_name": profile_generator_name,
                        "primary_profile_generator": PROFILE_GENERATOR,
                        "condition": condition,
                        "input_variant": condition,
                        "profile_request_id": "" if condition == "history_only" else profile_id,
                        "profile_hash": "" if condition == "history_only" else profile["profile_hash"],
                        "profile_source_file": "" if condition == "history_only" else profile["profile_file"],
                        "candidate_list_hash": candidate_list,
                        "candidate_item_ids_json": candidate_ids_json,
                        "candidate_item_titles_json": candidate_titles_json,
                        "candidate_count": 20,
                        "positive_item_id": positive,
                        "positive_candidate_position": positive_position,
                        "prompt_template_id": RANKING_PROMPT_TEMPLATE_ID,
                        "parser_contract": RANKING_PARSER_CONTRACT,
                        "expected_output_schema": stable_json({"ranked_candidate_indices": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}),
                        "expected_output_count": 10,
                        "candidate_index_base": 1,
                        "temperature": 0,
                        "seed": 0,
                        "max_new_tokens": int((config.get("runtime") or {}).get("max_new_tokens_ranking", 256)),
                        "prompt_render": prompt_render,
                        "prompt_hash": prompt_hash,
                        "positive_label_hidden": bool_text(prompt_hidden),
                        "history_context_hash": history_hash,
                        "history_item_ids_json": str(base["history_item_ids_json"]),
                        "history_item_titles_json": str(base["history_item_titles_json"]),
                        "history_length": int(base["history_length"]),
                        "full_history_length": int(base["full_history_length"]),
                        "source_file": str(context.get("candidate_source", "")),
                        "source_scope": str(context.get("source_scope", "")),
                        "output_destination": ranking_destination(config, request_id),
                        "metric_denominator_policy": DENOMINATOR_POLICY,
                        "exact_reuse_source_request_id": str(source_row.get("request_id", "")),
                        "exact_reuse_source_file": source_output,
                        "reuse_class": REUSE_RANKING if exact_reuse else NEW_RANKING,
                        "new_inference_required": bool_text(not exact_reuse),
                        "aplt_candidate_universe_item_ids_json": candidate_ids_json,
                        "serendipity_candidate_universe_item_ids_json": candidate_ids_json,
                        "train_popularity_support_provenance": "PENDING_F6L_MAPPING" if dataset in {"beauty", "sports"} else "AVAILABLE_FROM_G1_SOURCE_TRAIN_EVENTS",
                        "long_tail_threshold_provenance": "PENDING_OFFLINE_DERIVATION",
                        "mostpop_reference_provenance": "PENDING_OFFLINE_DERIVATION",
                    }
                    row["logical_key_sha256"] = sha256_text(
                        stable_json(
                            {
                                "dataset": dataset,
                                "user_id": user_id,
                                "recommender": recommender,
                                "condition": condition,
                                "profile_generator": profile_generator_name,
                                "candidate_list_hash": candidate_list,
                                "positive_item_id": positive,
                                "prompt_hash": prompt_hash,
                            }
                        )
                    )
                    rows.append(row)
                    reuse_rows.append(
                        {
                            "request_id": request_id,
                            "dataset": dataset,
                            "user_id": user_id,
                            "recommender": recommender,
                            "condition": condition,
                            "profile_generator": profile_generator_name,
                            "final_reuse_class": REUSE_RANKING if exact_reuse else NO_REUSE,
                            "source_request_id": str(source_row.get("request_id", "")),
                            "source_file": source_output,
                            "candidate_list_hash_match": bool_text(exact_reuse),
                            "positive_item_match": bool_text(exact_reuse),
                            "prompt_contract_match": bool_text(exact_reuse),
                            "new_inference_required": bool_text(not exact_reuse),
                            "r5d_reuse_decision": "DESCRIPTIVE_ONLY_ZERO_EXACT_REUSE",
                            "mistral_profile_generator_decision": "PROFILE_GENERATOR_SENSITIVITY_EXCLUDED_FROM_PRIMARY",
                        }
                    )
                    sequence += 1
    universe = pd.DataFrame(rows)
    reuse = pd.DataFrame(reuse_rows)
    expected = int((config.get("frozen_accounting") or {})["logical_rankings"])
    if len(universe) != expected:
        raise RuntimeError(f"ranking universe count mismatch: {len(universe)} != {expected}")
    if universe["request_id"].nunique() != expected:
        raise RuntimeError("duplicate ranking request ids")
    if not universe["positive_label_hidden"].eq("true").all():
        bad = universe.loc[universe["positive_label_hidden"].ne("true"), "request_id"].head().tolist()
        raise RuntimeError(f"positive label disclosure detected: {bad}")
    reuse_count = int(reuse["final_reuse_class"].eq(REUSE_RANKING).sum())
    if reuse_count != int((config.get("frozen_accounting") or {})["exact_reused_rankings"]):
        raise RuntimeError(f"ranking reuse count mismatch: {reuse_count}")
    return universe, reuse


def ranking_raw_capture_path(root: Path, config: Mapping[str, Any], request_id: str) -> Path:
    return output_path(root, config, "raw_namespace") / "ranking_raw_captures" / f"{request_id}.json"


def build_ranking_payload(
    row: Mapping[str, Any],
    *,
    execution_status: str,
    response_text: str,
    raw_response: Mapping[str, Any],
    error: str,
    latency_seconds: float,
    reuse_class: str,
    reuse_source_file: str = "",
    reuse_source_request_id: str = "",
) -> dict[str, Any]:
    parse_record = corrected.parse_corrected_response(row, response_text) if execution_status == "SUCCEEDED" else {
        "parse_valid": False,
        "parse_status": "backend_failed",
        "parse_error": error,
        "validity_class": "BACKEND_FAILED",
        "ranked_candidate_indices": [],
        "ranked_item_ids": [],
        "duplicate_count": 0,
        "unknown_item_count": 0,
        "output_length": 0,
        "expected_output_count": int(row["expected_output_count"]),
        "positive_rank": 0,
        "hr_at_5": 0.0,
        "ndcg_at_5": 0.0,
        "metric_ready": False,
    }
    return {
        "phase": PHASE_ID,
        "task": "ranking",
        "request_id": str(row["request_id"]),
        "dataset": str(row["dataset"]),
        "user_id": str(row["user_id"]),
        "model_name": str(row["model_name"]),
        "profile_generator_name": str(row["profile_generator_name"]),
        "primary_profile_generator": PROFILE_GENERATOR,
        "condition": str(row["condition"]),
        "execution_status": execution_status,
        "backend_complete": bool_text(execution_status == "SUCCEEDED"),
        "response_text": response_text,
        "raw_response": response_text,
        "raw_response_hash": sha256_text(response_text),
        "parse": parse_record,
        "candidate_item_ids": json_list(row["candidate_item_ids_json"]),
        "candidate_item_titles": json_list(row["candidate_item_titles_json"]),
        "candidate_list_hash": str(row["candidate_list_hash"]),
        "positive_item_id": str(row["positive_item_id"]),
        "positive_candidate_position": str(row["positive_candidate_position"]),
        "history_item_ids": json_list(row["history_item_ids_json"]),
        "profile_request_id": str(row.get("profile_request_id", "")),
        "profile_hash": str(row.get("profile_hash", "")),
        "prompt_template_id": RANKING_PROMPT_TEMPLATE_ID,
        "parser_contract": RANKING_PARSER_CONTRACT,
        "prompt_hash": str(row["prompt_hash"]),
        "prompt_render": str(row["prompt_render"]),
        "metric_denominator_policy": DENOMINATOR_POLICY,
        "reuse_class": reuse_class,
        "reuse_source_file": reuse_source_file,
        "reuse_source_request_id": reuse_source_request_id,
        "runtime_backend": "local_ollama",
        "runtime_model_id": str(raw_response.get("model", row["model_name"])),
        "ollama_done_reason": str(raw_response.get("done_reason", "")),
        "ollama_raw_response": dict(raw_response),
        "error": error,
        "latency_seconds": latency_seconds,
        "raw_output_recorded_before_parse": True,
    }


def payload_from_reused_ranking(root: Path, row: Mapping[str, Any]) -> dict[str, Any]:
    source_payload, _source = read_source_json(root, str(row["exact_reuse_source_file"]))
    response_text = corrected.raw_response_text(source_payload)
    raw_response = source_payload.get("ollama_raw_response", {})
    if not isinstance(raw_response, Mapping):
        raw_response = {}
    return build_ranking_payload(
        row,
        execution_status=str(source_payload.get("execution_status", "SUCCEEDED")),
        response_text=response_text,
        raw_response=raw_response,
        error=str(source_payload.get("error", "")),
        latency_seconds=0.0,
        reuse_class=REUSE_RANKING,
        reuse_source_file=str(row["exact_reuse_source_file"]),
        reuse_source_request_id=str(row["exact_reuse_source_request_id"]),
    )


def result_from_raw_capture(path: Path) -> RequestResult:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return RequestResult(
        backend_success=bool(payload.get("backend_success", False)),
        response_text=str(payload.get("response_text", "")),
        raw_backend_response=payload.get("raw_backend_response", {}),
        backend_error_type=str(payload.get("backend_error_type", "")),
        backend_error_message=str(payload.get("backend_error_message", "")),
        started_at=str(payload.get("started_at", "")),
        completed_at=str(payload.get("completed_at", "")),
        duration_seconds=float(payload.get("duration_seconds", 0.0) or 0.0),
    )


def execute_rankings(root: Path, config: Mapping[str, Any], universe: pd.DataFrame, *, execute: bool) -> int:
    if not execute:
        return 0
    runtime = config.get("runtime") or {}
    sent = 0
    ordered = universe.copy()
    ordered["_model_order"] = ordered["model_name"].map({model: index for index, model in enumerate((config.get("scope") or {})["recommenders"])})
    ordered["_dataset_order"] = ordered["dataset"].map({dataset: index for index, dataset in enumerate((config.get("scope") or {})["datasets"])})
    ordered["_condition_order"] = ordered["condition"].map({condition: index for index, condition in enumerate(CONDITIONS)})
    ordered = ordered.sort_values(["_model_order", "_dataset_order", "_condition_order", "user_id"], kind="mergesort")
    for index, row in enumerate(ordered.to_dict("records"), start=1):
        destination = project_path(root, row["output_destination"])
        if destination.exists():
            continue
        if str(row["reuse_class"]) == REUSE_RANKING:
            write_json(destination, payload_from_reused_ranking(root, row))
            continue
        capture = ranking_raw_capture_path(root, config, str(row["request_id"]))
        if capture.exists():
            result = result_from_raw_capture(capture)
        else:
            payload = {
                "model": str(row["model_name"]),
                "prompt": str(row["prompt_render"]),
                "stream": False,
                "format": str(runtime.get("format", "json")),
                "options": {
                    "temperature": float(row["temperature"]),
                    "seed": int(row["seed"]),
                    "num_predict": int(row["max_new_tokens"]),
                },
            }
            result = call_ollama_generate(str(runtime["base_url"]), payload, int(runtime["timeout_seconds"]))
            write_json(
                capture,
                {
                    "phase": PHASE_ID,
                    "task": "ranking",
                    "request_id": str(row["request_id"]),
                    "backend_success": result.backend_success,
                    "response_text": result.response_text,
                    "raw_backend_response": result.raw_backend_response,
                    "backend_error_type": result.backend_error_type,
                    "backend_error_message": result.backend_error_message,
                    "started_at": result.started_at,
                    "completed_at": result.completed_at,
                    "duration_seconds": result.duration_seconds,
                    "raw_response_hash": sha256_text(result.response_text),
                    "raw_output_recorded_before_parse": True,
                },
            )
            sent += 1
        execution_status = "SUCCEEDED" if result.backend_success else "BACKEND_FAILED"
        write_json(
            destination,
            build_ranking_payload(
                row,
                execution_status=execution_status,
                response_text=result.response_text,
                raw_response=result.raw_backend_response,
                error=result.backend_error_message,
                latency_seconds=result.duration_seconds,
                reuse_class=NEW_RANKING,
            ),
        )
        if not result.backend_success:
            raise RuntimeError(f"ranking backend failure: {row['request_id']} {result.backend_error_message}")
        if sent and sent % 100 == 0:
            print(f"RQ5_RANKING_PROGRESS new_ranking_calls={sent} ordered_row={index}/{len(ordered)}", flush=True)
    return sent


def ranking_status(root: Path, universe: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for row in universe.to_dict("records"):
        destination = project_path(root, row["output_destination"])
        payload: dict[str, Any] = {}
        if destination.exists():
            payload = json.loads(destination.read_text(encoding="utf-8"))
        parse_record = payload.get("parse", {}) if isinstance(payload.get("parse", {}), Mapping) else {}
        parse_status = str(parse_record.get("parse_status", "not_executed"))
        ranked_item_ids = [str(value) for value in parse_record.get("ranked_item_ids", [])] if isinstance(parse_record.get("ranked_item_ids", []), list) else []
        rows.append(
            {
                "request_id": str(row["request_id"]),
                "dataset": str(row["dataset"]),
                "user_id": str(row["user_id"]),
                "recommender": str(row["model_name"]),
                "condition": str(row["condition"]),
                "profile_generator": str(row["profile_generator_name"]),
                "primary_profile_generator": PROFILE_GENERATOR,
                "planned": 1,
                "completed": 1 if str(payload.get("execution_status", "")) == "SUCCEEDED" else 0,
                "terminal": 1 if payload else 0,
                "strict_valid": 1 if parse_bool(parse_record.get("parse_valid", False)) else 0,
                "invalid_length": 1 if parse_status == "invalid_length" else 0,
                "duplicate_index": 1 if parse_status == "duplicate_indices" else 0,
                "out_of_range_index": 1 if parse_status == "unknown_indices" else 0,
                "parse_failure": 1 if corrected.validity_class_from_status(parse_status) == "PARSE_FAILURE" else 0,
                "backend_failure": 1 if str(payload.get("execution_status", "")) == "BACKEND_FAILED" else 0,
                "backend_incomplete": 1 if str(payload.get("execution_status", "")) == "BACKEND_INCOMPLETE" else 0,
                "reuse_class": str(payload.get("reuse_class", row["reuse_class"])),
                "parse_status": parse_status,
                "validity_class": str(parse_record.get("validity_class", corrected.validity_class_from_status(parse_status))),
                "positive_rank": int(parse_record.get("positive_rank", 0) or 0),
                "hr_at_5": float(parse_record.get("hr_at_5", 0.0) or 0.0),
                "ndcg_at_5": float(parse_record.get("ndcg_at_5", 0.0) or 0.0),
                "output_length": int(parse_record.get("output_length", 0) or 0),
                "duplicate_count": int(parse_record.get("duplicate_count", 0) or 0),
                "unknown_item_count": int(parse_record.get("unknown_item_count", 0) or 0),
                "candidate_item_ids_json": str(row["candidate_item_ids_json"]),
                "top5_item_ids_json": stable_json(ranked_item_ids[:5]),
                "history_item_ids_json": str(row["history_item_ids_json"]),
                "profile_request_id": str(row.get("profile_request_id", "")),
                "profile_hash": str(row.get("profile_hash", "")),
                "result_file_sha256": sha256_file(destination) if destination.exists() else "",
            }
        )
    return pd.DataFrame(rows)


def build_request_accounting(status: pd.DataFrame) -> pd.DataFrame:
    group_cols = ["dataset", "recommender", "condition", "profile_generator"]
    numeric = [
        "planned",
        "completed",
        "terminal",
        "strict_valid",
        "invalid_length",
        "duplicate_index",
        "out_of_range_index",
        "parse_failure",
        "backend_failure",
        "backend_incomplete",
    ]
    grouped = status.groupby(group_cols, as_index=False, sort=True)[numeric].sum()
    grouped["strict_validity_rate"] = grouped["strict_valid"] / grouped["planned"].clip(lower=1)
    return grouped


def build_metrics(status: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for (dataset, recommender, condition), group in status.groupby(["dataset", "recommender", "condition"], sort=True):
        planned = int(group["planned"].sum())
        strict = int(group["strict_valid"].sum())
        rows.append(
            {
                "dataset": dataset,
                "recommender": recommender,
                "condition": condition,
                "primary_profile_generator": PROFILE_GENERATOR,
                "requests": planned,
                "strict_valid": strict,
                "strict_validity_rate": strict / planned if planned else 0.0,
                "hr_at_5": float(group["hr_at_5"].sum() / planned) if planned else 0.0,
                "ndcg_at_5": float(group["ndcg_at_5"].sum() / planned) if planned else 0.0,
                "denominator_policy": DENOMINATOR_POLICY,
                "metric_source": "primary_systematic_rq5_index_rankings_invalid_zero",
            }
        )
    return pd.DataFrame(rows)


def build_matching_audit(universe: pd.DataFrame, profile_status_frame: pd.DataFrame) -> pd.DataFrame:
    profile_ok = profile_status_frame.set_index(["dataset", "user_id"])["profile_hash"].to_dict()
    rows: list[dict[str, Any]] = []
    for (dataset, recommender, user_id), group in universe.groupby(["dataset", "recommender_model_name", "user_id"], sort=True):
        by_cond = group.set_index("condition").to_dict("index")
        candidate_values = {cond: str(row["candidate_item_ids_json"]) for cond, row in by_cond.items()}
        hash_values = {cond: str(row["candidate_list_hash"]) for cond, row in by_cond.items()}
        positives = {cond: str(row["positive_item_id"]) for cond, row in by_cond.items()}
        positive_positions = {cond: str(row["positive_candidate_position"]) for cond, row in by_cond.items()}
        prompts_hide_positive = all(str(row["positive_label_hidden"]) == "true" for row in by_cond.values())
        profile_hash = str(profile_ok.get((dataset, user_id), ""))
        profile_matches = all(
            str(row["profile_hash"]) == profile_hash
            for cond, row in by_cond.items()
            if cond in {"profile_only", "profile_plus_history"}
        )
        pass_check = (
            set(by_cond) == set(CONDITIONS)
            and len(set(candidate_values.values())) == 1
            and len(set(hash_values.values())) == 1
            and len(set(positives.values())) == 1
            and len(set(positive_positions.values())) == 1
            and prompts_hide_positive
            and profile_matches
        )
        rows.append(
            {
                "dataset": dataset,
                "recommender": recommender,
                "user_id": user_id,
                "conditions_present": stable_json(sorted(by_cond)),
                "same_candidate_membership_order": bool_text(len(set(candidate_values.values())) == 1),
                "same_candidate_hash": bool_text(len(set(hash_values.values())) == 1),
                "same_positive_item": bool_text(len(set(positives.values())) == 1),
                "same_positive_candidate_position": bool_text(len(set(positive_positions.values())) == 1),
                "positive_hidden_from_prompt": bool_text(prompts_hide_positive),
                "profile_user_lineage_exact": bool_text(profile_matches),
                "profile_hash": profile_hash,
                "matching_status": "PASS" if pass_check else "FAIL",
            }
        )
    return pd.DataFrame(rows)


def build_paired_contributions(status: pd.DataFrame) -> pd.DataFrame:
    index = status.set_index(["dataset", "recommender", "condition", "user_id"])
    rows: list[dict[str, Any]] = []
    history_rows = status.loc[status["condition"].eq("history_only")].copy()
    for row in history_rows.to_dict("records"):
        dataset = str(row["dataset"])
        recommender = str(row["recommender"])
        user_id = str(row["user_id"])
        h = index.loc[(dataset, recommender, "history_only", user_id)]
        for comparison, treatment in TREATMENT_SPECS:
            t = index.loc[(dataset, recommender, treatment, user_id)]
            for metric in METRICS:
                h_value = float(h[metric])
                t_value = float(t[metric])
                rows.append(
                    {
                        "dataset": dataset,
                        "user_id": user_id,
                        "recommender": recommender,
                        "profile_generator": PROFILE_GENERATOR,
                        "comparison": comparison,
                        "metric": metric,
                        "history_value": h_value,
                        "treatment_value": t_value,
                        "delta": t_value - h_value,
                        "history_request_id": str(h["request_id"]),
                        "treatment_request_id": str(t["request_id"]),
                        "denominator_policy": DENOMINATOR_POLICY,
                        "metric_source": "primary_systematic_rq5_index_rankings_invalid_zero",
                    }
                )
    return pd.DataFrame(rows)


def build_matched_deltas(contrib: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for (dataset, recommender, comparison, metric), group in contrib.groupby(["dataset", "recommender", "comparison", "metric"], sort=True):
        rows.append(
            {
                "dataset": dataset,
                "recommender": recommender,
                "profile_generator": PROFILE_GENERATOR,
                "comparison": comparison,
                "metric": metric,
                "paired_n": int(len(group)),
                "history_mean": float(group["history_value"].mean()),
                "treatment_mean": float(group["treatment_value"].mean()),
                "mean_delta": float(group["delta"].mean()),
                "denominator_policy": DENOMINATOR_POLICY,
                "metric_source": "primary_systematic_rq5_index_rankings_invalid_zero",
            }
        )
    return pd.DataFrame(rows)


def build_bootstrap(contrib: pd.DataFrame, config: Mapping[str, Any]) -> pd.DataFrame:
    stats = config.get("statistics") or {}
    resamples = int(stats.get("bootstrap_resamples", 10000))
    seed = int(stats.get("bootstrap_seed", 20260901))
    low = float(stats.get("bootstrap_ci_lower", 0.025))
    high = float(stats.get("bootstrap_ci_upper", 0.975))
    rng = np.random.default_rng(seed)
    rows: list[dict[str, Any]] = []
    for (dataset, recommender, comparison, metric), group in contrib.groupby(["dataset", "recommender", "comparison", "metric"], sort=True):
        values = group["delta"].astype(float).to_numpy()
        sample_idx = rng.integers(0, len(values), size=(resamples, len(values)))
        boot = values[sample_idx].mean(axis=1)
        ci_low, ci_high = np.quantile(boot, [low, high], method="linear")
        mean_delta = float(values.mean())
        if ci_low > 0:
            decision = "CI_SUPPORTED_POSITIVE"
        elif ci_high < 0:
            decision = "CI_SUPPORTED_NEGATIVE"
        else:
            decision = "NON_SIGNIFICANT_CI_INCLUDES_ZERO"
        rows.append(
            {
                "dataset": dataset,
                "recommender": recommender,
                "profile_generator": PROFILE_GENERATOR,
                "comparison": comparison,
                "metric": metric,
                "paired_n": int(len(values)),
                "mean_delta": mean_delta,
                "ci_lower": float(ci_low),
                "ci_upper": float(ci_high),
                "bootstrap_resamples": resamples,
                "bootstrap_seed": seed,
                "ci_method": "two_sided_percentile_numpy_linear",
                "decision": decision,
                "p_value": "",
            }
        )
    return pd.DataFrame(rows)


def build_beyond_readiness(universe: pd.DataFrame, status: pd.DataFrame) -> pd.DataFrame:
    terminal = int(status["terminal"].sum()) if not status.empty else 0
    top5_ready = terminal == len(universe) and status["top5_item_ids_json"].astype(str).str.startswith("[").all()
    rows = [
        ("canonical_item_ids", "READY", "candidate_item_ids_json and positive_item_id retained per request"),
        ("candidate_universe", "READY", "candidate membership/order retained per request"),
        ("top_k_item_ids", "READY" if top5_ready else "PENDING_TERMINAL_RANKINGS", "top5_item_ids_json retained in ranking execution status"),
        ("train_popularity_support_ml1m_lastfm_foodcom", "READY_FOR_OFFLINE_DERIVATION", "G1 source train events are resolvable from source_root"),
        ("train_popularity_support_beauty_sports", "PENDING_F6L_MAPPING", "F6L numeric item space retained; train-popularity mapping not materialized here"),
        ("long_tail_threshold_provenance", "PENDING_OFFLINE_DERIVATION", "provenance field retained in ranking universe"),
        ("mostpop_reference_provenance", "PENDING_OFFLINE_DERIVATION", "provenance field retained in ranking universe"),
        ("self_information_inputs", "READY_WITH_POPULARITY_SUPPORT", "top-k and candidate item IDs retained; probability support can be added offline"),
    ]
    return pd.DataFrame([{"component": c, "status": s, "notes": n} for c, s, n in rows])


def validation_row(check_id: str, passed: bool, expected: Any, observed: Any) -> dict[str, str]:
    return {
        "check_id": check_id,
        "status": "PASS" if passed else "FAIL",
        "expected": str(expected),
        "observed": str(observed),
    }


def protected_status_paths(root: Path) -> list[str]:
    completed = subprocess.run(
        ["git", "status", "--short", "--untracked-files=all"],
        cwd=root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    paths: list[str] = []
    for line in completed.stdout.splitlines():
        path = line[3:].replace("\\", "/")
        if any(path.startswith(prefix) for prefix in PROTECTED_PREFIXES):
            paths.append(path)
    return paths


def build_validation(
    config: Mapping[str, Any],
    preflight: pd.DataFrame,
    profile_manifest: pd.DataFrame,
    profile_status_frame: pd.DataFrame,
    universe: pd.DataFrame,
    reuse: pd.DataFrame,
    status: pd.DataFrame,
    accounting: pd.DataFrame,
    matching: pd.DataFrame,
    deltas: pd.DataFrame,
    bootstrap: pd.DataFrame,
    protected_paths: Sequence[str],
) -> pd.DataFrame:
    frozen = config.get("frozen_accounting") or {}
    planned = int(status["planned"].sum()) if not status.empty else 0
    terminal = int(status["terminal"].sum()) if not status.empty else 0
    strict = int(status["strict_valid"].sum()) if not status.empty else 0
    overall_rate = strict / planned if planned else 0.0
    family_ok = bool(not accounting.empty and accounting["strict_validity_rate"].ge(float((config.get("gates") or {})["min_family_strict_validity_rate"])).all())
    rows = [
        validation_row("BACKEND-PREFLIGHT", bool(not preflight.empty and preflight["status"].eq("PASS").all()), "all required models PASS", preflight[["model", "status"]].to_dict("records") if not preflight.empty else []),
        validation_row("PROFILE-COUNT", len(profile_manifest) == int(frozen["target_profiles"]), frozen["target_profiles"], len(profile_manifest)),
        validation_row("PROFILE-REUSE-COUNT", int(profile_manifest["profile_reuse_class"].eq(REUSE_PROFILE).sum()) == int(frozen["exact_reused_profiles"]), frozen["exact_reused_profiles"], int(profile_manifest["profile_reuse_class"].eq(REUSE_PROFILE).sum())),
        validation_row("PROFILE-NEW-COUNT", int(profile_manifest["profile_reuse_class"].eq(NEW_PROFILE).sum()) == int(frozen["new_profile_calls"]), frozen["new_profile_calls"], int(profile_manifest["profile_reuse_class"].eq(NEW_PROFILE).sum())),
        validation_row("PROFILE-COMPLETION", int(profile_status_frame["profile_present"].sum()) == int(frozen["target_profiles"]), frozen["target_profiles"], int(profile_status_frame["profile_present"].sum())),
        validation_row("RANKING-LOGICAL-COUNT", len(universe) == int(frozen["logical_rankings"]), frozen["logical_rankings"], len(universe)),
        validation_row("RANKING-REUSE-COUNT", int(reuse["final_reuse_class"].eq(REUSE_RANKING).sum()) == int(frozen["exact_reused_rankings"]), frozen["exact_reused_rankings"], int(reuse["final_reuse_class"].eq(REUSE_RANKING).sum())),
        validation_row("RANKING-NEW-COUNT", int(reuse["new_inference_required"].eq("true").sum()) == int(frozen["new_ranking_calls"]), frozen["new_ranking_calls"], int(reuse["new_inference_required"].eq("true").sum())),
        validation_row("RANKING-TERMINAL", terminal == int(frozen["logical_rankings"]), frozen["logical_rankings"], terminal),
        validation_row("BACKEND-FAILURES-ZERO", int(status["backend_failure"].sum()) == 0, 0, int(status["backend_failure"].sum()) if not status.empty else 0),
        validation_row("STRICT-VALIDITY-OVERALL", overall_rate >= float((config.get("gates") or {})["min_overall_strict_validity_rate"]), f">={float((config.get('gates') or {})['min_overall_strict_validity_rate'])}", overall_rate),
        validation_row("STRICT-VALIDITY-BY-FAMILY", family_ok, f">={float((config.get('gates') or {})['min_family_strict_validity_rate'])}", accounting[["dataset", "recommender", "condition", "strict_validity_rate"]].to_dict("records") if not accounting.empty else []),
        validation_row("MATCHING-AUDIT", bool(not matching.empty and matching["matching_status"].eq("PASS").all() and len(matching) == 3000), "3000 PASS rows", f"{len(matching)} rows; failures={int(matching['matching_status'].ne('PASS').sum()) if not matching.empty else 'NA'}"),
        validation_row("PAIRED-DELTAS", bool(len(deltas) == 60 and deltas["paired_n"].astype(int).eq(200).all()), "60 rows paired_n=200", f"rows={len(deltas)}; paired={sorted(deltas['paired_n'].astype(str).unique().tolist()) if not deltas.empty else []}"),
        validation_row("BOOTSTRAP", bool(len(bootstrap) == 60 and bootstrap["paired_n"].astype(int).eq(200).all() and bootstrap["bootstrap_resamples"].astype(int).eq(10000).all() and bootstrap["bootstrap_seed"].astype(int).eq(20260901).all() and bootstrap["p_value"].eq("").all() and set(bootstrap["decision"]).issubset(DECISIONS)), "60 bootstrap rows, seed 20260901, no p-values", f"rows={len(bootstrap)}; decisions={bootstrap['decision'].value_counts().to_dict() if not bootstrap.empty else {}}"),
        validation_row("PROTECTED-PATH-CHECK", len(protected_paths) == 0, "no G1/G2/G3/G4 protected path dirty", list(protected_paths)),
    ]
    return pd.DataFrame(rows)


def build_manifest_payload(
    config_path: Path,
    source_root: str,
    preflight: pd.DataFrame,
    profile_manifest: pd.DataFrame,
    profile_status_frame: pd.DataFrame,
    universe: pd.DataFrame,
    reuse: pd.DataFrame,
    status: pd.DataFrame,
    metrics: pd.DataFrame,
    deltas: pd.DataFrame,
    bootstrap: pd.DataFrame,
    validation: pd.DataFrame,
    profile_calls_now: int,
    ranking_calls_now: int,
) -> dict[str, Any]:
    return {
        "phase": PHASE_ID,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "config_path": config_path.as_posix(),
        "source_root": source_root,
        "profile_accounting": {
            "profiles": int(len(profile_manifest)),
            "reused_profiles": int(profile_manifest["profile_reuse_class"].eq(REUSE_PROFILE).sum()),
            "new_profiles": int(profile_manifest["profile_reuse_class"].eq(NEW_PROFILE).sum()),
            "profile_terminal": int(profile_status_frame["terminal"].sum()) if not profile_status_frame.empty else 0,
            "profile_present": int(profile_status_frame["profile_present"].sum()) if not profile_status_frame.empty else 0,
            "profile_calls_executed_this_invocation": int(profile_calls_now),
        },
        "ranking_accounting": {
            "logical_rankings": int(len(universe)),
            "exact_reused_rankings": int(reuse["final_reuse_class"].eq(REUSE_RANKING).sum()),
            "new_rankings": int(reuse["new_inference_required"].eq("true").sum()),
            "ranking_terminal": int(status["terminal"].sum()) if not status.empty else 0,
            "strict_valid": int(status["strict_valid"].sum()) if not status.empty else 0,
            "ranking_calls_executed_this_invocation": int(ranking_calls_now),
        },
        "backend_preflight": preflight.to_dict("records"),
        "metrics": metrics.to_dict("records"),
        "matched_deltas": deltas.to_dict("records"),
        "bootstrap_decision_counts": bootstrap["decision"].value_counts().sort_index().to_dict() if not bootstrap.empty else {},
        "validation_passed": bool(not validation.empty and validation["status"].eq("PASS").all()),
        "validation_failures": validation.loc[validation["status"].ne("PASS"), "check_id"].tolist() if not validation.empty else [],
    }


def frame_to_markdown(frame: pd.DataFrame) -> str:
    if frame.empty:
        return "_empty_"
    text_frame = frame.fillna("").astype(str)
    headers = list(text_frame.columns)
    rows = text_frame.values.tolist()
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(cell.replace("|", "\\|").replace("\n", " ") for cell in row) + " |")
    return "\n".join(lines)


def render_report(manifest: Mapping[str, Any], validation: pd.DataFrame) -> str:
    return "\n".join(
        [
            "# Primary Systematic RQ5 Extension",
            "",
            f"- Phase: `{PHASE_ID}`",
            f"- Validation passed: `{str(manifest['validation_passed']).lower()}`",
            f"- Profiles: `{manifest['profile_accounting']}`",
            f"- Rankings: `{manifest['ranking_accounting']}`",
            f"- Bootstrap decisions: `{manifest['bootstrap_decision_counts']}`",
            "",
            "## Validation",
            "",
            frame_to_markdown(validation),
            "",
        ]
    )


def run_primary(
    root: Path,
    config_path: Path,
    *,
    execute: bool,
    allow_api_calls: bool,
) -> dict[str, Any]:
    config = load_config(config_path)
    preflight = backend_preflight(config)
    write_csv(preflight, output_path(root, config, "backend_preflight"))
    require_preflight(preflight)
    if execute and not allow_api_calls:
        raise RuntimeError("--allow-api-calls is required for primary RQ5 execution")
    contexts, source_root = build_all_contexts(root, config)
    profile_manifest = build_profile_manifest(root, config, contexts, preflight)
    write_csv(profile_manifest, output_path(root, config, "profile_manifest"))
    profile_calls_now = execute_profiles(root, config, profile_manifest, execute=execute)
    profile_status_frame = profile_status(root, profile_manifest)
    require_profiles_complete(profile_status_frame, int((config.get("frozen_accounting") or {})["target_profiles"]))
    profile_manifest = materialize_profile_manifest_hashes(profile_manifest, profile_status_frame)
    write_csv(profile_manifest, output_path(root, config, "profile_manifest"))
    write_csv(profile_status_frame, output_path(root, config, "profile_execution_status"))
    profile_by_id = completed_profiles(root, profile_manifest)
    ranking_universe, reuse = build_ranking_universe(root, config, contexts, profile_manifest, profile_by_id, preflight)
    write_csv(ranking_universe, output_path(root, config, "ranking_universe"))
    write_csv(reuse, output_path(root, config, "ranking_reuse_audit"))
    ranking_calls_now = execute_rankings(root, config, ranking_universe, execute=execute)
    status = ranking_status(root, ranking_universe)
    accounting = build_request_accounting(status)
    metrics = build_metrics(status)
    matching = build_matching_audit(ranking_universe, profile_status_frame)
    contrib = build_paired_contributions(status)
    deltas = build_matched_deltas(contrib)
    bootstrap = build_bootstrap(contrib, config)
    beyond = build_beyond_readiness(ranking_universe, status)
    protected_paths = protected_status_paths(root)
    validation = build_validation(config, preflight, profile_manifest, profile_status_frame, ranking_universe, reuse, status, accounting, matching, deltas, bootstrap, protected_paths)
    manifest = build_manifest_payload(
        config_path,
        source_root,
        preflight,
        profile_manifest,
        profile_status_frame,
        ranking_universe,
        reuse,
        status,
        metrics,
        deltas,
        bootstrap,
        validation,
        profile_calls_now,
        ranking_calls_now,
    )
    write_csv(status, output_path(root, config, "ranking_execution_status"))
    write_csv(accounting, output_path(root, config, "request_accounting"))
    write_csv(matching, output_path(root, config, "matching_audit"))
    write_csv(metrics, output_path(root, config, "metrics"))
    write_csv(contrib, output_path(root, config, "paired_contributions"))
    write_csv(deltas, output_path(root, config, "matched_deltas"))
    write_csv(bootstrap, output_path(root, config, "bootstrap_results"))
    write_csv(beyond, output_path(root, config, "beyond_utility_readiness"))
    write_csv(validation, output_path(root, config, "validation"))
    write_json(output_path(root, config, "manifest"), manifest)
    output_path(root, config, "report").write_text(render_report(manifest, validation), encoding="utf-8")
    return {
        "config": config,
        "preflight": preflight,
        "profile_manifest": profile_manifest,
        "profile_status": profile_status_frame,
        "ranking_universe": ranking_universe,
        "reuse": reuse,
        "status": status,
        "accounting": accounting,
        "metrics": metrics,
        "matching": matching,
        "deltas": deltas,
        "bootstrap": bootstrap,
        "beyond": beyond,
        "validation": validation,
        "manifest": manifest,
    }


def print_summary(result: Mapping[str, Any]) -> None:
    manifest = result["manifest"]
    validation = result["validation"]
    print(f"FINAL_VERDICT={'PASS' if manifest['validation_passed'] else 'FAIL'}")
    print(f"PROFILE_ACCOUNTING={manifest['profile_accounting']}")
    print(f"RANKING_ACCOUNTING={manifest['ranking_accounting']}")
    print(f"BOOTSTRAP_DECISIONS={manifest['bootstrap_decision_counts']}")
    print(f"VALIDATION_FAILURES={validation.loc[validation['status'].ne('PASS'), 'check_id'].tolist() if not validation.empty else []}")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--project-root", default=".")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--allow-api-calls", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    root = Path(args.project_root).resolve()
    config_path = project_path(root, args.config)
    try:
        result = run_primary(root, config_path, execute=bool(args.execute), allow_api_calls=bool(args.allow_api_calls))
    except Exception as exc:
        print(f"RQ5_PRIMARY_SYSTEMATIC_ERROR={type(exc).__name__}: {exc}")
        return 2
    print_summary(result)
    return 0 if result["manifest"]["validation_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
