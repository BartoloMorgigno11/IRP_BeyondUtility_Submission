from __future__ import annotations

import json
import math
import subprocess
from pathlib import Path

import pandas as pd

from src.analysis.rq5_corrected_matched_recovery import (
    PROTECTED_GIT_PATHS,
    build_corrected_matched_recovery,
    hr_at_5,
    ndcg_at_5,
    parse_corrected_response,
    prompt_discloses_positive,
    render_corrected_prompt,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
TABLES = PROJECT_ROOT / "results" / "tables"
MANIFEST = PROJECT_ROOT / "results" / "manifests" / "rq5_corrected_matched_recovery_pilot_v2.json"


def truthy(series: pd.Series) -> pd.Series:
    return series.astype(str).str.lower().isin({"true", "1"})


def sample_row() -> dict[str, str | int]:
    return {
        "candidate_item_ids_json": json.dumps([f"item-{index}" for index in range(1, 21)]),
        "expected_output_count": 10,
        "positive_item_id": "item-3",
    }


def test_rq5_corrected_parser_exact_unique_index_contract() -> None:
    row = sample_row()
    parsed = parse_corrected_response(row, '{"ranked_candidate_indices":[2,3,1,4,5,6,7,8,9,10]}')

    assert parsed["parse_valid"] is True
    assert parsed["ranked_candidate_indices"] == [2, 3, 1, 4, 5, 6, 7, 8, 9, 10]
    assert parsed["ranked_item_ids"] == [
        "item-2",
        "item-3",
        "item-1",
        "item-4",
        "item-5",
        "item-6",
        "item-7",
        "item-8",
        "item-9",
        "item-10",
    ]
    assert parsed["positive_rank"] == 2
    assert parsed["hr_at_5"] == 1.0
    assert parsed["ndcg_at_5"] == 1.0 / math.log2(3)


def test_rq5_corrected_parser_rejects_length_duplicates_range_and_strings() -> None:
    row = sample_row()

    too_short = parse_corrected_response(row, '{"ranked_candidate_indices":[1,2,3]}')
    duplicate = parse_corrected_response(row, '{"ranked_candidate_indices":[1,2,2,4,5,6,7,8,9,10]}')
    out_of_range = parse_corrected_response(row, '{"ranked_candidate_indices":[1,2,21,4,5,6,7,8,9,10]}')
    string_index = parse_corrected_response(row, '{"ranked_candidate_indices":[1,"2",3,4,5,6,7,8,9,10]}')
    prose = parse_corrected_response(row, 'Here: {"ranked_candidate_indices":[1,2,3,4,5,6,7,8,9,10]}')

    assert too_short["parse_valid"] is False
    assert too_short["parse_status"] == "invalid_length"
    assert duplicate["parse_valid"] is False
    assert duplicate["parse_status"] == "duplicate_indices"
    assert out_of_range["parse_valid"] is False
    assert out_of_range["parse_status"] == "unknown_indices"
    assert string_index["parse_valid"] is False
    assert string_index["parse_status"] == "invalid_schema"
    assert prose["parse_valid"] is False
    assert prose["parse_status"] == "parse_failed"
    assert all(result["hr_at_5"] == 0.0 and result["ndcg_at_5"] == 0.0 for result in [too_short, duplicate, out_of_range, string_index, prose])


def test_rq5_corrected_metric_helpers() -> None:
    assert hr_at_5(1) == 1.0
    assert hr_at_5(5) == 1.0
    assert hr_at_5(6) == 0.0
    assert ndcg_at_5(1) == 1.0
    assert ndcg_at_5(5) == 1.0 / math.log2(6)
    assert ndcg_at_5(0) == 0.0
    assert ndcg_at_5(6) == 0.0


def test_rq5_corrected_prompt_hides_positive_labels() -> None:
    prompt = render_corrected_prompt(
        condition="profile_plus_history",
        history_context="Beauty user 7 has purchased items ['A', 'B'].",
        profile_text="This user prefers compact skincare products.",
        candidate_titles=[f"Candidate title {index}" for index in range(1, 21)],
    )

    assert "ranked_candidate_indices" in prompt
    assert "1. Candidate title 1" in prompt
    assert "20. Candidate title 20" in prompt
    assert not prompt_discloses_positive(prompt, "123456", "7")
    assert prompt_discloses_positive(prompt + "\nThe ground truth is candidate 7.", "123456", "7")


def test_rq5_corrected_static_build_preserves_matched_inputs_without_execution() -> None:
    result = build_corrected_matched_recovery(
        PROJECT_ROOT,
        config_path=PROJECT_ROOT / "configs" / "rq5_corrected_matched_recovery.yaml",
        write=False,
        execute_pilot_flag=False,
    )

    assert result.profile_reuse_audit["status"].value_counts().to_dict() == {"REUSABLE": 800}
    assert len(result.matching_audit) == 160
    assert result.matching_audit["matching_status"].eq("PASS").all()
    assert result.manifest["request_count"] == 200


def test_rq5_corrected_written_outputs_have_matched_hashes_and_no_positive_disclosure() -> None:
    matching = pd.read_csv(TABLES / "rq5_corrected_pilot_v2_matching_audit.csv", dtype=str, keep_default_na=False)
    validation = pd.read_csv(TABLES / "rq5_corrected_pilot_v2_validation.csv", dtype=str, keep_default_na=False)
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))

    assert len(matching) == 160
    assert matching["matching_status"].eq("PASS").all()
    assert matching["same_candidate_list_hash"].eq("true").all()
    assert matching["same_candidate_order"].eq("true").all()
    assert matching["same_positive_item"].eq("true").all()
    assert matching["same_positive_candidate_position"].eq("true").all()
    assert manifest["request_count"] == 200
    assert {row["status"] for row in validation.to_dict("records") if row["check_id"] == "PROMPTS-HIDE-POSITIVE-LABELS"} == {"PASS"}


def test_rq5_corrected_request_accounting_gate_when_executed() -> None:
    accounting = pd.read_csv(TABLES / "rq5_corrected_pilot_v2_request_accounting.csv", keep_default_na=False)
    validation = pd.read_csv(TABLES / "rq5_corrected_pilot_v2_validation.csv", keep_default_na=False)

    assert int(accounting["planned"].sum()) == 200
    assert int(accounting.loc[accounting["condition"].eq("history_only"), "planned"].sum()) == 40
    assert int(accounting.loc[accounting["condition"].eq("profile_only"), "planned"].sum()) == 80
    assert int(accounting.loc[accounting["condition"].eq("profile_plus_history"), "planned"].sum()) == 80

    by_check = validation.set_index("check_id")
    backend_failures = int(accounting["backend_failure"].sum())
    if by_check.loc["PILOT-TERMINAL-ACCOUNTING", "status"] == "PASS" and backend_failures == 0:
        planned = int(accounting["planned"].sum())
        strict_valid = int(accounting["strict_valid"].sum())
        invalid_total = int(
            accounting["invalid_length"].sum()
            + accounting["duplicate_index"].sum()
            + accounting["out_of_range_index"].sum()
            + accounting["parse_failure"].sum()
            + accounting["backend_incomplete"].sum()
        )
        if by_check.loc["STRICT-VALIDITY-GATE", "status"] == "PASS":
            assert strict_valid / float(planned) >= 0.98
        assert invalid_total == planned - strict_valid
        assert int(accounting["backend_failure"].sum()) == 0
    else:
        assert by_check.loc["STRICT-VALIDITY-GATE", "status"] == "FAIL"


def test_rq5_corrected_duplicate_forensics_documents_v1_without_repair() -> None:
    forensics = pd.read_csv(TABLES / "rq5_corrected_pilot_v1_duplicate_forensics.csv", keep_default_na=False)

    assert len(forensics) == 10
    assert set(forensics["parse_status"]) == {"duplicate_indices"}
    assert truthy(forensics["json_syntactically_valid"]).all()
    assert (~truthy(forensics["hidden_error_detected"])).all()
    assert pd.to_numeric(forensics["candidate_count"], errors="raise").eq(20).all()
    assert pd.to_numeric(forensics["output_length"], errors="raise").eq(10).all()
    assert pd.to_numeric(forensics["number_of_unique_indices"], errors="raise").lt(10).all()
    assert forensics["prompt_format_instructions"].str.contains("ranked_candidate_indices", regex=False).all()


def test_rq5_corrected_structured_output_audit_does_not_claim_uniqueitems_enforced() -> None:
    audit = pd.read_csv(TABLES / "rq5_corrected_structured_output_capability_audit.csv", keep_default_na=False)

    assert set(audit["model"]) == {"qwen2:7b-instruct", "mistral:7b-instruct"}
    assert truthy(audit["schema_request_accepted"]).all()
    assert (~truthy(audit["unique_items_enforced_by_probe"])).all()
    assert (~truthy(audit["schema_constrained_generation_selected"])).all()


def test_rq5_corrected_v1_v2_comparison_preserves_population_and_identities() -> None:
    comparison = pd.read_csv(TABLES / "rq5_corrected_pilot_v1_vs_v2_contract_comparison.csv", keep_default_na=False)
    overall = comparison.loc[comparison["scope"].eq("overall")].iloc[0]

    assert int(overall["planned_v1"]) == 200
    assert int(overall["planned_v2"]) == 200
    assert str(overall["same_request_population"]).lower() in {"true", "1"}
    assert int(overall["candidate_hash_mismatch_count"]) == 0
    assert int(overall["positive_mismatch_count"]) == 0
    assert int(overall["duplicate_index_v1"]) == 10


def test_rq5_corrected_protected_historical_artifacts_untouched() -> None:
    changed = subprocess.run(
        ["git", "diff", "--name-only", "--", *PROTECTED_GIT_PATHS],
        cwd=PROJECT_ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    assert changed == ""
