from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pandas as pd

from src.analysis.rq5_corrected_matched_full_recovery import (
    NEW_INFERENCE,
    REUSE_PILOT,
    VERDICT_BACKEND,
    VERDICT_READY,
)
from src.analysis.rq5_corrected_matched_recovery import PROTECTED_GIT_PATHS


PROJECT_ROOT = Path(__file__).resolve().parents[1]
TABLES = PROJECT_ROOT / "results" / "tables"
MANIFEST = PROJECT_ROOT / "results" / "manifests" / "rq5_corrected_matched_recovery_full.json"


def test_rq5_corrected_full_universe_has_expected_4000_logical_requests() -> None:
    universe = pd.read_csv(TABLES / "rq5_corrected_full_request_universe.csv", dtype=str, keep_default_na=False)

    assert len(universe) == 4000
    assert universe["request_id"].is_unique
    assert universe["logical_key_sha256"].is_unique
    assert universe.groupby("dataset")["user_id"].nunique().to_dict() == {"beauty": 200, "sports": 200}
    assert universe["condition"].value_counts().to_dict() == {
        "profile_only": 1600,
        "profile_plus_history": 1600,
        "history_only": 800,
    }
    assert universe["positive_label_hidden"].astype(str).str.lower().eq("true").all()


def test_rq5_corrected_full_reuse_audit_prioritizes_pilot_and_requires_new_for_non_exact_g1_g2() -> None:
    reuse = pd.read_csv(TABLES / "rq5_corrected_full_reuse_audit.csv", dtype=str, keep_default_na=False)

    assert len(reuse) == 4000
    assert reuse["final_reuse_class"].value_counts().to_dict() == {
        NEW_INFERENCE: 3800,
        REUSE_PILOT: 200,
    }
    assert reuse["g1_candidate_status"].eq("NOT_EXACTLY_REUSABLE").all()
    assert reuse["g2_candidate_status"].eq("NOT_EXACTLY_REUSABLE").all()
    pilot = reuse[reuse["final_reuse_class"].eq(REUSE_PILOT)]
    assert len(pilot) == 200
    assert pilot["pilot_v2_exact_reusable"].astype(str).str.lower().eq("true").all()
    assert pilot["pilot_v2_parse_valid"].astype(str).str.lower().eq("true").all()


def test_rq5_corrected_full_matching_and_contract_audits_pass() -> None:
    matching = pd.read_csv(TABLES / "rq5_corrected_full_matching_audit.csv", dtype=str, keep_default_na=False)
    contract = pd.read_csv(TABLES / "rq5_corrected_full_canonical_contract_audit.csv", dtype=str, keep_default_na=False)

    assert len(matching) == 3200
    assert matching["matching_status"].eq("PASS").all()
    assert matching["same_candidate_list_hash"].astype(str).str.lower().eq("true").all()
    assert matching["same_candidate_order"].astype(str).str.lower().eq("true").all()
    assert matching["same_positive_item"].astype(str).str.lower().eq("true").all()
    assert matching["dependency_matches_profile"].astype(str).str.lower().eq("true").all()
    assert len(contract) == 3
    assert contract["status"].eq("PASS").all()


def test_rq5_corrected_full_manifest_and_validation_are_ready_or_backend_blocked() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    validation = pd.read_csv(TABLES / "rq5_corrected_full_validation.csv", dtype=str, keep_default_na=False)
    by_check = validation.set_index("check_id")

    assert manifest["logical_request_count"] == 4000
    assert manifest["reuse_summary"] == {NEW_INFERENCE: 3800, REUSE_PILOT: 200}
    assert manifest["verdict"] in {VERDICT_READY, VERDICT_BACKEND}
    assert by_check.loc["FULL-LOGICAL-REQUEST-COUNT", "status"] == "PASS"
    assert by_check.loc["REUSE-ACCOUNTING-EXACT", "status"] == "PASS"
    assert by_check.loc["PROTECTED-HISTORICAL-PATHS-UNTOUCHED", "status"] == "PASS"
    if manifest["verdict"] == VERDICT_READY:
        assert by_check.loc["STRICT-VALIDITY-GATE", "status"] == "PASS"
        assert by_check.loc["NO-SYSTEMATIC-MAJOR-FAMILY-FAILURE", "status"] == "PASS"
        assert manifest["figure_regeneration"] == "REGENERATED_F1_F2_ONLY"
    else:
        assert by_check.loc["BACKEND-RUNTIME-AVAILABLE", "status"] == "FAIL"
        assert by_check.loc["FULL-TERMINAL-ACCOUNTING", "status"] == "FAIL"
        assert manifest["figure_regeneration"] == "SKIPPED_VALIDITY_GATE_NOT_READY"


def test_rq5_corrected_full_metrics_and_bootstrap_contract_shape() -> None:
    metrics = pd.read_csv(TABLES / "rq5_corrected_full_metrics.csv", dtype=str, keep_default_na=False)
    deltas = pd.read_csv(TABLES / "rq5_corrected_full_matched_deltas.csv", dtype=str, keep_default_na=False)
    bootstrap = pd.read_csv(TABLES / "rq5_corrected_full_bootstrap_results.csv", dtype=str, keep_default_na=False)

    assert len(metrics) == 20
    assert set(metrics["metric_source"]) == {"corrected_full_index_rankings_invalid_zero"}
    assert len(deltas) == 32
    assert deltas["paired_n"].astype(int).eq(200).all()
    assert len(bootstrap) == 32
    assert bootstrap["bootstrap_resamples"].astype(int).eq(10000).all()
    assert bootstrap["bootstrap_seed"].astype(int).eq(20260901).all()
    assert bootstrap["p_value"].eq("").all()


def test_rq5_corrected_full_protected_historical_artifacts_untouched() -> None:
    changed = subprocess.run(
        ["git", "diff", "--name-only", "--", *PROTECTED_GIT_PATHS],
        cwd=PROJECT_ROOT,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    assert changed == ""
