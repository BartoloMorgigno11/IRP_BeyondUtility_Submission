"""RQ5 corrected matched-recovery pilot.

This phase is intentionally narrow: it audits whether frozen F6L profile
outputs can be reused, builds a matched Beauty/Sports pilot using the R5D
strict JSON candidate-index contract, optionally executes only the 200-request
pilot, and writes validation artifacts in a new namespace.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import subprocess
import sys
import time
import urllib.error
import urllib.request
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import pandas as pd
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.analysis import reproduction_r5c_history_length_recovery as r5c  # noqa: E402
from src.llm.canonical_llm_contract import parse_strict_index_response  # noqa: E402


PHASE_ID = "RQ5_CORRECTED_MATCHED_RECOVERY_PILOT_V2"
DEFAULT_CONFIG_PATH = Path("configs") / "rq5_corrected_matched_recovery.yaml"
F6L_RUN_ID = "20260801_010000"

VERDICT_READY = "RQ5_CORRECTED_FULL_RECOVERY_READY"
VERDICT_CONTRACT_FAILED = "RQ5_CORRECTED_CONTRACT_V2_NOT_READY_OUTPUT_CONTRACT"
VERDICT_MATCHING_FAILED = "RQ5_CORRECTED_CONTRACT_V2_NOT_READY_MATCHING"
VERDICT_COLLAPSE = "RQ5_CORRECTED_CONTRACT_V2_NOT_READY_SUSPICIOUS_METRIC_COLLAPSE"
VERDICT_PROFILE_BLOCKED = "RQ5_CORRECTED_CONTRACT_V2_NOT_READY_PROFILE_REUSE"

REUSABLE = "REUSABLE"
BLOCKED_MISSING_PROFILE = "BLOCKED_MISSING_PROFILE"
BLOCKED_LINEAGE_MISMATCH = "BLOCKED_LINEAGE_MISMATCH"
BLOCKED_OTHER = "BLOCKED_OTHER"

PARSER_CONTRACT = "r5d_ranked_index_json_top10_v1"
PROMPT_TEMPLATE_ID = "rq5_corrected_matched_json_index_exact10_hardened_v2"
DENOMINATOR_POLICY = "FAIL_STRICT_ALL_MANIFEST_REQUESTS_INVALID_ZERO"

SOURCE_RELS = {
    "parse_results": Path("results/tables/phase_f6l_profile_parse_results.csv"),
    "metrics": Path("results/tables/phase_f6l_profile_metrics.csv"),
    "metric_differences": Path("results/tables/phase_f6l_profile_metric_differences.csv"),
    "recommendation_rows": Path("results/tables/phase_f6l_profile_recommendation_rows.csv"),
    "request_manifest": Path("results/tables/phase_f6l_profile_request_manifest.csv"),
}

PROTECTED_GIT_PATHS = [
    "results/tables/phase_f6l_profile_parse_results.csv",
    "results/tables/phase_f6l_profile_metrics.csv",
    "results/tables/phase_f6l_profile_metric_differences.csv",
    "results/tables/phase_f6l_profile_recommendation_rows.csv",
    "results/tables/phase_f6l_profile_request_manifest.csv",
    "results/llm/phase_f6l_profile_execution_20260801_010000",
    "results/tables/reproduction_r5c_history_length_corrected_results.csv",
    "results/tables/reproduction_r5d_generation_involved_v2_results.csv",
    "results/tables/reproduction_r5d_generation_involved_v2_execution_manifest.csv",
    "results/tables/reproduction_r5d_generation_involved_v2_request_execution_status.csv",
    "results/recovery/r5c_history_length_corrected",
    "results/recovery/r5d_generation_involved_v2",
]


class RQ5CorrectedRecoveryError(RuntimeError):
    """Raised when the corrected RQ5 pilot cannot be constructed safely."""


@dataclass(frozen=True)
class SourcePath:
    rel_path: Path
    path: Path
    scope: str
    sha256: str


@dataclass(frozen=True)
class BuildResult:
    verdict: str
    profile_reuse_audit: pd.DataFrame
    matching_audit: pd.DataFrame
    request_accounting: pd.DataFrame
    metrics: pd.DataFrame
    validation: pd.DataFrame
    duplicate_forensics: pd.DataFrame
    structured_output_capability: pd.DataFrame
    v1_vs_v2_comparison: pd.DataFrame
    report: str
    manifest: dict[str, Any]


def load_config(path: Path | None = None) -> dict[str, Any]:
    config_path = path or DEFAULT_CONFIG_PATH
    with config_path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


def repository_root_from_arg(value: str | None, config: Mapping[str, Any]) -> Path:
    root = Path(value or str(config.get("project_root", "."))).resolve()
    if not (root / "src" / "analysis").exists():
        raise FileNotFoundError(f"Not a project root: {root}")
    return root


def project_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def normalize_rel(path: str | Path) -> str:
    return Path(path).as_posix().replace("\\", "/")


def bool_text(value: bool) -> str:
    return "true" if bool(value) else "false"


def parse_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value or "").strip().lower()
    if text in {"true", "1", "yes", "y", "t"}:
        return True
    if text in {"false", "0", "no", "n", "f", ""}:
        return False
    raise ValueError(f"Unrecognized boolean value: {value!r}")


def stable_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"))


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest().upper()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def stable_id(prefix: str, *parts: Any, length: int = 20) -> str:
    return f"{prefix}-{sha256_text(stable_json([str(part) for part in parts]))[:length]}"


def source_candidates(root: Path, rel_path: Path) -> list[tuple[Path, str]]:
    candidates: list[tuple[Path, str]] = [(root / rel_path, "local_current_worktree")]
    for sibling in sorted(root.parent.glob("IRP_BeyondUtility*")):
        if sibling.resolve() == root.resolve():
            continue
        candidates.append((sibling / rel_path, "external_read_only"))
    return candidates


def resolve_source(root: Path, rel_path: Path) -> SourcePath:
    searched: list[str] = []
    for path, scope in source_candidates(root, rel_path):
        searched.append(str(path))
        if path.exists():
            return SourcePath(rel_path=rel_path, path=path, scope=scope, sha256=sha256_file(path))
    raise FileNotFoundError(f"Missing source {rel_path}; searched: {searched}")


def read_source_csv(root: Path, rel_path: Path) -> pd.DataFrame:
    source = resolve_source(root, rel_path)
    return pd.read_csv(source.path, dtype=str, keep_default_na=False, low_memory=False)


def read_source_json(root: Path, rel_path: str | Path) -> tuple[dict[str, Any], SourcePath]:
    source = resolve_source(root, Path(rel_path))
    with source.path.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise RQ5CorrectedRecoveryError(f"Raw payload is not an object: {rel_path}")
    return payload, source


def write_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, lineterminator="\n")


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=True, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def http_json_post(endpoint: str, payload: Mapping[str, Any], timeout_seconds: int) -> dict[str, Any]:
    data = json.dumps(payload, ensure_ascii=True).encode("utf-8")
    request = urllib.request.Request(
        endpoint,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
        parsed = json.loads(response.read().decode("utf-8"))
    if not isinstance(parsed, dict):
        raise RQ5CorrectedRecoveryError("HTTP JSON response is not an object")
    return parsed


def ranking_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["ranked_candidate_indices"],
        "properties": {
            "ranked_candidate_indices": {
                "type": "array",
                "minItems": 10,
                "maxItems": 10,
                "uniqueItems": True,
                "items": {"type": "integer", "minimum": 1, "maximum": 20},
            }
        },
    }


def source_metadata(root: Path) -> list[dict[str, str]]:
    rows = []
    for name, rel_path in SOURCE_RELS.items():
        source = resolve_source(root, rel_path)
        rows.append(
            {
                "source_name": name,
                "source_file": source.rel_path.as_posix(),
                "source_scope": source.scope,
                "source_sha256": source.sha256,
            }
        )
    return rows


def source_file_string(root: Path, names: Iterable[str]) -> str:
    parts = []
    for name in names:
        source = resolve_source(root, SOURCE_RELS[name])
        parts.append(f"{source.rel_path.as_posix()}[{source.scope}:{source.sha256}]")
    return ";".join(parts)


def load_f6l_manifest(root: Path) -> pd.DataFrame:
    manifest = read_source_csv(root, SOURCE_RELS["request_manifest"]).copy()
    for column in [
        "request_id",
        "dataset",
        "user_id",
        "task",
        "input_variant",
        "model_name",
        "profile_generator_name",
        "recommender_model_name",
        "dependency_request_id",
        "candidate_list_hash",
        "positive_item_id",
        "positive_candidate_position",
        "history_hash",
    ]:
        if column in manifest.columns:
            manifest[column] = manifest[column].astype(str)
    return manifest


def load_f6l_parse(root: Path) -> pd.DataFrame:
    parse = read_source_csv(root, SOURCE_RELS["parse_results"]).copy()
    for column in [
        "request_id",
        "run_id",
        "dataset",
        "user_id",
        "model_name",
        "profile_generator_name",
        "recommender_model_name",
        "input_variant",
        "dependency_request_id",
        "candidate_list_hash",
        "positive_item_id",
        "positive_candidate_position",
        "source_file",
    ]:
        if column in parse.columns:
            parse[column] = parse[column].astype(str)
    parse["hit_at_5_numeric"] = pd.to_numeric(parse["hit_at_5"], errors="raise")
    parse["ndcg_at_5_numeric"] = pd.to_numeric(parse["ndcg_at_5"], errors="raise")
    parse["strict_valid_bool"] = parse["strict_valid"].map(parse_bool)
    return parse


def raw_rel_for_request(request_id: str) -> Path:
    return Path("results/llm") / f"phase_f6l_profile_execution_{F6L_RUN_ID}" / f"{request_id}.json"


def profile_text_from_raw(payload: Mapping[str, Any]) -> str:
    value = payload.get("raw_response")
    if isinstance(value, str) and value.strip():
        return value.strip()
    ollama = payload.get("ollama_response")
    if isinstance(ollama, Mapping):
        response = ollama.get("response")
        if isinstance(response, str) and response.strip():
            return response.strip()
    return ""


def raw_response_text(payload: Mapping[str, Any]) -> str:
    value = payload.get("response_text")
    if isinstance(value, str):
        return value
    value = payload.get("raw_response")
    if isinstance(value, str):
        return value
    ollama = payload.get("ollama_raw_response")
    if isinstance(ollama, Mapping) and isinstance(ollama.get("response"), str):
        return str(ollama["response"])
    ollama = payload.get("ollama_response")
    if isinstance(ollama, Mapping) and isinstance(ollama.get("response"), str):
        return str(ollama["response"])
    return ""


def json_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value]
    if isinstance(value, str) and value.strip():
        parsed = json.loads(value)
        if isinstance(parsed, list):
            return [str(item) for item in parsed]
    return []


def candidate_item_ids_from_raw(payload: Mapping[str, Any]) -> list[str]:
    return json_list(payload.get("candidate_item_ids"))


def candidate_item_titles_from_raw(payload: Mapping[str, Any]) -> list[str]:
    return json_list(payload.get("candidate_item_titles"))


def manifest_row_from_raw(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    row = payload.get("manifest_row")
    return row if isinstance(row, Mapping) else {}


def sorted_users(values: Iterable[str]) -> list[str]:
    def key(value: str) -> tuple[int, str]:
        text = str(value)
        return (int(text), text) if text.isdigit() else (10**18, text)

    return sorted({str(value) for value in values}, key=key)


def row_lookup(frame: pd.DataFrame, **filters: str) -> pd.Series:
    mask = pd.Series([True] * len(frame), index=frame.index)
    for column, value in filters.items():
        mask &= frame[column].eq(str(value))
    subset = frame.loc[mask]
    if len(subset) != 1:
        raise RQ5CorrectedRecoveryError(f"Expected one row for {filters}, found {len(subset)}")
    return subset.iloc[0]


def rows_lookup(frame: pd.DataFrame, **filters: str) -> pd.DataFrame:
    mask = pd.Series([True] * len(frame), index=frame.index)
    for column, value in filters.items():
        mask &= frame[column].eq(str(value))
    return frame.loc[mask].copy()


def profile_generation_rows(manifest: pd.DataFrame, datasets: Sequence[str], profile_generators: Sequence[str]) -> pd.DataFrame:
    return manifest.loc[
        manifest["task"].eq("profile_generation")
        & manifest["dataset"].isin(set(datasets))
        & manifest["profile_generator_name"].isin(set(profile_generators))
    ].copy()


def build_profile_reuse_audit(root: Path, config: Mapping[str, Any], manifest: pd.DataFrame) -> pd.DataFrame:
    scope = config.get("scope") or {}
    datasets = [str(value) for value in scope.get("datasets", [])]
    recommenders = [str(value) for value in scope.get("recommenders", [])]
    profile_generators = [str(value) for value in scope.get("profile_generators", [])]
    source_file = source_file_string(root, ["request_manifest"])
    rows: list[dict[str, Any]] = []
    for record in profile_generation_rows(manifest, datasets, profile_generators).to_dict("records"):
        request_id = str(record["request_id"])
        rel = raw_rel_for_request(request_id)
        status = REUSABLE
        reason = ""
        profile_text = ""
        profile_hash = ""
        raw_scope = ""
        raw_sha = ""
        raw_status = ""
        try:
            payload, raw_source = read_source_json(root, rel)
            raw_scope = raw_source.scope
            raw_sha = raw_source.sha256
            raw_status = str(payload.get("status", ""))
            profile_text = profile_text_from_raw(payload)
            raw_manifest = manifest_row_from_raw(payload)
            lineage_ok = (
                str(raw_manifest.get("request_id", request_id)) == request_id
                and str(raw_manifest.get("dataset", record["dataset"])) == str(record["dataset"])
                and str(raw_manifest.get("user_id", record["user_id"])) == str(record["user_id"])
                and str(raw_manifest.get("profile_generator_name", record["profile_generator_name"]))
                == str(record["profile_generator_name"])
            )
            if raw_status != "completed" or not profile_text:
                status = BLOCKED_MISSING_PROFILE
                reason = f"raw_status={raw_status}; profile_text_empty={not bool(profile_text)}"
            elif not lineage_ok:
                status = BLOCKED_LINEAGE_MISMATCH
                reason = "raw manifest row does not match profile request dataset/user/generator"
        except FileNotFoundError:
            status = BLOCKED_MISSING_PROFILE
            reason = f"missing raw profile {rel.as_posix()}"
        except Exception as exc:
            status = BLOCKED_OTHER
            reason = str(exc)
        if profile_text:
            profile_hash = sha256_text(profile_text)

        expected_dependency_rows = 0
        observed_dependency_rows = 0
        dependency_mismatches: list[str] = []
        for recommender in recommenders:
            for condition in ["profile_only", "profile_plus_history"]:
                expected_dependency_rows += 1
                deps = rows_lookup(
                    manifest,
                    task="ranking",
                    dataset=str(record["dataset"]),
                    user_id=str(record["user_id"]),
                    recommender_model_name=recommender,
                    profile_generator_name=str(record["profile_generator_name"]),
                    input_variant=condition,
                )
                if len(deps) == 1:
                    observed_dependency_rows += 1
                    dep = str(deps.iloc[0]["dependency_request_id"])
                    if dep != request_id:
                        dependency_mismatches.append(f"{recommender}/{condition}->{dep}")
                else:
                    dependency_mismatches.append(f"{recommender}/{condition}:rows={len(deps)}")
        cross_links = manifest.loc[manifest["dependency_request_id"].eq(request_id)].copy()
        cross_link_bad = cross_links.loc[
            ~(
                cross_links["dataset"].eq(str(record["dataset"]))
                & cross_links["user_id"].eq(str(record["user_id"]))
                & cross_links["profile_generator_name"].eq(str(record["profile_generator_name"]))
            )
        ]
        if status == REUSABLE and (dependency_mismatches or not cross_link_bad.empty):
            status = BLOCKED_LINEAGE_MISMATCH
            reason = ";".join(dependency_mismatches) or "dependency cross-link mismatch"

        rows.append(
            {
                "dataset": str(record["dataset"]),
                "user_id": str(record["user_id"]),
                "profile_generator": str(record["profile_generator_name"]),
                "profile_request_id": request_id,
                "status": status,
                "blocking_reason": reason,
                "profile_completed": bool_text(raw_status == "completed"),
                "profile_text_nonempty": bool_text(bool(profile_text)),
                "profile_char_count": len(profile_text),
                "profile_hash": profile_hash,
                "expected_dependency_rows": expected_dependency_rows,
                "observed_dependency_rows": observed_dependency_rows,
                "dependency_mismatch_count": len(dependency_mismatches),
                "cross_link_mismatch_count": int(len(cross_link_bad)),
                "history_hash": str(record.get("history_hash", "")),
                "raw_source_file": rel.as_posix(),
                "raw_source_scope": raw_scope,
                "raw_source_sha256": raw_sha,
                "source_file": source_file,
            }
        )
    return pd.DataFrame(rows).sort_values(["dataset", "profile_generator", "user_id"], kind="mergesort")


def corrected_ranking_instruction(expected_count: int = 10, candidate_count: int = 20) -> str:
    return (
        "Use only the train-history, generated profile when provided, and candidate context below. "
        f"Return exactly {expected_count} ranked candidate indices selected from the {candidate_count} candidates. "
        f"Each value must be an integer between 1 and {candidate_count} inclusive. "
        f"All {expected_count} integers MUST be distinct. "
        "An index MUST NOT appear more than once. "
        "The array order is the ranking order from best to worst. "
        "Valid outputs are candidate POSITIONS, not dataset item IDs. "
        "Do not return item IDs or titles. "
        "Return JSON only, with exactly one key named ranked_candidate_indices and no additional fields: "
        '{"ranked_candidate_indices":[2,5,1,7,4,9,3,8,6,10]}. '
        "Before returning the JSON, verify that ranked_candidate_indices contains exactly "
        f"{expected_count} different integers and that no integer occurs twice. "
        "Do not include rationale, explanation, prose, Markdown, or extra keys."
    )


def extract_history_context(rendered_prompt: str) -> str:
    text = str(rendered_prompt or "").strip()
    marker = " Please select"
    if marker in text:
        return text.split(marker, 1)[0].strip()
    marker = ". Please select"
    if marker in text:
        return text.split(marker, 1)[0].strip()
    marker = "The candidates are:"
    if marker in text:
        return text.split(marker, 1)[0].strip()
    return text


def render_numbered_candidates(candidate_titles: Sequence[str]) -> str:
    if len(candidate_titles) != 20:
        raise ValueError("corrected RQ5 pilot requires exactly 20 candidate titles")
    return "\n".join(f"{index}. {title}" for index, title in enumerate(candidate_titles, start=1))


def render_corrected_prompt(
    *,
    condition: str,
    history_context: str,
    profile_text: str,
    candidate_titles: Sequence[str],
    expected_count: int = 10,
    candidate_count: int = 20,
) -> str:
    blocks: list[str] = []
    if condition in {"history_only", "profile_plus_history"}:
        blocks.append("User interaction history:\n" + history_context.strip())
    if condition in {"profile_only", "profile_plus_history"}:
        if not profile_text.strip():
            raise ValueError("profile condition requires a non-empty profile")
        blocks.append("Generated user profile:\n" + profile_text.strip())
    blocks.append(corrected_ranking_instruction(expected_count, candidate_count))
    blocks.append("Candidates:\n" + render_numbered_candidates(candidate_titles))
    return "\n\n".join(blocks).strip()


def prompt_discloses_positive(prompt: str, positive_item_id: str, positive_position: str) -> bool:
    text = str(prompt)
    lower = text.lower()
    forbidden_phrases = [
        "positive_item",
        "positive item",
        "ground truth",
        "held-out positive",
        "heldout positive",
        "correct item",
        "target item",
        f"candidate {positive_position} is positive".lower(),
    ]
    if any(phrase in lower for phrase in forbidden_phrases):
        return True
    return bool(str(positive_item_id).strip() and f"item id {positive_item_id}" in lower)


def parsed_source_row(parse: pd.DataFrame, *, dataset: str, user_id: str, recommender: str, condition: str, profile_generator: str = "") -> pd.Series:
    filters = {
        "dataset": dataset,
        "user_id": user_id,
        "recommender_model_name": recommender,
        "input_variant": condition,
    }
    if condition == "history_only":
        filters["profile_generator_name"] = ""
    else:
        filters["profile_generator_name"] = profile_generator
    return row_lookup(parse, **filters)


def raw_for_parse_row(root: Path, row: Mapping[str, Any]) -> tuple[dict[str, Any], SourcePath]:
    rel = Path(str(row["source_file"]))
    return read_source_json(root, rel)


def profile_record(
    profile_audit: pd.DataFrame,
    *,
    dataset: str,
    user_id: str,
    profile_generator: str,
) -> pd.Series:
    return row_lookup(
        profile_audit,
        dataset=dataset,
        user_id=user_id,
        profile_generator=profile_generator,
    )


def users_with_reusable_profiles(profile_audit: pd.DataFrame, datasets: Sequence[str], profile_generators: Sequence[str]) -> dict[str, set[str]]:
    result: dict[str, set[str]] = {}
    for dataset in datasets:
        reusable_sets = []
        for generator in profile_generators:
            subset = profile_audit.loc[
                profile_audit["dataset"].eq(dataset)
                & profile_audit["profile_generator"].eq(generator)
                & profile_audit["status"].eq(REUSABLE)
            ]
            reusable_sets.append(set(subset["user_id"].astype(str)))
        result[dataset] = set.intersection(*reusable_sets) if reusable_sets else set()
    return result


def candidate_signature(payload: Mapping[str, Any]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    return tuple(candidate_item_ids_from_raw(payload)), tuple(candidate_item_titles_from_raw(payload))


def build_pilot_requests(
    root: Path,
    config: Mapping[str, Any],
    parse: pd.DataFrame,
    profile_audit: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, list[str]]]:
    scope = config.get("scope") or {}
    outputs = config.get("outputs") or {}
    datasets = [str(value) for value in scope.get("datasets", [])]
    recommenders = [str(value) for value in scope.get("recommenders", [])]
    profile_generators = [str(value) for value in scope.get("profile_generators", [])]
    n_users = int(scope.get("pilot_users_per_dataset", 10))
    expected_count = int(scope.get("expected_output_count", 10))
    candidate_count = int(scope.get("candidate_count", 20))
    raw_namespace = Path(str(outputs["raw_namespace"]))
    reusable_users = users_with_reusable_profiles(profile_audit, datasets, profile_generators)

    selected_users: dict[str, list[str]] = {}
    matching_rows: list[dict[str, Any]] = []
    request_rows: list[dict[str, Any]] = []
    sequence = 1

    for dataset in datasets:
        chosen: list[str] = []
        for user_id in sorted_users(reusable_users.get(dataset, set())):
            user_match_records: list[dict[str, Any]] = []
            try:
                for recommender in recommenders:
                    history_row = parsed_source_row(
                        parse,
                        dataset=dataset,
                        user_id=user_id,
                        recommender=recommender,
                        condition="history_only",
                    )
                    history_payload, history_source = raw_for_parse_row(root, history_row)
                    history_context = extract_history_context(str(history_payload.get("rendered_prompt", "")))
                    history_ids, history_titles = candidate_signature(history_payload)
                    if len(history_ids) != candidate_count or len(history_titles) != candidate_count:
                        raise RQ5CorrectedRecoveryError("history candidate list is not length 20")
                    for generator in profile_generators:
                        prof = profile_record(
                            profile_audit,
                            dataset=dataset,
                            user_id=user_id,
                            profile_generator=generator,
                        )
                        profile_payload, _ = read_source_json(root, raw_rel_for_request(str(prof["profile_request_id"])))
                        profile_text = profile_text_from_raw(profile_payload)
                        for condition in ["profile_only", "profile_plus_history"]:
                            condition_row = parsed_source_row(
                                parse,
                                dataset=dataset,
                                user_id=user_id,
                                recommender=recommender,
                                condition=condition,
                                profile_generator=generator,
                            )
                            condition_payload, _ = raw_for_parse_row(root, condition_row)
                            condition_ids, condition_titles = candidate_signature(condition_payload)
                            hashes_match = str(condition_row["candidate_list_hash"]) == str(history_row["candidate_list_hash"])
                            positives_match = (
                                str(condition_row["positive_item_id"]) == str(history_row["positive_item_id"])
                                and str(condition_row["positive_candidate_position"])
                                == str(history_row["positive_candidate_position"])
                            )
                            candidates_match = condition_ids == history_ids and condition_titles == history_titles
                            dependency_match = str(condition_row["dependency_request_id"]) == str(prof["profile_request_id"])
                            user_match_records.append(
                                {
                                    "dataset": dataset,
                                    "user_id": user_id,
                                    "recommender": recommender,
                                    "profile_generator": generator,
                                    "condition": condition,
                                    "history_request_id": str(history_row["request_id"]),
                                    "condition_request_id": str(condition_row["request_id"]),
                                    "profile_request_id": str(prof["profile_request_id"]),
                                    "candidate_list_hash": str(history_row["candidate_list_hash"]),
                                    "same_candidate_list_hash": bool_text(hashes_match),
                                    "same_candidate_order": bool_text(candidates_match),
                                    "same_positive_item": bool_text(positives_match),
                                    "same_positive_candidate_position": bool_text(
                                        str(condition_row["positive_candidate_position"])
                                        == str(history_row["positive_candidate_position"])
                                    ),
                                    "dependency_matches_profile": bool_text(dependency_match),
                                    "history_context_hash": sha256_text(history_context),
                                    "profile_hash": str(prof["profile_hash"]),
                                    "matching_status": "PASS"
                                    if hashes_match and positives_match and candidates_match and dependency_match
                                    else "FAIL",
                                    "details": "",
                                }
                            )
                if all(row["matching_status"] == "PASS" for row in user_match_records):
                    chosen.append(user_id)
                    matching_rows.extend(user_match_records)
            except Exception as exc:
                matching_rows.append(
                    {
                        "dataset": dataset,
                        "user_id": user_id,
                        "recommender": "",
                        "profile_generator": "",
                        "condition": "",
                        "history_request_id": "",
                        "condition_request_id": "",
                        "profile_request_id": "",
                        "candidate_list_hash": "",
                        "same_candidate_list_hash": "false",
                        "same_candidate_order": "false",
                        "same_positive_item": "false",
                        "same_positive_candidate_position": "false",
                        "dependency_matches_profile": "false",
                        "history_context_hash": "",
                        "profile_hash": "",
                        "matching_status": "FAIL",
                        "details": str(exc),
                    }
                )
            if len(chosen) == n_users:
                break
        selected_users[dataset] = chosen
        if len(chosen) != n_users:
            continue

        for user_id in chosen:
            for recommender in recommenders:
                history_row = parsed_source_row(
                    parse,
                    dataset=dataset,
                    user_id=user_id,
                    recommender=recommender,
                    condition="history_only",
                )
                history_payload, history_source = raw_for_parse_row(root, history_row)
                history_context = extract_history_context(str(history_payload.get("rendered_prompt", "")))
                history_ids, history_titles = candidate_signature(history_payload)
                history_prompt = render_corrected_prompt(
                    condition="history_only",
                    history_context=history_context,
                    profile_text="",
                    candidate_titles=history_titles,
                    expected_count=expected_count,
                    candidate_count=candidate_count,
                )
                request_rows.append(
                    pilot_request_row(
                        sequence=sequence,
                        condition="history_only",
                        source_row=history_row,
                        recommender=recommender,
                        profile_generator="none",
                        profile_request_id="",
                        profile_hash="",
                        profile_text="",
                        candidate_ids=history_ids,
                        candidate_titles=history_titles,
                        prompt_render=history_prompt,
                        history_context_hash=sha256_text(history_context),
                        history_source_scope=history_source.scope,
                        output_namespace=raw_namespace,
                    )
                )
                sequence += 1
                for generator in profile_generators:
                    prof = profile_record(
                        profile_audit,
                        dataset=dataset,
                        user_id=user_id,
                        profile_generator=generator,
                    )
                    profile_payload, _ = read_source_json(root, raw_rel_for_request(str(prof["profile_request_id"])))
                    profile_text = profile_text_from_raw(profile_payload)
                    for condition in ["profile_only", "profile_plus_history"]:
                        condition_row = parsed_source_row(
                            parse,
                            dataset=dataset,
                            user_id=user_id,
                            recommender=recommender,
                            condition=condition,
                            profile_generator=generator,
                        )
                        condition_payload, condition_source = raw_for_parse_row(root, condition_row)
                        condition_ids, condition_titles = candidate_signature(condition_payload)
                        prompt = render_corrected_prompt(
                            condition=condition,
                            history_context=history_context,
                            profile_text=profile_text,
                            candidate_titles=condition_titles,
                            expected_count=expected_count,
                            candidate_count=candidate_count,
                        )
                        request_rows.append(
                            pilot_request_row(
                                sequence=sequence,
                                condition=condition,
                                source_row=condition_row,
                                recommender=recommender,
                                profile_generator=generator,
                                profile_request_id=str(prof["profile_request_id"]),
                                profile_hash=str(prof["profile_hash"]),
                                profile_text=profile_text,
                                candidate_ids=condition_ids,
                                candidate_titles=condition_titles,
                                prompt_render=prompt,
                                history_context_hash=sha256_text(history_context),
                                history_source_scope=condition_source.scope,
                                output_namespace=raw_namespace,
                            )
                        )
                        sequence += 1

    requests = pd.DataFrame(request_rows)
    if not requests.empty:
        requests = requests.sort_values(
            ["dataset", "user_id", "recommender_model_name", "profile_generator_name", "condition"],
            kind="mergesort",
        ).reset_index(drop=True)
        requests["request_id"] = [
            f"RQ5CMR-PILOT-REQ-{index:04d}" for index in range(1, len(requests) + 1)
        ]
        requests["output_destination"] = requests["request_id"].map(
            lambda request_id: normalize_rel(raw_namespace / f"{request_id}.json")
        )
        requests["request_key_sha256"] = requests.apply(
            lambda row: sha256_text(
                stable_json(
                    {
                        "phase": PHASE_ID,
                        "f6l_request_id": row["f6l_request_id"],
                        "condition": row["condition"],
                        "candidate_list_hash": row["candidate_list_hash"],
                        "prompt_hash": row["prompt_hash"],
                    }
                )
            ),
            axis=1,
        )
    matching = pd.DataFrame(matching_rows)
    return requests, matching, selected_users


def pilot_request_row(
    *,
    sequence: int,
    condition: str,
    source_row: Mapping[str, Any],
    recommender: str,
    profile_generator: str,
    profile_request_id: str,
    profile_hash: str,
    profile_text: str,
    candidate_ids: Sequence[str],
    candidate_titles: Sequence[str],
    prompt_render: str,
    history_context_hash: str,
    history_source_scope: str,
    output_namespace: Path,
) -> dict[str, Any]:
    positive_item_id = str(source_row["positive_item_id"])
    positive_position = str(source_row["positive_candidate_position"])
    return {
        "request_id": f"PENDING-{sequence:04d}",
        "sequence": sequence,
        "phase": PHASE_ID,
        "f6l_request_id": str(source_row["request_id"]),
        "dataset": str(source_row["dataset"]),
        "user_id": str(source_row["user_id"]),
        "model_name": recommender,
        "recommender_model_name": recommender,
        "profile_generator_name": profile_generator,
        "condition": condition,
        "input_variant": condition,
        "profile_request_id": profile_request_id,
        "profile_hash": profile_hash,
        "candidate_list_hash": str(source_row["candidate_list_hash"]),
        "candidate_item_ids_json": stable_json([str(item) for item in candidate_ids]),
        "candidate_item_titles_json": stable_json([str(item) for item in candidate_titles]),
        "candidate_count": len(candidate_ids),
        "positive_item_id": positive_item_id,
        "positive_candidate_position": positive_position,
        "prompt_template_id": PROMPT_TEMPLATE_ID,
        "parser_contract": PARSER_CONTRACT,
        "expected_output_schema": stable_json({"ranked_candidate_indices": list(range(1, 11))}),
        "expected_output_count": 10,
        "candidate_index_base": 1,
        "temperature": 0,
        "seed": 0,
        "max_new_tokens": 256,
        "prompt_render": prompt_render,
        "prompt_hash": sha256_text(prompt_render),
        "positive_label_hidden": bool_text(not prompt_discloses_positive(prompt_render, positive_item_id, positive_position)),
        "history_context_hash": history_context_hash,
        "profile_char_count": len(profile_text),
        "source_file": str(source_row["source_file"]),
        "source_scope": history_source_scope,
        "output_destination": normalize_rel(output_namespace / f"PENDING-{sequence:04d}.json"),
        "metric_denominator_policy": DENOMINATOR_POLICY,
    }


def candidate_ids_from_request(row: Mapping[str, Any]) -> list[str]:
    return json_list(row.get("candidate_item_ids_json"))


def candidate_titles_from_request(row: Mapping[str, Any]) -> list[str]:
    return json_list(row.get("candidate_item_titles_json"))


def positive_rank(row: Mapping[str, Any], ranked_item_ids: Sequence[str]) -> int:
    positive = str(row.get("positive_item_id", ""))
    for index, item_id in enumerate(ranked_item_ids, start=1):
        if str(item_id) == positive:
            return index
    return 0


def hr_at_5(rank: int) -> float:
    return 1.0 if 1 <= int(rank) <= 5 else 0.0


def ndcg_at_5(rank: int) -> float:
    return float(1.0 / math.log2(int(rank) + 1)) if 1 <= int(rank) <= 5 else 0.0


def validity_class_from_status(status: str) -> str:
    mapping = {
        "parsed_valid": "VALID",
        "invalid_length": "INVALID_LENGTH",
        "duplicate_indices": "DUPLICATE_INDEX",
        "unknown_indices": "OUT_OF_RANGE_INDEX",
        "missing_permutation_indices": "OUT_OF_RANGE_INDEX",
        "parse_failed": "PARSE_FAILURE",
        "invalid_schema": "PARSE_FAILURE",
        "empty_output": "PARSE_FAILURE",
        "backend_failed": "BACKEND_FAILED",
        "backend_incomplete": "BACKEND_INCOMPLETE",
        "not_executed": "NOT_EXECUTED",
    }
    return mapping.get(status, "PARSE_FAILURE")


def parse_corrected_response(row: Mapping[str, Any], response_text: str) -> dict[str, Any]:
    candidate_ids = candidate_ids_from_request(row)
    expected_count = int(row.get("expected_output_count", 10) or 10)
    parsed = parse_strict_index_response(
        response_text,
        candidate_items=candidate_ids,
        expected_count=expected_count,
        require_full_permutation=False,
    )
    rank = positive_rank(row, parsed.output_items) if parsed.parse_valid else 0
    return {
        "parse_valid": bool(parsed.parse_valid),
        "parse_status": parsed.status,
        "parse_error": parsed.error,
        "validity_class": validity_class_from_status(parsed.status),
        "ranked_candidate_indices": list(parsed.output_indices),
        "ranked_item_ids": list(parsed.output_items),
        "duplicate_count": int(parsed.duplicate_count),
        "unknown_item_count": int(parsed.unknown_item_count),
        "output_length": int(parsed.output_length),
        "expected_output_count": expected_count,
        "positive_rank": rank,
        "hr_at_5": hr_at_5(rank) if parsed.parse_valid else 0.0,
        "ndcg_at_5": ndcg_at_5(rank) if parsed.parse_valid else 0.0,
        "metric_ready": bool(parsed.parse_valid),
    }


def duplicated_indices(values: Sequence[Any]) -> list[int]:
    counts = Counter(int(value) for value in values if isinstance(value, int) and not isinstance(value, bool))
    return sorted(index for index, count in counts.items() if count > 1)


def prompt_format_instructions(prompt: str) -> str:
    text = str(prompt or "")
    start_markers = [
        "Use only the train-history, generated profile when provided, and candidate context below.",
        "Use only the train-history",
        "Return exactly",
    ]
    starts = [text.find(marker) for marker in start_markers if text.find(marker) >= 0]
    start = min(starts) if starts else 0
    end = text.find("\n\nCandidates:", start)
    if end < 0:
        end = text.find("Candidates:", start)
    return text[start : end if end >= 0 else len(text)].strip()


def build_duplicate_forensics(root: Path, config: Mapping[str, Any], requests: pd.DataFrame) -> pd.DataFrame:
    prior = config.get("prior_pilot_v1") or {}
    namespace = Path(str(prior.get("raw_namespace", "results/llm/rq5_corrected_matched_recovery_pilot")))
    rows: list[dict[str, Any]] = []
    for request in requests.to_dict("records"):
        raw_path = project_path(root, namespace / f"{request['request_id']}.json")
        if not raw_path.exists():
            continue
        payload = json.loads(raw_path.read_text(encoding="utf-8"))
        parse_record = payload.get("parse") if isinstance(payload.get("parse"), Mapping) else {}
        if str(parse_record.get("parse_status", "")) != "duplicate_indices":
            continue
        response_text = raw_response_text(payload)
        syntax_valid = True
        parsed_json: Any = {}
        try:
            parsed_json = json.loads(response_text)
        except json.JSONDecodeError:
            syntax_valid = False
        returned_indices = (
            parsed_json.get("ranked_candidate_indices", [])
            if isinstance(parsed_json, dict)
            else parse_record.get("ranked_candidate_indices", [])
        )
        if not isinstance(returned_indices, list):
            returned_indices = []
        duplicate_values = duplicated_indices(returned_indices)
        candidate_ids = payload.get("candidate_item_ids")
        if not isinstance(candidate_ids, list):
            candidate_ids = candidate_ids_from_request(request)
        rows.append(
            {
                "request_id": str(request["request_id"]),
                "dataset": str(request["dataset"]),
                "recommender": str(request["recommender_model_name"]),
                "condition": str(request["condition"]),
                "profile_generator": str(request["profile_generator_name"]),
                "user_id": str(request["user_id"]),
                "raw_returned_json": response_text,
                "returned_index_sequence": stable_json(returned_indices),
                "duplicated_indices": stable_json(duplicate_values),
                "number_of_unique_indices": len(set(int(value) for value in returned_indices if isinstance(value, int) and not isinstance(value, bool))),
                "candidate_count": len(candidate_ids),
                "json_syntactically_valid": bool_text(syntax_valid),
                "parse_status": str(parse_record.get("parse_status", "")),
                "output_length": int(parse_record.get("output_length", 0) or 0),
                "expected_output_count": int(parse_record.get("expected_output_count", 10) or 10),
                "duplicate_count": int(parse_record.get("duplicate_count", 0) or 0),
                "unknown_item_count": int(parse_record.get("unknown_item_count", 0) or 0),
                "hidden_error_detected": bool_text(
                    (not syntax_valid)
                    or int(parse_record.get("output_length", 0) or 0) != int(parse_record.get("expected_output_count", 10) or 10)
                    or int(parse_record.get("unknown_item_count", 0) or 0) != 0
                ),
                "prompt_format_instructions": prompt_format_instructions(str(payload.get("prompt_render", ""))),
                "source_raw_file": normalize_rel(raw_path),
            }
        )
    return pd.DataFrame(rows).sort_values(["dataset", "recommender", "condition", "profile_generator", "user_id"], kind="mergesort")


def build_structured_output_capability_audit(
    config: Mapping[str, Any],
    *,
    run_probe: bool,
) -> pd.DataFrame:
    runtime = config.get("runtime") or {}
    scope = config.get("scope") or {}
    models = [str(value) for value in scope.get("recommenders", [])]
    tags_endpoint = str(runtime.get("tags_endpoint", "http://127.0.0.1:11434/api/tags"))
    version_endpoint = str(runtime.get("version_endpoint", "http://127.0.0.1:11434/api/version"))
    endpoint = str(runtime.get("endpoint", "http://127.0.0.1:11434/api/generate"))
    timeout = int(runtime.get("timeout_seconds", 120))
    schema = ranking_schema()
    rows: list[dict[str, Any]] = []
    version = ""
    backend_available = False
    tags: dict[str, Any] = {}
    try:
        version_payload = r5c.http_json_get(version_endpoint, timeout)
        version = str(version_payload.get("version", ""))
        tags = r5c.http_json_get(tags_endpoint, timeout)
        backend_available = True
    except Exception as exc:
        for model in models:
            rows.append(
                {
                    "model": model,
                    "ollama_version": version,
                    "backend_available": "false",
                    "model_available": "false",
                    "schema_probe_run": bool_text(run_probe),
                    "schema_request_accepted": "false",
                    "json_syntactically_valid": "false",
                    "unique_items_enforced_by_probe": "false",
                    "schema_constrained_generation_selected": "false",
                    "probe_response": "",
                    "error": str(exc),
                }
            )
        return pd.DataFrame(rows)
    available_models = {
        str(item.get("name", ""))
        for item in tags.get("models", [])
        if isinstance(item, Mapping)
    }
    for model in models:
        model_available = model in available_models
        accepted = False
        syntax_valid = False
        unique_enforced = False
        response_text = ""
        error = ""
        if run_probe and model_available:
            payload = {
                "model": model,
                "stream": False,
                "format": schema,
                "options": {"temperature": 0, "seed": 0, "num_predict": 128},
                "prompt": (
                    "Non-scientific schema probe. Return JSON only. "
                    "Intentionally try to return duplicate index 1 twice in ranked_candidate_indices while keeping length 10."
                ),
            }
            try:
                started = time.perf_counter()
                raw = http_json_post(endpoint, payload, timeout)
                _latency = time.perf_counter() - started
                response_text = str(raw.get("response", ""))
                accepted = True
                parsed = json.loads(response_text)
                syntax_valid = isinstance(parsed, dict)
                values = parsed.get("ranked_candidate_indices", []) if isinstance(parsed, dict) else []
                unique_enforced = (
                    isinstance(values, list)
                    and len(values) == 10
                    and len(set(values)) == 10
                    and all(isinstance(value, int) and 1 <= value <= 20 for value in values)
                )
            except Exception as exc:
                error = str(exc)
        rows.append(
            {
                "model": model,
                "ollama_version": version,
                "backend_available": bool_text(backend_available),
                "model_available": bool_text(model_available),
                "schema_probe_run": bool_text(run_probe),
                "schema_request_accepted": bool_text(accepted),
                "json_syntactically_valid": bool_text(syntax_valid),
                "unique_items_enforced_by_probe": bool_text(unique_enforced),
                "schema_constrained_generation_selected": "false",
                "probe_response": response_text,
                "error": error,
                "decision": (
                    "SCHEMA_ACCEPTED_BUT_UNIQUE_ITEMS_NOT_ENFORCED"
                    if accepted and syntax_valid and not unique_enforced
                    else ("SCHEMA_CAPABILITY_NOT_PROBED" if not run_probe else "SCHEMA_UNIQUE_ITEMS_OBSERVED")
                ),
            }
        )
    return pd.DataFrame(rows)


def backend_failed_payload(row: Mapping[str, Any], error: str) -> dict[str, Any]:
    parse_record = {
        "parse_valid": False,
        "parse_status": "backend_failed",
        "parse_error": error,
        "validity_class": "BACKEND_FAILED",
        "ranked_candidate_indices": [],
        "ranked_item_ids": [],
        "duplicate_count": 0,
        "unknown_item_count": 0,
        "output_length": 0,
        "expected_output_count": int(row.get("expected_output_count", 10) or 10),
        "positive_rank": 0,
        "hr_at_5": 0.0,
        "ndcg_at_5": 0.0,
        "metric_ready": False,
    }
    return build_raw_payload(row, "BACKEND_FAILED", "", parse_record, {}, error, 0.0, "", "")


def build_raw_payload(
    row: Mapping[str, Any],
    execution_status: str,
    response_text: str,
    parse_record: Mapping[str, Any],
    raw_response: Mapping[str, Any],
    error: str,
    latency_seconds: float,
    runtime_model_id: str,
    done_reason: str,
) -> dict[str, Any]:
    return {
        "phase": PHASE_ID,
        "request_id": str(row["request_id"]),
        "f6l_request_id": str(row["f6l_request_id"]),
        "dataset": str(row["dataset"]),
        "user_id": str(row["user_id"]),
        "model_name": str(row["model_name"]),
        "profile_generator_name": str(row["profile_generator_name"]),
        "condition": str(row["condition"]),
        "execution_status": execution_status,
        "backend_complete": bool_text(execution_status == "SUCCEEDED"),
        "response_text": response_text,
        "parse": dict(parse_record),
        "candidate_item_ids": candidate_ids_from_request(row),
        "candidate_item_titles": candidate_titles_from_request(row),
        "candidate_list_hash": str(row["candidate_list_hash"]),
        "positive_item_id": str(row["positive_item_id"]),
        "positive_candidate_position": str(row["positive_candidate_position"]),
        "prompt_template_id": PROMPT_TEMPLATE_ID,
        "parser_contract": PARSER_CONTRACT,
        "prompt_hash": str(row["prompt_hash"]),
        "prompt_render": str(row["prompt_render"]),
        "metric_denominator_policy": DENOMINATOR_POLICY,
        "runtime_backend": "local_ollama",
        "runtime_model_id": runtime_model_id,
        "ollama_done_reason": done_reason,
        "ollama_raw_response": dict(raw_response),
        "error": error,
        "latency_seconds": latency_seconds,
    }


def execute_pilot(
    root: Path,
    config: Mapping[str, Any],
    requests: pd.DataFrame,
    *,
    execute: bool,
    allow_api_calls: bool,
    allow_local_ollama: bool,
    rerun_backend_failed: bool = False,
) -> None:
    if not execute:
        return
    if not allow_api_calls:
        raise RQ5CorrectedRecoveryError("pilot execution requires --allow-api-calls")
    if not allow_local_ollama:
        raise RQ5CorrectedRecoveryError("pilot execution requires --allow-local-ollama")
    outputs = config.get("outputs") or {}
    namespace = project_path(root, outputs["raw_namespace"]).resolve()
    namespace.mkdir(parents=True, exist_ok=True)
    models = sorted(set(requests["model_name"].astype(str)))
    runtime_available, runtime_error, _tags = r5c.validate_runtime_available(config, models)
    if not runtime_available:
        raise RQ5CorrectedRecoveryError(f"backend_unavailable: {runtime_error}")
    for row in requests.to_dict("records"):
        destination = project_path(root, row["output_destination"])
        if destination.exists():
            if not rerun_backend_failed:
                continue
            existing = json.loads(destination.read_text(encoding="utf-8"))
            if str(existing.get("execution_status", "")) != "BACKEND_FAILED":
                continue
        runtime = r5c.generate_local_ollama(row, config)
        if not runtime.response_received:
            payload = backend_failed_payload(row, runtime.error)
        elif not runtime.backend_complete:
            parse_record = parse_corrected_response(row, runtime.response_text)
            parse_record["parse_valid"] = False
            parse_record["parse_status"] = "backend_incomplete"
            parse_record["validity_class"] = "BACKEND_INCOMPLETE"
            parse_record["hr_at_5"] = 0.0
            parse_record["ndcg_at_5"] = 0.0
            payload = build_raw_payload(
                row,
                "BACKEND_INCOMPLETE",
                runtime.response_text,
                parse_record,
                runtime.raw_response or {},
                runtime.error,
                runtime.latency_seconds,
                runtime.runtime_model_id,
                runtime.done_reason,
            )
        else:
            parse_record = parse_corrected_response(row, runtime.response_text)
            payload = build_raw_payload(
                row,
                "SUCCEEDED",
                runtime.response_text,
                parse_record,
                runtime.raw_response or {},
                "",
                runtime.latency_seconds,
                runtime.runtime_model_id,
                runtime.done_reason,
            )
        write_json(destination, payload)


def status_from_payload(row: Mapping[str, Any], payload: Mapping[str, Any], file_sha: str) -> dict[str, Any]:
    parse_record = payload.get("parse") if isinstance(payload.get("parse"), Mapping) else {}
    execution_status = str(payload.get("execution_status", payload.get("status", "SUCCEEDED")))
    parse_status = str(parse_record.get("parse_status", parse_record.get("status", "")))
    return {
        "request_id": str(row["request_id"]),
        "dataset": str(row["dataset"]),
        "user_id": str(row["user_id"]),
        "recommender": str(row["model_name"]),
        "condition": str(row["condition"]),
        "profile_generator": str(row["profile_generator_name"]),
        "planned": 1,
        "completed": 1 if execution_status == "SUCCEEDED" else 0,
        "terminal": 1,
        "strict_valid": 1 if parse_bool(parse_record.get("parse_valid", False)) else 0,
        "invalid_length": 1 if parse_status == "invalid_length" else 0,
        "duplicate_index": 1 if parse_status == "duplicate_indices" else 0,
        "out_of_range_index": 1 if parse_status == "unknown_indices" else 0,
        "parse_failure": 1 if validity_class_from_status(parse_status) == "PARSE_FAILURE" else 0,
        "backend_failure": 1 if execution_status == "BACKEND_FAILED" else 0,
        "backend_incomplete": 1 if execution_status == "BACKEND_INCOMPLETE" else 0,
        "parse_status": parse_status,
        "validity_class": str(parse_record.get("validity_class", validity_class_from_status(parse_status))),
        "positive_rank": int(parse_record.get("positive_rank", 0) or 0),
        "hr_at_5": float(parse_record.get("hr_at_5", 0.0) or 0.0),
        "ndcg_at_5": float(parse_record.get("ndcg_at_5", 0.0) or 0.0),
        "output_length": int(parse_record.get("output_length", 0) or 0),
        "duplicate_count": int(parse_record.get("duplicate_count", 0) or 0),
        "unknown_item_count": int(parse_record.get("unknown_item_count", 0) or 0),
        "result_file_sha256": file_sha,
    }


def not_executed_status(row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "request_id": str(row["request_id"]),
        "dataset": str(row["dataset"]),
        "user_id": str(row["user_id"]),
        "recommender": str(row["model_name"]),
        "condition": str(row["condition"]),
        "profile_generator": str(row["profile_generator_name"]),
        "planned": 1,
        "completed": 0,
        "terminal": 0,
        "strict_valid": 0,
        "invalid_length": 0,
        "duplicate_index": 0,
        "out_of_range_index": 0,
        "parse_failure": 0,
        "backend_failure": 0,
        "backend_incomplete": 0,
        "parse_status": "not_executed",
        "validity_class": "NOT_EXECUTED",
        "positive_rank": 0,
        "hr_at_5": 0.0,
        "ndcg_at_5": 0.0,
        "output_length": 0,
        "duplicate_count": 0,
        "unknown_item_count": 0,
        "result_file_sha256": "",
    }


def build_request_status(root: Path, requests: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for row in requests.to_dict("records"):
        destination = project_path(root, row["output_destination"])
        if destination.exists():
            payload = json.loads(destination.read_text(encoding="utf-8"))
            rows.append(status_from_payload(row, payload, sha256_file(destination)))
        else:
            rows.append(not_executed_status(row))
    return pd.DataFrame(rows)


def build_request_accounting(status: pd.DataFrame) -> pd.DataFrame:
    group_cols = ["dataset", "recommender", "condition", "profile_generator"]
    if status.empty:
        return pd.DataFrame(
            columns=group_cols
            + [
                "planned",
                "completed",
                "strict_valid",
                "invalid_length",
                "duplicate_index",
                "out_of_range_index",
                "parse_failure",
                "backend_failure",
                "backend_incomplete",
                "strict_validity_rate",
            ]
        )
    grouped = status.groupby(group_cols, as_index=False, sort=True)[
        [
            "planned",
            "completed",
            "strict_valid",
            "invalid_length",
            "duplicate_index",
            "out_of_range_index",
            "parse_failure",
            "backend_failure",
            "backend_incomplete",
        ]
    ].sum()
    grouped["strict_validity_rate"] = grouped["strict_valid"] / grouped["planned"].clip(lower=1)
    return grouped


def build_pilot_metrics(status: pd.DataFrame) -> pd.DataFrame:
    group_cols = ["dataset", "recommender", "condition", "profile_generator"]
    rows: list[dict[str, Any]] = []
    for key, group in status.groupby(group_cols, sort=True):
        dataset, recommender, condition, profile_generator = key
        planned = int(group["planned"].sum())
        strict_valid = int(group["strict_valid"].sum())
        rows.append(
            {
                "dataset": dataset,
                "recommender": recommender,
                "condition": condition,
                "profile_generator": profile_generator,
                "requests": planned,
                "strict_valid": strict_valid,
                "strict_validity_rate": strict_valid / planned if planned else 0.0,
                "hr_at_5": float(group["hr_at_5"].sum() / planned) if planned else 0.0,
                "ndcg_at_5": float(group["ndcg_at_5"].sum() / planned) if planned else 0.0,
                "denominator_policy": DENOMINATOR_POLICY,
                "metric_source": "corrected_index_rankings_invalid_zero",
            }
        )
    return pd.DataFrame(rows)


def status_for_namespace(root: Path, requests: pd.DataFrame, namespace: str | Path) -> pd.DataFrame:
    frame = requests.copy()
    base = Path(namespace)
    frame["output_destination"] = frame["request_id"].map(lambda request_id: normalize_rel(base / f"{request_id}.json"))
    return build_request_status(root, frame)


def summarize_status(status: pd.DataFrame, group_cols: Sequence[str]) -> pd.DataFrame:
    if status.empty:
        return pd.DataFrame()
    if not group_cols:
        totals = {
            column: int(status[column].sum())
            for column in [
                "planned",
                "strict_valid",
                "invalid_length",
                "duplicate_index",
                "out_of_range_index",
                "parse_failure",
                "backend_failure",
                "backend_incomplete",
            ]
        }
        totals["strict_validity_rate"] = totals["strict_valid"] / max(1, totals["planned"])
        return pd.DataFrame([totals])
    grouped = status.groupby(list(group_cols), as_index=False, sort=True)[
        [
            "planned",
            "strict_valid",
            "invalid_length",
            "duplicate_index",
            "out_of_range_index",
            "parse_failure",
            "backend_failure",
            "backend_incomplete",
        ]
    ].sum()
    grouped["strict_validity_rate"] = grouped["strict_valid"] / grouped["planned"].clip(lower=1)
    return grouped


def raw_identity_mismatch_counts(root: Path, requests: pd.DataFrame, left_namespace: str | Path, right_namespace: str | Path) -> tuple[int, int, int]:
    request_mismatch = 0
    candidate_mismatch = 0
    positive_mismatch = 0
    for row in requests.to_dict("records"):
        left_path = project_path(root, Path(left_namespace) / f"{row['request_id']}.json")
        right_path = project_path(root, Path(right_namespace) / f"{row['request_id']}.json")
        if not left_path.exists() or not right_path.exists():
            request_mismatch += 1
            continue
        left = json.loads(left_path.read_text(encoding="utf-8"))
        right = json.loads(right_path.read_text(encoding="utf-8"))
        if str(left.get("request_id", "")) != str(right.get("request_id", "")):
            request_mismatch += 1
        if str(left.get("candidate_list_hash", "")) != str(right.get("candidate_list_hash", "")):
            candidate_mismatch += 1
        if (
            str(left.get("positive_item_id", "")) != str(right.get("positive_item_id", ""))
            or str(left.get("positive_candidate_position", "")) != str(right.get("positive_candidate_position", ""))
        ):
            positive_mismatch += 1
    return request_mismatch, candidate_mismatch, positive_mismatch


def build_v1_vs_v2_comparison(
    root: Path,
    config: Mapping[str, Any],
    requests: pd.DataFrame,
    v2_status: pd.DataFrame,
) -> pd.DataFrame:
    prior = config.get("prior_pilot_v1") or {}
    outputs = config.get("outputs") or {}
    v1_namespace = str(prior.get("raw_namespace", "results/llm/rq5_corrected_matched_recovery_pilot"))
    v2_namespace = str(outputs.get("raw_namespace", "results/llm/rq5_corrected_matched_recovery_pilot_v2"))
    v1_status = status_for_namespace(root, requests, v1_namespace)
    rows: list[dict[str, Any]] = []
    req_mismatch, cand_mismatch, pos_mismatch = raw_identity_mismatch_counts(root, requests, v1_namespace, v2_namespace)

    def append_rows(scope: str, group_cols: Sequence[str]) -> None:
        left = summarize_status(v1_status, group_cols)
        right = summarize_status(v2_status, group_cols)
        if group_cols:
            merged = left.merge(right, on=list(group_cols), how="outer", suffixes=("_v1", "_v2")).fillna(0)
        else:
            left = left.assign(_join_key="overall")
            right = right.assign(_join_key="overall")
            merged = left.merge(right, on="_join_key", how="outer", suffixes=("_v1", "_v2")).fillna(0)
        for record in merged.to_dict("records"):
            row = {"scope": scope}
            for column in ["dataset", "recommender", "condition", "profile_generator"]:
                row[column] = str(record.get(column, "ALL") or "ALL")
            row.update(
                {
                    "planned_v1": int(record.get("planned_v1", 0)),
                    "strict_valid_v1": int(record.get("strict_valid_v1", 0)),
                    "strict_validity_rate_v1": float(record.get("strict_validity_rate_v1", 0.0)),
                    "duplicate_index_v1": int(record.get("duplicate_index_v1", 0)),
                    "other_invalid_reasons_v1": int(
                        record.get("invalid_length_v1", 0)
                        + record.get("out_of_range_index_v1", 0)
                        + record.get("parse_failure_v1", 0)
                        + record.get("backend_failure_v1", 0)
                        + record.get("backend_incomplete_v1", 0)
                    ),
                    "planned_v2": int(record.get("planned_v2", 0)),
                    "strict_valid_v2": int(record.get("strict_valid_v2", 0)),
                    "strict_validity_rate_v2": float(record.get("strict_validity_rate_v2", 0.0)),
                    "duplicate_index_v2": int(record.get("duplicate_index_v2", 0)),
                    "other_invalid_reasons_v2": int(
                        record.get("invalid_length_v2", 0)
                        + record.get("out_of_range_index_v2", 0)
                        + record.get("parse_failure_v2", 0)
                        + record.get("backend_failure_v2", 0)
                        + record.get("backend_incomplete_v2", 0)
                    ),
                    "same_request_population": bool_text(req_mismatch == 0),
                    "candidate_hash_mismatch_count": cand_mismatch,
                    "positive_mismatch_count": pos_mismatch,
                }
            )
            rows.append(row)

    append_rows("overall", [])
    append_rows("major_family", ["dataset", "recommender", "condition"])
    append_rows("detailed_cell", ["dataset", "recommender", "condition", "profile_generator"])
    return pd.DataFrame(rows)


def random_reference() -> dict[str, float]:
    return {
        "hr_at_5": 5.0 / 20.0,
        "ndcg_at_5": sum(1.0 / math.log2(rank + 1) for rank in range(1, 6)) / 20.0,
    }


def protected_git_diff(root: Path) -> list[str]:
    result = subprocess.run(
        ["git", "diff", "--name-only", "--", *PROTECTED_GIT_PATHS],
        cwd=root,
        check=True,
        capture_output=True,
        text=True,
    )
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def add_validation(rows: list[dict[str, Any]], check_id: str, passed: bool, expected: Any, observed: Any, details: str = "") -> None:
    rows.append(
        {
            "check_id": check_id,
            "status": "PASS" if passed else "FAIL",
            "expected": str(expected),
            "observed": str(observed),
            "details": details,
        }
    )


def old_f6l_pilot_diagnostic(parse: pd.DataFrame, requests: pd.DataFrame) -> pd.DataFrame:
    if requests.empty:
        return pd.DataFrame()
    source_ids = set(requests["f6l_request_id"].astype(str))
    subset = parse.loc[parse["request_id"].isin(source_ids)].copy()
    if subset.empty:
        return pd.DataFrame()
    subset["condition"] = subset["input_variant"]
    subset["profile_generator"] = subset["profile_generator_name"].replace("", "none")
    rows = []
    for key, group in subset.groupby(["dataset", "recommender_model_name", "condition", "profile_generator"], sort=True):
        dataset, recommender, condition, profile_generator = key
        rows.append(
            {
                "dataset": dataset,
                "recommender": recommender,
                "condition": condition,
                "profile_generator": profile_generator,
                "f6l_rows": len(group),
                "f6l_strict_validity_rate": float(group["strict_valid_bool"].mean()),
                "f6l_hr_at_5": float(group["hit_at_5_numeric"].mean()),
                "f6l_ndcg_at_5": float(group["ndcg_at_5_numeric"].mean()),
                "diagnostic_only": "true",
            }
        )
    return pd.DataFrame(rows)


def build_validation(
    root: Path,
    config: Mapping[str, Any],
    profile_audit: pd.DataFrame,
    matching_audit: pd.DataFrame,
    requests: pd.DataFrame,
    status: pd.DataFrame,
    accounting: pd.DataFrame,
    metrics: pd.DataFrame,
) -> tuple[pd.DataFrame, bool, bool, bool, bool]:
    scope = config.get("scope") or {}
    gates = config.get("gates") or {}
    datasets = [str(value) for value in scope.get("datasets", [])]
    n_users = int(scope.get("pilot_users_per_dataset", 10))
    expected_total = 200
    expected_history = 40
    expected_profile = 80
    expected_plus = 80
    min_validity = float(gates.get("min_overall_strict_validity_rate", 0.98))
    min_major_validity = float(gates.get("min_major_family_strict_validity_rate", 0.95))
    rows: list[dict[str, Any]] = []
    profile_all_reusable = bool(not profile_audit.empty and profile_audit["status"].eq(REUSABLE).all())
    matching_pass = bool(
        not matching_audit.empty
        and matching_audit["matching_status"].eq("PASS").all()
        and all((requests["dataset"].eq(dataset).sum() == 100) for dataset in datasets)
    )
    protected = protected_git_diff(root)
    planned = int(status["planned"].sum()) if not status.empty else 0
    terminal = int(status["terminal"].sum()) if not status.empty else 0
    strict_valid = int(status["strict_valid"].sum()) if not status.empty else 0
    overall_rate = strict_valid / planned if planned else 0.0
    completed_or_failed = terminal == planned and planned == expected_total
    prompt_hidden = bool(requests["positive_label_hidden"].eq("true").all()) if not requests.empty else False
    request_profile_counts = requests["condition"].value_counts().to_dict() if not requests.empty else {}
    max_abs_delta = 0.0
    suspicious = False
    if not metrics.empty and overall_rate >= float(gates.get("suspicious_metric_collapse_min_validity", 0.95)):
        metric_mean = float(metrics["hr_at_5"].astype(float).mean())
        suspicious = metric_mean <= float(gates.get("suspicious_metric_collapse_max_mean", 0.02))
    systematic_pass = False
    systematic_observed: Any = "no terminal status"
    if not status.empty and planned:
        major = (
            status.groupby(["dataset", "recommender", "condition"], as_index=False, sort=True)[["planned", "strict_valid"]]
            .sum()
            .copy()
        )
        major["strict_validity_rate"] = major["strict_valid"] / major["planned"].clip(lower=1)
        systematic_pass = bool(major["strict_validity_rate"].ge(min_major_validity).all())
        systematic_observed = major[["dataset", "recommender", "condition", "strict_valid", "planned", "strict_validity_rate"]].to_dict("records")

    add_validation(rows, "PROFILE-REUSE-ALL-REUSABLE", profile_all_reusable, "all REUSABLE", profile_audit["status"].value_counts().to_dict())
    add_validation(rows, "MATCHED-PILOT-INPUTS-PASS", matching_pass, "10 users per dataset and all matching rows PASS", f"requests={len(requests)}; matching_failures={(matching_audit['matching_status'].ne('PASS')).sum() if not matching_audit.empty else 'NA'}")
    add_validation(rows, "PILOT-REQUEST-COUNT", len(requests) == expected_total, expected_total, len(requests))
    add_validation(rows, "PILOT-HISTORY-REQUEST-COUNT", request_profile_counts.get("history_only", 0) == expected_history, expected_history, request_profile_counts.get("history_only", 0))
    add_validation(rows, "PILOT-PROFILE-REQUEST-COUNT", request_profile_counts.get("profile_only", 0) == expected_profile, expected_profile, request_profile_counts.get("profile_only", 0))
    add_validation(rows, "PILOT-PROFILE-PLUS-HISTORY-REQUEST-COUNT", request_profile_counts.get("profile_plus_history", 0) == expected_plus, expected_plus, request_profile_counts.get("profile_plus_history", 0))
    add_validation(rows, "PROMPTS-HIDE-POSITIVE-LABELS", prompt_hidden, "positive ids/labels absent", requests["positive_label_hidden"].value_counts().to_dict() if not requests.empty else {})
    add_validation(rows, "PILOT-TERMINAL-ACCOUNTING", completed_or_failed, "all 200 terminal after execution", f"terminal={terminal}; planned={planned}")
    add_validation(rows, "STRICT-VALIDITY-GATE", overall_rate >= min_validity and terminal == planned and planned == expected_total, f">={min_validity}", overall_rate)
    add_validation(rows, "NO-SYSTEMATIC-MAJOR-FAMILY-FAILURE", systematic_pass, f"all dataset/recommender/condition families >= {min_major_validity}", systematic_observed)
    add_validation(rows, "NO-SUSPICIOUS-METRIC-COLLAPSE", not suspicious, "not almost every cell near zero with high validity", f"suspicious={suspicious}")
    add_validation(rows, "MATCHED-SOURCE-MAX-ABS-DELTA", max_abs_delta == 0.0, "0.0", max_abs_delta)
    add_validation(rows, "PROTECTED-HISTORICAL-PATHS-UNTOUCHED", len(protected) == 0, "no git diff in protected F6L/R5C/R5D paths", ";".join(protected))
    return pd.DataFrame(rows), profile_all_reusable, matching_pass, suspicious, not systematic_pass


def verdict_from_validation(
    *,
    profile_all_reusable: bool,
    matching_pass: bool,
    suspicious: bool,
    systematic_failure: bool,
    status: pd.DataFrame,
    min_validity: float,
) -> str:
    if not profile_all_reusable:
        return VERDICT_PROFILE_BLOCKED
    if not matching_pass:
        return VERDICT_MATCHING_FAILED
    planned = int(status["planned"].sum()) if not status.empty else 0
    terminal = int(status["terminal"].sum()) if not status.empty else 0
    strict_valid = int(status["strict_valid"].sum()) if not status.empty else 0
    validity_rate = strict_valid / planned if planned else 0.0
    if terminal != planned or validity_rate < min_validity:
        return VERDICT_CONTRACT_FAILED
    if systematic_failure:
        return VERDICT_CONTRACT_FAILED
    if suspicious:
        return VERDICT_COLLAPSE
    return VERDICT_READY


def render_table(frame: pd.DataFrame, columns: Sequence[str]) -> str:
    if frame.empty:
        return "_empty_"
    text_frame = frame[list(columns)].fillna("").astype(str)
    header = list(text_frame.columns)
    lines = [
        "| " + " | ".join(header) + " |",
        "| " + " | ".join(["---"] * len(header)) + " |",
    ]
    for row in text_frame.values.tolist():
        lines.append("| " + " | ".join(cell.replace("|", "\\|").replace("\n", " ") for cell in row) + " |")
    return "\n".join(lines)


def render_report(
    root: Path,
    config: Mapping[str, Any],
    verdict: str,
    profile_audit: pd.DataFrame,
    matching_audit: pd.DataFrame,
    requests: pd.DataFrame,
    accounting: pd.DataFrame,
    metrics: pd.DataFrame,
    validation: pd.DataFrame,
    old_diag: pd.DataFrame,
    selected_users: Mapping[str, Sequence[str]],
) -> str:
    ref = random_reference()
    profile_counts = profile_audit["status"].value_counts().sort_index().to_dict() if not profile_audit.empty else {}
    matching_failures = int(matching_audit["matching_status"].ne("PASS").sum()) if not matching_audit.empty else 0
    validation_failures = validation.loc[validation["status"].ne("PASS"), "check_id"].tolist()
    return "\n".join(
        [
            "# RQ5 Corrected Matched Recovery Pilot",
            "",
            f"- Phase: `{PHASE_ID}`",
            f"- Verdict: `{verdict}`",
            f"- Source root: `{root}`",
            f"- Selected users: `{dict(selected_users)}`",
            f"- Profile reuse statuses: `{profile_counts}`",
            f"- Matching failures: `{matching_failures}`",
            f"- Pilot requests: `{len(requests)}`",
            f"- Random reference HR@5: `{ref['hr_at_5']:.6f}`",
            f"- Random reference NDCG@5: `{ref['ndcg_at_5']:.6f}`",
            "",
            "## Output Contract",
            "",
            "- Parser: `r5d_ranked_index_json_top10_v1` via `parse_strict_index_response`.",
            "- Required output: JSON object with `ranked_candidate_indices`, exactly 10 unique one-based positions from 1..20.",
            "- Metric policy: fail-strict all-request invalid-zero.",
            "",
            "## Request Accounting",
            "",
            render_table(
                accounting,
                [
                    "dataset",
                    "recommender",
                    "condition",
                    "profile_generator",
                    "planned",
                    "completed",
                    "strict_valid",
                    "invalid_length",
                    "duplicate_index",
                    "out_of_range_index",
                    "parse_failure",
                    "backend_failure",
                    "strict_validity_rate",
                ],
            ),
            "",
            "## Metrics",
            "",
            render_table(
                metrics,
                [
                    "dataset",
                    "recommender",
                    "condition",
                    "profile_generator",
                    "requests",
                    "strict_validity_rate",
                    "hr_at_5",
                    "ndcg_at_5",
                ],
            ),
            "",
            "## Old F6L Diagnostic",
            "",
            render_table(
                old_diag,
                [
                    "dataset",
                    "recommender",
                    "condition",
                    "profile_generator",
                    "f6l_rows",
                    "f6l_strict_validity_rate",
                    "f6l_hr_at_5",
                    "f6l_ndcg_at_5",
                ],
            ),
            "",
            "## Validation",
            "",
            render_table(validation, ["check_id", "status", "expected", "observed"]),
            "",
            f"- Validation failures: `{validation_failures}`",
            "- Full corrected recovery was not executed.",
            "",
        ]
    )


def build_manifest(
    root: Path,
    config_path: Path,
    config: Mapping[str, Any],
    verdict: str,
    requests: pd.DataFrame,
    accounting: pd.DataFrame,
    metrics: pd.DataFrame,
    validation: pd.DataFrame,
    duplicate_forensics: pd.DataFrame,
    structured_output_capability: pd.DataFrame,
    v1_vs_v2_comparison: pd.DataFrame,
    selected_users: Mapping[str, Sequence[str]],
) -> dict[str, Any]:
    request_records = []
    for row in requests.to_dict("records"):
        request_records.append(
            {
                "request_id": row["request_id"],
                "f6l_request_id": row["f6l_request_id"],
                "dataset": row["dataset"],
                "user_id": row["user_id"],
                "recommender": row["recommender_model_name"],
                "profile_generator": row["profile_generator_name"],
                "condition": row["condition"],
                "candidate_list_hash": row["candidate_list_hash"],
                "positive_item_id": row["positive_item_id"],
                "positive_candidate_position": row["positive_candidate_position"],
                "prompt_hash": row["prompt_hash"],
                "output_destination": row["output_destination"],
            }
        )
    return {
        "phase": PHASE_ID,
        "verdict": verdict,
        "config_path": normalize_rel(config_path),
        "source_metadata": source_metadata(root),
        "selected_users": {key: list(value) for key, value in selected_users.items()},
        "raw_namespace": (config.get("outputs") or {}).get("raw_namespace", ""),
        "request_count": len(requests),
        "request_protocol_hash": sha256_text(stable_json(request_records)),
        "accounting_summary": accounting.to_dict("records"),
        "metrics_summary": metrics.to_dict("records"),
        "validation": validation.to_dict("records"),
        "duplicate_forensics_rows": len(duplicate_forensics),
        "structured_output_capability": structured_output_capability.to_dict("records"),
        "v1_vs_v2_summary": v1_vs_v2_comparison.loc[v1_vs_v2_comparison["scope"].eq("overall")].to_dict("records")
        if not v1_vs_v2_comparison.empty
        else [],
        "pilot_requests": request_records,
        "full_recovery_executed": False,
    }


def output_path(root: Path, config: Mapping[str, Any], key: str) -> Path:
    return project_path(root, (config.get("outputs") or {})[key])


def write_outputs(
    root: Path,
    config: Mapping[str, Any],
    profile_audit: pd.DataFrame,
    matching_audit: pd.DataFrame,
    accounting: pd.DataFrame,
    metrics: pd.DataFrame,
    validation: pd.DataFrame,
    duplicate_forensics: pd.DataFrame,
    structured_output_capability: pd.DataFrame,
    v1_vs_v2_comparison: pd.DataFrame,
    manifest: Mapping[str, Any],
    report: str,
) -> None:
    write_csv(profile_audit, output_path(root, config, "profile_reuse_audit"))
    write_csv(matching_audit, output_path(root, config, "pilot_matching_audit"))
    write_csv(accounting, output_path(root, config, "pilot_request_accounting"))
    write_csv(metrics, output_path(root, config, "pilot_metrics"))
    write_csv(validation, output_path(root, config, "pilot_validation"))
    write_csv(duplicate_forensics, output_path(root, config, "duplicate_forensics"))
    write_csv(structured_output_capability, output_path(root, config, "structured_output_capability_audit"))
    write_csv(v1_vs_v2_comparison, output_path(root, config, "v1_vs_v2_comparison"))
    write_json(output_path(root, config, "manifest"), manifest)
    report_path = output_path(root, config, "report")
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report, encoding="utf-8")


def build_corrected_matched_recovery(
    root: Path,
    config_path: Path | None = None,
    *,
    write: bool = True,
    execute_pilot_flag: bool = False,
    allow_api_calls: bool = False,
    allow_local_ollama: bool = False,
    rerun_backend_failed: bool = False,
    structured_output_probe: bool = False,
) -> BuildResult:
    actual_config_path = config_path or DEFAULT_CONFIG_PATH
    config = load_config(actual_config_path)
    manifest = load_f6l_manifest(root)
    parse = load_f6l_parse(root)
    profile_audit = build_profile_reuse_audit(root, config, manifest)

    profile_all_reusable = bool(not profile_audit.empty and profile_audit["status"].eq(REUSABLE).all())
    if profile_all_reusable:
        requests, matching_audit, selected_users = build_pilot_requests(root, config, parse, profile_audit)
    else:
        requests = pd.DataFrame()
        matching_audit = pd.DataFrame()
        selected_users = {}

    matching_pass_pre = bool(
        not requests.empty
        and not matching_audit.empty
        and matching_audit["matching_status"].eq("PASS").all()
        and len(requests) == 200
        and requests["positive_label_hidden"].eq("true").all()
    )
    if profile_all_reusable and matching_pass_pre:
        execute_pilot(
            root,
            config,
            requests,
            execute=execute_pilot_flag,
            allow_api_calls=allow_api_calls,
            allow_local_ollama=allow_local_ollama,
            rerun_backend_failed=rerun_backend_failed,
        )

    status = build_request_status(root, requests) if not requests.empty else pd.DataFrame()
    accounting = build_request_accounting(status)
    metrics = build_pilot_metrics(status) if not status.empty else pd.DataFrame()
    duplicate_forensics = build_duplicate_forensics(root, config, requests) if not requests.empty else pd.DataFrame()
    structured_output_capability = build_structured_output_capability_audit(
        config,
        run_probe=bool(structured_output_probe and allow_local_ollama),
    )
    v1_vs_v2_comparison = build_v1_vs_v2_comparison(root, config, requests, status) if not requests.empty else pd.DataFrame()
    validation, profile_valid, matching_valid, suspicious, systematic_failure = build_validation(
        root,
        config,
        profile_audit,
        matching_audit,
        requests,
        status,
        accounting,
        metrics,
    )
    verdict = verdict_from_validation(
        profile_all_reusable=profile_valid,
        matching_pass=matching_valid,
        suspicious=suspicious,
        systematic_failure=systematic_failure,
        status=status,
        min_validity=float((config.get("gates") or {}).get("min_overall_strict_validity_rate", 0.98)),
    )
    old_diag = old_f6l_pilot_diagnostic(parse, requests)
    report = render_report(
        root,
        config,
        verdict,
        profile_audit,
        matching_audit,
        requests,
        accounting,
        metrics,
        validation,
        old_diag,
        selected_users,
    )
    manifest_payload = build_manifest(
        root,
        actual_config_path,
        config,
        verdict,
        requests,
        accounting,
        metrics,
        validation,
        duplicate_forensics,
        structured_output_capability,
        v1_vs_v2_comparison,
        selected_users,
    )
    if write:
        write_outputs(
            root,
            config,
            profile_audit,
            matching_audit,
            accounting,
            metrics,
            validation,
            duplicate_forensics,
            structured_output_capability,
            v1_vs_v2_comparison,
            manifest_payload,
            report,
        )
    return BuildResult(
        verdict=verdict,
        profile_reuse_audit=profile_audit,
        matching_audit=matching_audit,
        request_accounting=accounting,
        metrics=metrics,
        validation=validation,
        duplicate_forensics=duplicate_forensics,
        structured_output_capability=structured_output_capability,
        v1_vs_v2_comparison=v1_vs_v2_comparison,
        report=report,
        manifest=manifest_payload,
    )


def print_summary(result: BuildResult) -> None:
    profile_counts = result.profile_reuse_audit["status"].value_counts().sort_index().to_dict()
    planned = int(result.request_accounting["planned"].sum()) if not result.request_accounting.empty else 0
    strict = int(result.request_accounting["strict_valid"].sum()) if not result.request_accounting.empty else 0
    backend = int(result.request_accounting["backend_failure"].sum()) if not result.request_accounting.empty else 0
    failures = result.validation.loc[result.validation["status"].ne("PASS"), "check_id"].tolist()
    print(f"FINAL_VERDICT={result.verdict}")
    print(f"PROFILE_REUSE={profile_counts}")
    print(f"PILOT_PLANNED={planned}")
    print(f"PILOT_STRICT_VALID={strict}")
    print(f"PILOT_BACKEND_FAILURE={backend}")
    print(f"VALIDATION_FAILURES={failures}")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG_PATH))
    parser.add_argument("--project-root", default=None)
    parser.add_argument("--execute-pilot", action="store_true")
    parser.add_argument("--allow-api-calls", action="store_true")
    parser.add_argument("--allow-local-ollama", action="store_true")
    parser.add_argument("--rerun-backend-failed", action="store_true")
    parser.add_argument("--structured-output-audit", action="store_true")
    parser.add_argument("--no-write", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    config_path = Path(args.config)
    config = load_config(config_path)
    root = repository_root_from_arg(args.project_root, config)
    try:
        result = build_corrected_matched_recovery(
            root,
            config_path=config_path,
            write=not args.no_write,
            execute_pilot_flag=args.execute_pilot,
            allow_api_calls=args.allow_api_calls,
            allow_local_ollama=args.allow_local_ollama,
            rerun_backend_failed=args.rerun_backend_failed,
            structured_output_probe=args.structured_output_audit,
        )
    except RQ5CorrectedRecoveryError as exc:
        print(f"RQ5_CORRECTED_RECOVERY_ERROR={exc}")
        return 2
    print_summary(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
