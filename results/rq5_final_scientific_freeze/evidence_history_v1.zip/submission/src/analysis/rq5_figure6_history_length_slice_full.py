"""Run the paper-aligned Figure 6 history-length slice for RQ5.

This script is deliberately separate from the primary systematic RQ5 extension.
It reuses H=10 evidence exactly, executes only the missing Beauty/Qwen/Qwen
multi-history requests, and computes paper-aligned offline APLT and serendipity.
"""

from __future__ import annotations

import argparse
import ast
import json
import math
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zipfile
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import yaml

PROJECT_ROOT_FOR_IMPORTS = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT_FOR_IMPORTS) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT_FOR_IMPORTS))

from src.analysis import rq5_corrected_matched_recovery as corrected
from src.extension.f0_final_extension_freeze import sha256_file


DEFAULT_CONFIG = Path("configs/rq5_figure6_history_length_slice_full.yaml")
PHASE_ID = "FIGURE6_HISTORY_LENGTH_SLICE_FULL"
DATASET = "beauty"
DATASET_LABEL = "Beauty"
PROFILE_GENERATOR = "qwen2:7b-instruct"
RECOMMENDER = "qwen2:7b-instruct"
CONDITIONS = ("history_only", "profile_only", "profile_plus_history")
CONDITION_LABELS = {
    "history_only": "History",
    "profile_only": "Profile",
    "profile_plus_history": "Profile+History",
}
TREATMENTS = (
    ("profile_only_vs_history_only", "profile_only"),
    ("profile_plus_history_vs_history_only", "profile_plus_history"),
)
PROFILE_REUSE = "REUSE_PRIMARY_RQ5_H10_PROFILE"
PROFILE_NEW = "NEW_PROFILE_INFERENCE"
RANKING_REUSE = "REUSE_PRIMARY_RQ5_H10_RANKING"
RANKING_NEW = "NEW_RANKING_INFERENCE"
DENOMINATOR_POLICY = "FAIL_STRICT_ALL_MANIFEST_REQUESTS_INVALID_ZERO"
PROFILE_PROMPT_TEMPLATE_ID = "template_user_profile_generate_index3_free_text_retained"
PROFILE_PARSER_CONTRACT = "free_text_profile_retained"
RANKING_PROMPT_TEMPLATE_ID = "rq5_corrected_matched_json_index_exact10_hardened_v2"
RANKING_PARSER_CONTRACT = "r5d_ranked_index_json_top10_v1"
METRIC_COLUMNS = ("hr_at_5", "ndcg_at_5", "aplt_at_5", "serendipity_at_5")
DECISIONS = {"CI_SUPPORTED_POSITIVE", "CI_SUPPORTED_NEGATIVE", "NON_SIGNIFICANT_CI_INCLUDES_ZERO"}
PROTECTED_PATHS = (
    "original_repo",
    "data/raw",
    "paper",
    "results/tables/g1_",
    "results/tables/g2_",
    "results/tables/g3_",
    "results/tables/g4_",
    "results/manifests/g1_",
    "results/manifests/g2_",
    "results/manifests/g3_",
    "results/manifests/g4_",
    "results/llm/extension_canonical/g1_",
    "results/llm/extension_canonical/g2_",
    "results/llm/extension_canonical/g3_",
    "results/llm/extension_canonical/g4_",
    "results/llm/rq5_primary_systematic_extension",
    "results/tables/rq5_primary_systematic_",
    "report/rq5_primary_systematic_extension.md",
)


def load_config(path: Path) -> dict[str, Any]:
    loaded = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(loaded, dict):
        raise ValueError(f"config must be a mapping: {path}")
    return loaded


def project_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def output_path(root: Path, config: Mapping[str, Any], key: str) -> Path:
    return project_path(root, (config.get("outputs") or {})[key])


def write_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, lineterminator="\n")


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def read_csv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, dtype=str, keep_default_na=False, low_memory=False)


def stable_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"))


def sha256_text(value: str) -> str:
    return corrected.sha256_text(value)


def stable_id(prefix: str, *parts: Any, length: int = 20) -> str:
    return f"{prefix}-{sha256_text(stable_json([str(part) for part in parts]))[:length]}"


def bool_text(value: bool) -> str:
    return "true" if value else "false"


def parse_bool(value: Any) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def json_list(value: Any) -> list[str]:
    return corrected.json_list(value)


def sorted_users(values: Iterable[str]) -> list[str]:
    return corrected.sorted_users(values)


def source_roots(root: Path) -> list[tuple[Path, str]]:
    rows: list[tuple[Path, str]] = []
    seen: set[Path] = set()
    candidates = [root, *sorted(root.parent.glob("IRP_BeyondUtility*"))]
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved in seen:
            continue
        seen.add(resolved)
        scope = "local_current_worktree" if resolved == root.resolve() else "external_read_only"
        rows.append((candidate, scope))
    return rows


def resolve_source(root: Path, rel_path: str | Path) -> tuple[Path, str, str]:
    rel = Path(rel_path)
    searched: list[str] = []
    for candidate_root, scope in source_roots(root):
        candidate = candidate_root / rel
        searched.append(str(candidate))
        if candidate.exists() and candidate.is_file():
            return candidate, scope, sha256_file(candidate)
    raise FileNotFoundError(f"missing source {rel.as_posix()}; searched={searched}")


def read_source_csv(root: Path, rel_path: str | Path) -> tuple[pd.DataFrame, Path, str, str]:
    path, scope, digest = resolve_source(root, rel_path)
    return read_csv(path), path, scope, digest


def zip_json(zip_path: Path, member: str) -> list[dict[str, Any]]:
    with zipfile.ZipFile(zip_path) as archive:
        payload = json.loads(archive.read(member).decode("utf-8"))
    if not isinstance(payload, list):
        raise ValueError(f"zip member is not a list: {member}")
    return [dict(row) for row in payload]


def parse_candidate_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value]
    parsed = ast.literal_eval(str(value))
    if not isinstance(parsed, list):
        raise ValueError("candidate list is not a list")
    return [str(item) for item in parsed]


def extract_history_context(prompt: str) -> str:
    text = str(prompt).strip()
    for marker in (". Please select", " Please select"):
        index = text.find(marker)
        if index >= 0:
            stop = index + (1 if marker.startswith(".") else 0)
            return text[:stop].strip()
    return text


@dataclass(frozen=True)
class RequestResult:
    backend_success: bool
    response_text: str
    raw_backend_response: dict[str, Any]
    backend_error_type: str
    backend_error_message: str
    started_at: str
    completed_at: str
    duration_seconds: float


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def call_ollama_generate(base_url: str, payload: Mapping[str, Any], timeout_seconds: int) -> RequestResult:
    started = utc_now()
    start_clock = time.perf_counter()
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        base_url.rstrip("/") + "/api/generate",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            raw_body = response.read().decode("utf-8")
        raw = json.loads(raw_body)
        response_text = str(raw.get("response", ""))
        success = bool(response_text.strip()) and bool(raw.get("done", True))
        return RequestResult(success, response_text, raw, "", "", started, utc_now(), time.perf_counter() - start_clock)
    except urllib.error.HTTPError as exc:
        return RequestResult(False, "", {}, "HTTPError", f"{exc.code}: {exc.reason}", started, utc_now(), time.perf_counter() - start_clock)
    except urllib.error.URLError as exc:
        return RequestResult(False, "", {}, "URLError", str(exc.reason), started, utc_now(), time.perf_counter() - start_clock)
    except TimeoutError as exc:
        return RequestResult(False, "", {}, "TimeoutError", str(exc), started, utc_now(), time.perf_counter() - start_clock)
    except Exception as exc:
        return RequestResult(False, "", {}, type(exc).__name__, str(exc), started, utc_now(), time.perf_counter() - start_clock)

def http_json(method: str, url: str, *, timeout: int) -> dict[str, Any]:
    request = urllib.request.Request(url, headers={"Content-Type": "application/json"}, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            parsed = json.loads(response.read().decode("utf-8"))
    except Exception as exc:
        return {"_error": f"{type(exc).__name__}: {exc}", "models": []}
    return parsed if isinstance(parsed, dict) else {"_error": "non-object JSON response", "models": []}


def backend_preflight(config: Mapping[str, Any]) -> pd.DataFrame:
    runtime = config["runtime"]
    required_models = sorted({PROFILE_GENERATOR, RECOMMENDER})
    version = http_json("GET", str(runtime["version_endpoint"]), timeout=5)
    tags = http_json("GET", str(runtime["tags_endpoint"]), timeout=10)
    model_rows = tags.get("models", []) if isinstance(tags.get("models", []), list) else []
    by_name: dict[str, Mapping[str, Any]] = {}
    for row in model_rows:
        if isinstance(row, Mapping):
            for key in ("name", "model"):
                name = str(row.get(key, "")).strip()
                if name:
                    by_name[name] = row
    backend_ok = not str(version.get("_error", "")) and not str(tags.get("_error", ""))
    rows: list[dict[str, Any]] = []
    for model in required_models:
        tag = by_name.get(model, {})
        details = tag.get("details", {}) if isinstance(tag.get("details", {}), Mapping) else {}
        rows.append(
            {
                "model": model,
                "backend_available": bool_text(backend_ok),
                "model_available": bool_text(bool(tag)),
                "model_digest": str(tag.get("digest", "")),
                "model_modified_at": str(tag.get("modified_at", "")),
                "ollama_version": str(version.get("version", "")),
                "parameter_size": str(details.get("parameter_size", "")),
                "quantization_level": str(details.get("quantization_level", "")),
                "context_length": str(details.get("context_length", "")),
                "runtime_error": str(version.get("_error", "") or tags.get("_error", "")),
                "tags_endpoint": str(runtime["tags_endpoint"]),
                "status": "PASS" if backend_ok and bool(tag) else "FAIL",
            }
        )
    return pd.DataFrame(rows)


def require_preflight(preflight: pd.DataFrame) -> None:
    if preflight.empty or not preflight["status"].eq("PASS").all():
        raise RuntimeError("backend/model preflight failed; stopping before inference")

def model_digest(preflight: pd.DataFrame, model: str) -> str:
    subset = preflight.loc[preflight["model"].eq(model), "model_digest"]
    return str(subset.iloc[0]) if not subset.empty else ""


def profile_text_from_payload(payload: Mapping[str, Any]) -> str:
    for key in ("profile_text", "response_text", "raw_response"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    ollama = payload.get("ollama_raw_response")
    if isinstance(ollama, Mapping) and isinstance(ollama.get("response"), str) and str(ollama["response"]).strip():
        return str(ollama["response"]).strip()
    ollama = payload.get("ollama_response")
    if isinstance(ollama, Mapping) and isinstance(ollama.get("response"), str) and str(ollama["response"]).strip():
        return str(ollama["response"]).strip()
    return ""


def raw_response_text(payload: Mapping[str, Any]) -> str:
    return corrected.raw_response_text(payload)


def load_primary_material(root: Path, config: Mapping[str, Any]) -> dict[str, Any]:
    sources = config["source_authority"]
    profiles = read_csv(project_path(root, sources["primary_profile_manifest"]))
    rank_universe = read_csv(project_path(root, sources["primary_ranking_universe"]))
    rank_status = read_csv(project_path(root, sources["primary_ranking_status"]))
    metrics = read_csv(project_path(root, sources["primary_metrics"]))

    profile_subset = profiles.loc[
        profiles["dataset"].eq(DATASET)
        & profiles["profile_generator"].eq(PROFILE_GENERATOR)
        & profiles["history_length"].astype(str).eq("10")
    ].copy()
    if len(profile_subset) != 200:
        raise RuntimeError(f"primary H10 profile reuse count != 200: {len(profile_subset)}")

    ranking_subset = rank_universe.loc[
        rank_universe["dataset"].eq(DATASET)
        & rank_universe["model_name"].eq(RECOMMENDER)
        & rank_universe["history_length"].astype(str).eq("10")
        & rank_universe["condition"].isin(CONDITIONS)
    ].copy()
    if len(ranking_subset) != 600:
        raise RuntimeError(f"primary H10 ranking reuse count != 600: {len(ranking_subset)}")

    status_subset = rank_status.loc[
        rank_status["dataset"].eq(DATASET)
        & rank_status["recommender"].eq(RECOMMENDER)
        & rank_status["condition"].isin(CONDITIONS)
    ].copy()
    if len(status_subset) != 600:
        raise RuntimeError(f"primary H10 ranking status count != 600: {len(status_subset)}")

    profile_by_user: dict[str, dict[str, Any]] = {}
    for row in profile_subset.to_dict("records"):
        user_id = str(row["user_id"])
        source_file = str(row["output_destination"])
        source_path = project_path(root, source_file)
        payload = json.loads(source_path.read_text(encoding="utf-8"))
        text = profile_text_from_payload(payload)
        observed_hash = sha256_text(text) if text else ""
        expected_hash = str(row.get("profile_hash", ""))
        if not text or observed_hash != expected_hash:
            raise RuntimeError(f"primary H10 profile hash mismatch: user={user_id}")
        profile_by_user[user_id] = {
            "primary_profile_request_id": str(row["profile_request_id"]),
            "primary_profile_file": source_file,
            "primary_profile_sha256": sha256_file(source_path),
            "profile_text": text,
            "profile_hash": observed_hash,
            "rendered_prompt": str(row["rendered_prompt"]),
            "rendered_prompt_hash": str(row["rendered_prompt_hash"]),
        }

    base_by_user: dict[str, dict[str, Any]] = {}
    history_rows = ranking_subset.loc[ranking_subset["condition"].eq("history_only")].copy()
    for row in history_rows.to_dict("records"):
        user_id = str(row["user_id"])
        candidate_ids = json_list(row["candidate_item_ids_json"])
        candidate_titles = json_list(row["candidate_item_titles_json"])
        positive_position = int(row["positive_candidate_position"])
        if len(candidate_ids) != 20 or len(candidate_titles) != 20 or len(set(candidate_ids)) != 20:
            raise RuntimeError(f"primary candidate contract broken: user={user_id}")
        base_by_user[user_id] = {
            "user_id": user_id,
            "candidate_item_ids": candidate_ids,
            "candidate_item_titles": candidate_titles,
            "candidate_item_ids_json": stable_json(candidate_ids),
            "candidate_item_titles_json": stable_json(candidate_titles),
            "candidate_list_hash": str(row["candidate_list_hash"]),
            "positive_item_id": str(row["positive_item_id"]),
            "positive_candidate_position": str(positive_position),
            "positive_title": candidate_titles[positive_position - 1],
        }

    users = sorted_users(profile_by_user)
    if users != sorted_users(base_by_user) or len(users) != 200:
        raise RuntimeError("primary H10 users do not match profile/candidate bases")

    primary_rank_by_key = {
        (str(row["user_id"]), str(row["condition"])): dict(row)
        for row in ranking_subset.to_dict("records")
    }
    primary_status_by_key = {
        (str(row["user_id"]), str(row["condition"])): dict(row)
        for row in status_subset.to_dict("records")
    }
    return {
        "users": users,
        "profiles": profile_by_user,
        "base": base_by_user,
        "ranking_universe": ranking_subset,
        "ranking_status": status_subset,
        "rank_by_key": primary_rank_by_key,
        "status_by_key": primary_status_by_key,
        "metrics": metrics,
    }


def build_contexts(root: Path, config: Mapping[str, Any], primary_material: Mapping[str, Any]) -> tuple[dict[tuple[int, str], dict[str, Any]], pd.DataFrame]:
    scope = config["scope"]
    sources = config["source_authority"]
    history_lengths = [int(value) for value in scope["history_lengths"]]
    zip_path, zip_scope, zip_sha = resolve_source(root, sources["upstream_beauty_zip"])
    users = list(primary_material["users"])
    base_by_user = primary_material["base"]
    contexts: dict[tuple[int, str], dict[str, Any]] = {}
    audit_rows: list[dict[str, Any]] = []

    for history_length in history_lengths:
        rank_member = f"beauty/test_history{history_length}_candidate20_shuffle_sample.json"
        profile_member = f"beauty/test_history{history_length}_generate_profile_sample.json"
        rank_records = {str(row["user"]): row for row in zip_json(zip_path, rank_member)}
        profile_records = {str(row["user"]): row for row in zip_json(zip_path, profile_member)}
        if sorted_users(rank_records) != users or sorted_users(profile_records) != users:
            raise RuntimeError(f"upstream user set mismatch for H={history_length}")
        for user_id in users:
            base = base_by_user[user_id]
            rank_record = rank_records[user_id]
            profile_record = profile_records[user_id]
            upstream_candidates = parse_candidate_list(rank_record["cand_list"])
            candidate_match = upstream_candidates == base["candidate_item_ids"]
            candidate_hash_match = sha256_text(stable_json(upstream_candidates)) == base["candidate_list_hash"]
            target_title_match = str(rank_record.get("target", "")).strip() == str(base["positive_title"]).strip()
            if not candidate_match or not candidate_hash_match:
                raise RuntimeError(f"candidate invariant failed: H={history_length} user={user_id}")
            if not target_title_match:
                raise RuntimeError(f"positive target title invariant failed: H={history_length} user={user_id}")
            profile_prompt = str(profile_record["prompt"])
            if history_length == 10:
                profile_prompt = str(primary_material["profiles"][user_id]["rendered_prompt"])
            history_context = extract_history_context(str(rank_record["prompt"]))
            contexts[(history_length, user_id)] = {
                "history_length": history_length,
                "user_id": user_id,
                "history_context": history_context,
                "history_context_hash": sha256_text(history_context),
                "profile_prompt": profile_prompt,
                "profile_prompt_hash": sha256_text(profile_prompt),
                "candidate_item_ids": list(base["candidate_item_ids"]),
                "candidate_item_titles": list(base["candidate_item_titles"]),
                "candidate_item_ids_json": base["candidate_item_ids_json"],
                "candidate_item_titles_json": base["candidate_item_titles_json"],
                "candidate_list_hash": base["candidate_list_hash"],
                "positive_item_id": base["positive_item_id"],
                "positive_candidate_position": base["positive_candidate_position"],
                "positive_title": base["positive_title"],
                "upstream_rank_member": rank_member,
                "upstream_profile_member": profile_member,
                "upstream_zip_file": str(zip_path),
                "upstream_zip_scope": zip_scope,
                "upstream_zip_sha256": zip_sha,
            }
            audit_rows.append(
                {
                    "history_length": history_length,
                    "user_id": user_id,
                    "upstream_rank_member": rank_member,
                    "upstream_profile_member": profile_member,
                    "candidate_membership_order_matches_h10_primary": bool_text(candidate_match),
                    "candidate_hash_matches_h10_primary": bool_text(candidate_hash_match),
                    "positive_target_title_matches_h10_primary": bool_text(target_title_match),
                    "positive_item_id": base["positive_item_id"],
                    "positive_candidate_position": base["positive_candidate_position"],
                    "source_zip_scope": zip_scope,
                    "source_zip_sha256": zip_sha,
                }
            )
    return contexts, pd.DataFrame(audit_rows)


def build_profile_manifest(root: Path, config: Mapping[str, Any], preflight: pd.DataFrame, contexts: Mapping[tuple[int, str], Mapping[str, Any]], primary_material: Mapping[str, Any]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    max_tokens = int(config["runtime"].get("max_new_tokens_profile", 256))
    for history_length in [int(value) for value in config["scope"]["history_lengths"]]:
        for user_id in primary_material["users"]:
            context = contexts[(history_length, user_id)]
            profile_reuse = history_length == 10
            primary_profile = primary_material["profiles"].get(user_id, {})
            rendered_prompt = str(context["profile_prompt"])
            profile_request_id = stable_id("RQ5F6-PROF", DATASET, user_id, history_length, PROFILE_GENERATOR, sha256_text(rendered_prompt))
            output_destination = Path(str(config["outputs"]["profile_namespace"])) / f"{profile_request_id}.json"
            rows.append(
                {
                    "phase": PHASE_ID,
                    "dataset": DATASET,
                    "user_id": user_id,
                    "history_length": history_length,
                    "profile_generator": PROFILE_GENERATOR,
                    "profile_request_id": profile_request_id,
                    "profile_reuse_class": PROFILE_REUSE if profile_reuse else PROFILE_NEW,
                    "new_profile_call_required": bool_text(not profile_reuse),
                    "source_profile_request_id": str(primary_profile.get("primary_profile_request_id", "")) if profile_reuse else "",
                    "source_profile_file": str(primary_profile.get("primary_profile_file", "")) if profile_reuse else "",
                    "source_profile_sha256": str(primary_profile.get("primary_profile_sha256", "")) if profile_reuse else "",
                    "output_destination": output_destination.as_posix(),
                    "model_digest": model_digest(preflight, PROFILE_GENERATOR),
                    "prompt_template_id": PROFILE_PROMPT_TEMPLATE_ID,
                    "parser_contract": PROFILE_PARSER_CONTRACT,
                    "response_format": "text",
                    "temperature": 0,
                    "seed": 0,
                    "max_new_tokens": max_tokens,
                    "rendered_prompt": rendered_prompt,
                    "rendered_prompt_hash": sha256_text(rendered_prompt),
                    "history_context_hash": str(context["history_context_hash"]),
                    "history_input_provenance": str(context["upstream_profile_member"]),
                    "profile_hash": str(primary_profile.get("profile_hash", "")) if profile_reuse else "",
                    "profile_char_count": len(str(primary_profile.get("profile_text", ""))) if profile_reuse else 0,
                    "profile_dependency_status": "PRESENT_REUSED" if profile_reuse else "PENDING_GENERATION",
                    "r5d_reuse_decision": "DESCRIPTIVE_ONLY_ZERO_EXACT_REUSE",
                }
            )
    frame = pd.DataFrame(rows)
    expected = int(config["frozen_accounting"]["target_profiles"])
    if len(frame) != expected or frame["profile_request_id"].nunique() != expected:
        raise RuntimeError("profile manifest accounting/id uniqueness failed")
    return frame


def build_profile_payload(row: Mapping[str, Any], *, execution_status: str, response_text: str, raw_response: Mapping[str, Any], error: str, latency_seconds: float, reuse_source_payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
    profile_text = response_text.strip()
    return {
        "phase": PHASE_ID,
        "task": "profile_generation",
        "request_id": str(row["profile_request_id"]),
        "dataset": DATASET,
        "user_id": str(row["user_id"]),
        "history_length": int(row["history_length"]),
        "model_name": PROFILE_GENERATOR,
        "profile_generator_name": PROFILE_GENERATOR,
        "execution_status": execution_status,
        "backend_complete": bool_text(execution_status == "SUCCEEDED"),
        "response_text": response_text,
        "raw_response": response_text,
        "profile_text": profile_text,
        "profile_hash": sha256_text(profile_text) if profile_text else "",
        "profile_char_count": len(profile_text),
        "prompt_template_id": PROFILE_PROMPT_TEMPLATE_ID,
        "parser_contract": PROFILE_PARSER_CONTRACT,
        "rendered_prompt": str(row["rendered_prompt"]),
        "rendered_prompt_hash": str(row["rendered_prompt_hash"]),
        "generation_parameters": {"temperature": float(row["temperature"]), "seed": int(row["seed"]), "num_predict": int(row["max_new_tokens"])},
        "reuse_class": str(row["profile_reuse_class"]),
        "reuse_source_file": str(row.get("source_profile_file", "")),
        "reuse_source_request_id": str(row.get("source_profile_request_id", "")),
        "reuse_source_sha256": str(row.get("source_profile_sha256", "")),
        "runtime_backend": "local_ollama",
        "runtime_model_id": str(raw_response.get("model", PROFILE_GENERATOR)),
        "ollama_done_reason": str(raw_response.get("done_reason", "")),
        "ollama_raw_response": dict(raw_response),
        "error": error,
        "latency_seconds": latency_seconds,
        "raw_output_recorded_before_profile_validation": True,
        "source_reuse_payload_status": "AVAILABLE" if reuse_source_payload is not None else "",
    }


def profile_raw_capture_path(root: Path, config: Mapping[str, Any], request_id: str) -> Path:
    return output_path(root, config, "raw_namespace") / "profile_raw_captures" / f"{request_id}.json"


def result_from_raw_capture(path: Path) -> RequestResult:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return RequestResult(
        backend_success=bool(payload.get("backend_success", False)),
        response_text=str(payload.get("response_text", "")),
        raw_backend_response=payload.get("raw_backend_response", {}),
        backend_error_type=str(payload.get("backend_error_type", "")),
        backend_error_message=str(payload.get("backend_error_message", "")),
        started_at=str(payload.get("started_at", "")),
        completed_at=str(payload.get("completed_at", "")),
        duration_seconds=float(payload.get("duration_seconds", 0.0) or 0.0),
    )


def execute_profiles(root: Path, config: Mapping[str, Any], manifest: pd.DataFrame, *, execute: bool) -> int:
    if not execute:
        return 0
    runtime = config["runtime"]
    sent = 0
    for index, row in enumerate(manifest.to_dict("records"), start=1):
        destination = project_path(root, row["output_destination"])
        if destination.exists():
            continue
        if str(row["profile_reuse_class"]) == PROFILE_REUSE:
            source_path = project_path(root, row["source_profile_file"])
            source_payload = json.loads(source_path.read_text(encoding="utf-8"))
            text = profile_text_from_payload(source_payload)
            raw_response = source_payload.get("ollama_raw_response", {})
            if not isinstance(raw_response, Mapping):
                raw_response = {}
            write_json(
                destination,
                build_profile_payload(
                    row,
                    execution_status="SUCCEEDED",
                    response_text=text,
                    raw_response=raw_response,
                    error=str(source_payload.get("error", "")),
                    latency_seconds=0.0,
                    reuse_source_payload=source_payload,
                ),
            )
            continue
        capture = profile_raw_capture_path(root, config, str(row["profile_request_id"]))
        if capture.exists():
            result = result_from_raw_capture(capture)
        else:
            payload = {
                "model": PROFILE_GENERATOR,
                "prompt": str(row["rendered_prompt"]),
                "stream": False,
                "options": {"temperature": float(row["temperature"]), "seed": int(row["seed"]), "num_predict": int(row["max_new_tokens"])},
            }
            result = call_ollama_generate(str(runtime["base_url"]), payload, int(runtime["timeout_seconds"]))
            write_json(
                capture,
                {
                    "phase": PHASE_ID,
                    "task": "profile_generation",
                    "request_id": str(row["profile_request_id"]),
                    "history_length": int(row["history_length"]),
                    "backend_success": result.backend_success,
                    "response_text": result.response_text,
                    "raw_backend_response": result.raw_backend_response,
                    "backend_error_type": result.backend_error_type,
                    "backend_error_message": result.backend_error_message,
                    "started_at": result.started_at,
                    "completed_at": result.completed_at,
                    "duration_seconds": result.duration_seconds,
                    "raw_response_hash": sha256_text(result.response_text),
                    "raw_output_recorded_before_profile_validation": True,
                },
            )
            sent += 1
        status = "SUCCEEDED" if result.backend_success else "BACKEND_FAILED"
        write_json(destination, build_profile_payload(row, execution_status=status, response_text=result.response_text, raw_response=result.raw_backend_response, error=result.backend_error_message, latency_seconds=result.duration_seconds))
        if not result.backend_success or not result.response_text.strip():
            raise RuntimeError(f"profile generation failed: {row['profile_request_id']} {result.backend_error_message}")
        if sent and sent % 25 == 0:
            print(f"FIGURE6_PROFILE_PROGRESS new_profile_calls={sent} manifest_row={index}/{len(manifest)}", flush=True)
    return sent


def profile_status(root: Path, manifest: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for row in manifest.to_dict("records"):
        destination = project_path(root, row["output_destination"])
        payload: dict[str, Any] = {}
        if destination.exists():
            payload = json.loads(destination.read_text(encoding="utf-8"))
        text = profile_text_from_payload(payload) if payload else ""
        observed_hash = sha256_text(text) if text else ""
        expected_hash = str(row.get("profile_hash", ""))
        hash_ok = (not expected_hash) or expected_hash == observed_hash
        rows.append(
            {
                "dataset": DATASET,
                "user_id": str(row["user_id"]),
                "history_length": int(row["history_length"]),
                "profile_generator": PROFILE_GENERATOR,
                "profile_request_id": str(row["profile_request_id"]),
                "profile_reuse_class": str(row["profile_reuse_class"]),
                "planned": 1,
                "terminal": 1 if payload else 0,
                "profile_present": 1 if text else 0,
                "new_profile_call_required": 1 if str(row["profile_reuse_class"]) == PROFILE_NEW else 0,
                "reused_profile": 1 if str(row["profile_reuse_class"]) == PROFILE_REUSE else 0,
                "profile_hash": observed_hash,
                "profile_hash_matches_manifest": bool_text(hash_ok),
                "profile_char_count": len(text),
                "execution_status": str(payload.get("execution_status", "not_executed")) if payload else "not_executed",
                "backend_failure": 1 if str(payload.get("execution_status", "")) == "BACKEND_FAILED" else 0,
                "output_destination": str(row["output_destination"]),
            }
        )
    return pd.DataFrame(rows)


def require_profiles_complete(status: pd.DataFrame, expected: int) -> None:
    if int(status["terminal"].sum()) != expected or int(status["profile_present"].sum()) != expected:
        raise RuntimeError("profile completion gate failed")
    if int(status["backend_failure"].sum()) != 0:
        raise RuntimeError("profile backend failure gate failed")
    if not status["profile_hash_matches_manifest"].eq("true").all():
        raise RuntimeError("profile hash mismatch gate failed")


def materialize_profile_hashes(manifest: pd.DataFrame, status: pd.DataFrame) -> pd.DataFrame:
    observed = status.set_index("profile_request_id").to_dict("index")
    rows: list[dict[str, Any]] = []
    for row in manifest.to_dict("records"):
        current = observed[str(row["profile_request_id"])]
        updated = dict(row)
        updated["profile_hash"] = str(current["profile_hash"])
        updated["profile_char_count"] = int(current["profile_char_count"])
        updated["profile_dependency_status"] = "PRESENT"
        rows.append(updated)
    return pd.DataFrame(rows)


def completed_profiles(root: Path, manifest: pd.DataFrame) -> dict[tuple[int, str], dict[str, str]]:
    profiles: dict[tuple[int, str], dict[str, str]] = {}
    for row in manifest.to_dict("records"):
        destination = project_path(root, row["output_destination"])
        if not destination.exists():
            continue
        payload = json.loads(destination.read_text(encoding="utf-8"))
        text = profile_text_from_payload(payload)
        if text:
            profiles[(int(row["history_length"]), str(row["user_id"]))] = {
                "profile_request_id": str(row["profile_request_id"]),
                "profile_text": text,
                "profile_hash": sha256_text(text),
                "profile_file": str(row["output_destination"]),
            }
    return profiles


def render_ranking_prompt(condition: str, context: Mapping[str, Any], profile_text: str) -> str:
    return corrected.render_corrected_prompt(
        condition=condition,
        history_context=str(context["history_context"]),
        profile_text=profile_text,
        candidate_titles=[str(value) for value in context["candidate_item_titles"]],
        expected_count=10,
        candidate_count=20,
    )


def build_ranking_manifest(root: Path, config: Mapping[str, Any], preflight: pd.DataFrame, contexts: Mapping[tuple[int, str], Mapping[str, Any]], profile_manifest: pd.DataFrame, profiles: Mapping[tuple[int, str], Mapping[str, str]], primary_material: Mapping[str, Any]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    sequence = 1
    max_tokens = int(config["runtime"].get("max_new_tokens_ranking", 256))
    profile_by_key = profile_manifest.set_index(["history_length", "user_id"]).to_dict("index")
    for history_length in [int(value) for value in config["scope"]["history_lengths"]]:
        for user_id in primary_material["users"]:
            context = contexts[(history_length, user_id)]
            profile = profiles[(history_length, user_id)]
            profile_row = profile_by_key[(history_length, user_id)]
            for condition in CONDITIONS:
                profile_generator_name = "none" if condition == "history_only" else PROFILE_GENERATOR
                exact_reuse = history_length == 10
                source_row = primary_material["rank_by_key"].get((user_id, condition), {}) if exact_reuse else {}
                if exact_reuse:
                    prompt_render = str(source_row["prompt_render"])
                    prompt_hash = str(source_row["prompt_hash"])
                    history_context_hash = str(source_row["history_context_hash"])
                    output_source = str(source_row["output_destination"])
                    source_request_id = str(source_row["request_id"])
                else:
                    profile_text = "" if condition == "history_only" else profile["profile_text"]
                    prompt_render = render_ranking_prompt(condition, context, profile_text)
                    prompt_hash = sha256_text(prompt_render)
                    history_context_hash = str(context["history_context_hash"])
                    output_source = ""
                    source_request_id = ""
                prompt_hidden = not corrected.prompt_discloses_positive(prompt_render, str(context["positive_item_id"]), str(context["positive_candidate_position"]))
                request_id = stable_id("RQ5F6-RANK", DATASET, user_id, history_length, RECOMMENDER, condition, profile_generator_name, str(context["candidate_list_hash"]), prompt_hash)
                output_destination = Path(str(config["outputs"]["ranking_namespace"])) / f"{request_id}.json"
                rows.append(
                    {
                        "request_id": request_id,
                        "sequence": sequence,
                        "phase": PHASE_ID,
                        "dataset": DATASET,
                        "user_id": user_id,
                        "history_length": history_length,
                        "model_name": RECOMMENDER,
                        "recommender_model_name": RECOMMENDER,
                        "model_digest": model_digest(preflight, RECOMMENDER),
                        "profile_generator_name": profile_generator_name,
                        "primary_profile_generator": PROFILE_GENERATOR,
                        "condition": condition,
                        "input_variant": condition,
                        "profile_request_id": "" if condition == "history_only" else str(profile["profile_request_id"]),
                        "profile_hash": "" if condition == "history_only" else str(profile["profile_hash"]),
                        "profile_source_file": "" if condition == "history_only" else str(profile["profile_file"]),
                        "candidate_list_hash": str(context["candidate_list_hash"]),
                        "candidate_item_ids_json": str(context["candidate_item_ids_json"]),
                        "candidate_item_titles_json": str(context["candidate_item_titles_json"]),
                        "candidate_count": 20,
                        "positive_item_id": str(context["positive_item_id"]),
                        "positive_candidate_position": str(context["positive_candidate_position"]),
                        "prompt_template_id": RANKING_PROMPT_TEMPLATE_ID,
                        "parser_contract": RANKING_PARSER_CONTRACT,
                        "expected_output_schema": stable_json({"ranked_candidate_indices": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]}),
                        "expected_output_count": 10,
                        "candidate_index_base": 1,
                        "temperature": 0,
                        "seed": 0,
                        "max_new_tokens": max_tokens,
                        "prompt_render": prompt_render,
                        "prompt_hash": prompt_hash,
                        "positive_label_hidden": bool_text(prompt_hidden),
                        "history_context_hash": history_context_hash,
                        "history_input_provenance": str(context["upstream_rank_member"]),
                        "profile_input_provenance": "" if condition == "history_only" else str(profile_row["history_input_provenance"]),
                        "output_destination": output_destination.as_posix(),
                        "metric_denominator_policy": DENOMINATOR_POLICY,
                        "exact_reuse_source_request_id": source_request_id,
                        "exact_reuse_source_file": output_source,
                        "exact_reuse_source_sha256": sha256_file(project_path(root, output_source)) if output_source else "",
                        "reuse_class": RANKING_REUSE if exact_reuse else RANKING_NEW,
                        "new_inference_required": bool_text(not exact_reuse),
                        "r5d_reuse_decision": "DESCRIPTIVE_ONLY_ZERO_EXACT_REUSE",
                    }
                )
                rows[-1]["logical_key_sha256"] = sha256_text(
                    stable_json(
                        {
                            "dataset": DATASET,
                            "user_id": user_id,
                            "history_length": history_length,
                            "recommender": RECOMMENDER,
                            "condition": condition,
                            "profile_generator": profile_generator_name,
                            "candidate_list_hash": str(context["candidate_list_hash"]),
                            "positive_item_id": str(context["positive_item_id"]),
                            "prompt_hash": prompt_hash,
                        }
                    )
                )
                sequence += 1
    frame = pd.DataFrame(rows)
    expected = int(config["frozen_accounting"]["logical_rankings"])
    if len(frame) != expected or frame["request_id"].nunique() != expected or frame["logical_key_sha256"].nunique() != expected:
        raise RuntimeError("ranking manifest accounting/id uniqueness failed")
    if not frame["positive_label_hidden"].eq("true").all():
        bad = frame.loc[frame["positive_label_hidden"].ne("true"), "request_id"].head().tolist()
        raise RuntimeError(f"positive label disclosure detected: {bad}")
    return frame


def ranking_raw_capture_path(root: Path, config: Mapping[str, Any], request_id: str) -> Path:
    return output_path(root, config, "raw_namespace") / "ranking_raw_captures" / f"{request_id}.json"


def backend_failed_parse(row: Mapping[str, Any], error: str) -> dict[str, Any]:
    return {
        "parse_valid": False,
        "parse_status": "backend_failed",
        "parse_error": error,
        "validity_class": "BACKEND_FAILED",
        "ranked_candidate_indices": [],
        "ranked_item_ids": [],
        "duplicate_count": 0,
        "unknown_item_count": 0,
        "output_length": 0,
        "expected_output_count": int(row["expected_output_count"]),
        "positive_rank": 0,
        "hr_at_5": 0.0,
        "ndcg_at_5": 0.0,
        "metric_ready": False,
    }


def build_ranking_payload(row: Mapping[str, Any], *, execution_status: str, response_text: str, raw_response: Mapping[str, Any], error: str, latency_seconds: float, reuse_class: str, reuse_source_payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
    parse_record = corrected.parse_corrected_response(row, response_text) if execution_status == "SUCCEEDED" else backend_failed_parse(row, error)
    return {
        "phase": PHASE_ID,
        "task": "ranking",
        "request_id": str(row["request_id"]),
        "dataset": DATASET,
        "user_id": str(row["user_id"]),
        "history_length": int(row["history_length"]),
        "model_name": RECOMMENDER,
        "profile_generator_name": str(row["profile_generator_name"]),
        "primary_profile_generator": PROFILE_GENERATOR,
        "condition": str(row["condition"]),
        "execution_status": execution_status,
        "backend_complete": bool_text(execution_status == "SUCCEEDED"),
        "response_text": response_text,
        "raw_response": response_text,
        "raw_response_hash": sha256_text(response_text),
        "parse": parse_record,
        "candidate_item_ids": json_list(row["candidate_item_ids_json"]),
        "candidate_item_titles": json_list(row["candidate_item_titles_json"]),
        "candidate_list_hash": str(row["candidate_list_hash"]),
        "positive_item_id": str(row["positive_item_id"]),
        "positive_candidate_position": str(row["positive_candidate_position"]),
        "profile_request_id": str(row.get("profile_request_id", "")),
        "profile_hash": str(row.get("profile_hash", "")),
        "prompt_template_id": RANKING_PROMPT_TEMPLATE_ID,
        "parser_contract": RANKING_PARSER_CONTRACT,
        "prompt_hash": str(row["prompt_hash"]),
        "prompt_render": str(row["prompt_render"]),
        "metric_denominator_policy": DENOMINATOR_POLICY,
        "reuse_class": reuse_class,
        "reuse_source_file": str(row.get("exact_reuse_source_file", "")),
        "reuse_source_request_id": str(row.get("exact_reuse_source_request_id", "")),
        "reuse_source_sha256": str(row.get("exact_reuse_source_sha256", "")),
        "source_reuse_payload_status": "AVAILABLE" if reuse_source_payload is not None else "",
        "runtime_backend": "local_ollama",
        "runtime_model_id": str(raw_response.get("model", RECOMMENDER)),
        "ollama_done_reason": str(raw_response.get("done_reason", "")),
        "ollama_raw_response": dict(raw_response),
        "error": error,
        "latency_seconds": latency_seconds,
        "raw_output_recorded_before_parse": True,
    }


def payload_from_reused_ranking(root: Path, row: Mapping[str, Any]) -> dict[str, Any]:
    source_path = project_path(root, str(row["exact_reuse_source_file"]))
    source_payload = json.loads(source_path.read_text(encoding="utf-8"))
    response_text = raw_response_text(source_payload)
    raw_response = source_payload.get("ollama_raw_response", {})
    if not isinstance(raw_response, Mapping):
        raw_response = {}
    return build_ranking_payload(
        row,
        execution_status=str(source_payload.get("execution_status", "SUCCEEDED")),
        response_text=response_text,
        raw_response=raw_response,
        error=str(source_payload.get("error", "")),
        latency_seconds=0.0,
        reuse_class=RANKING_REUSE,
        reuse_source_payload=source_payload,
    )


def execute_rankings(root: Path, config: Mapping[str, Any], manifest: pd.DataFrame, *, execute: bool) -> int:
    if not execute:
        return 0
    runtime = config["runtime"]
    ordered = manifest.copy()
    ordered["_history_order"] = ordered["history_length"].astype(int)
    ordered["_condition_order"] = ordered["condition"].map({condition: index for index, condition in enumerate(CONDITIONS)})
    ordered["_user_order"] = ordered["user_id"].map(lambda value: corrected.sorted_users([value])[0])
    ordered = ordered.sort_values(["_history_order", "_condition_order", "_user_order"], kind="mergesort")
    sent = 0
    for index, row in enumerate(ordered.to_dict("records"), start=1):
        destination = project_path(root, row["output_destination"])
        if destination.exists():
            continue
        if str(row["reuse_class"]) == RANKING_REUSE:
            write_json(destination, payload_from_reused_ranking(root, row))
            continue
        capture = ranking_raw_capture_path(root, config, str(row["request_id"]))
        if capture.exists():
            result = result_from_raw_capture(capture)
        else:
            payload = {
                "model": RECOMMENDER,
                "prompt": str(row["prompt_render"]),
                "stream": False,
                "format": str(runtime.get("format", "json")),
                "options": {"temperature": float(row["temperature"]), "seed": int(row["seed"]), "num_predict": int(row["max_new_tokens"])},
            }
            result = call_ollama_generate(str(runtime["base_url"]), payload, int(runtime["timeout_seconds"]))
            write_json(
                capture,
                {
                    "phase": PHASE_ID,
                    "task": "ranking",
                    "request_id": str(row["request_id"]),
                    "history_length": int(row["history_length"]),
                    "condition": str(row["condition"]),
                    "backend_success": result.backend_success,
                    "response_text": result.response_text,
                    "raw_backend_response": result.raw_backend_response,
                    "backend_error_type": result.backend_error_type,
                    "backend_error_message": result.backend_error_message,
                    "started_at": result.started_at,
                    "completed_at": result.completed_at,
                    "duration_seconds": result.duration_seconds,
                    "raw_response_hash": sha256_text(result.response_text),
                    "raw_output_recorded_before_parse": True,
                },
            )
            sent += 1
        execution_status = "SUCCEEDED" if result.backend_success else "BACKEND_FAILED"
        write_json(destination, build_ranking_payload(row, execution_status=execution_status, response_text=result.response_text, raw_response=result.raw_backend_response, error=result.backend_error_message, latency_seconds=result.duration_seconds, reuse_class=RANKING_NEW))
        if not result.backend_success:
            raise RuntimeError(f"ranking backend failure: {row['request_id']} {result.backend_error_message}")
        if sent and sent % 100 == 0:
            print(f"FIGURE6_RANKING_PROGRESS new_ranking_calls={sent} ordered_row={index}/{len(ordered)}", flush=True)
    return sent


def ranking_status(root: Path, manifest: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for row in manifest.to_dict("records"):
        destination = project_path(root, row["output_destination"])
        payload: dict[str, Any] = {}
        if destination.exists():
            payload = json.loads(destination.read_text(encoding="utf-8"))
        parse_record = payload.get("parse", {}) if isinstance(payload.get("parse", {}), Mapping) else {}
        parse_status = str(parse_record.get("parse_status", "not_executed"))
        ranked_item_ids = [str(value) for value in parse_record.get("ranked_item_ids", [])] if isinstance(parse_record.get("ranked_item_ids", []), list) else []
        rows.append(
            {
                "request_id": str(row["request_id"]),
                "dataset": DATASET,
                "user_id": str(row["user_id"]),
                "history_length": int(row["history_length"]),
                "recommender": RECOMMENDER,
                "condition": str(row["condition"]),
                "profile_generator": str(row["profile_generator_name"]),
                "planned": 1,
                "completed": 1 if str(payload.get("execution_status", "")) == "SUCCEEDED" else 0,
                "terminal": 1 if payload else 0,
                "strict_valid": 1 if parse_bool(parse_record.get("parse_valid", False)) else 0,
                "invalid_length": 1 if parse_status == "invalid_length" else 0,
                "duplicate_index": 1 if parse_status == "duplicate_indices" else 0,
                "out_of_range_index": 1 if parse_status == "unknown_indices" else 0,
                "parse_failure": 1 if corrected.validity_class_from_status(parse_status) == "PARSE_FAILURE" else 0,
                "backend_failure": 1 if str(payload.get("execution_status", "")) == "BACKEND_FAILED" else 0,
                "backend_incomplete": 1 if str(payload.get("execution_status", "")) == "BACKEND_INCOMPLETE" else 0,
                "reuse_class": str(payload.get("reuse_class", row["reuse_class"])),
                "parse_status": parse_status,
                "validity_class": str(parse_record.get("validity_class", corrected.validity_class_from_status(parse_status))),
                "positive_rank": int(parse_record.get("positive_rank", 0) or 0),
                "hr_at_5": float(parse_record.get("hr_at_5", 0.0) or 0.0),
                "ndcg_at_5": float(parse_record.get("ndcg_at_5", 0.0) or 0.0),
                "output_length": int(parse_record.get("output_length", 0) or 0),
                "duplicate_count": int(parse_record.get("duplicate_count", 0) or 0),
                "unknown_item_count": int(parse_record.get("unknown_item_count", 0) or 0),
                "candidate_list_hash": str(row["candidate_list_hash"]),
                "candidate_item_ids_json": str(row["candidate_item_ids_json"]),
                "top5_item_ids_json": stable_json(ranked_item_ids[:5]),
                "top10_item_ids_json": stable_json(ranked_item_ids[:10]),
                "positive_item_id": str(row["positive_item_id"]),
                "positive_candidate_position": str(row["positive_candidate_position"]),
                "profile_request_id": str(row.get("profile_request_id", "")),
                "profile_hash": str(row.get("profile_hash", "")),
                "result_file_sha256": sha256_file(destination) if destination.exists() else "",
            }
        )
    return pd.DataFrame(rows)


def frequency_dict_hash(counts: Mapping[str, int]) -> str:
    payload = {str(item): int(count) for item, count in sorted(counts.items(), key=lambda pair: str(pair[0]))}
    return sha256_text(stable_json(payload)).lower()


def frozen_candidate_manifest_hash(manifest: pd.DataFrame) -> str:
    h10 = manifest.loc[manifest["history_length"].astype(int).eq(10) & manifest["condition"].astype(str).eq("history_only")].copy()
    h10 = h10.sort_values("user_id", key=lambda col: pd.to_numeric(col, errors="raise"))
    payload = [
        {
            "user_id": str(row["user_id"]),
            "candidate_item_ids": json_list(row["candidate_item_ids_json"]),
            "candidate_list_hash": str(row["candidate_list_hash"]),
            "positive_item_id": str(row["positive_item_id"]),
            "positive_candidate_position": str(row["positive_candidate_position"]),
        }
        for row in h10.to_dict("records")
    ]
    return sha256_text(stable_json(payload)).lower()


def load_popularity(root: Path, config: Mapping[str, Any], manifest: pd.DataFrame) -> dict[str, Any]:
    pop_cfg = config["popularity"]
    sources = config["source_authority"]
    interactions, interactions_path, interactions_scope, interactions_sha = read_source_csv(root, sources["beauty_interactions"])
    catalog, catalog_path, catalog_scope, catalog_sha = read_source_csv(root, sources["beauty_catalog"])
    train = interactions.loc[interactions["split"].astype(str).eq(str(pop_cfg["split"]))].copy()
    counts_series = train[str(pop_cfg["item_key"])].astype(str).value_counts(sort=False)
    counts = {str(item): int(count) for item, count in counts_series.items()}
    threshold = float(np.quantile(np.array(list(counts.values()), dtype=float), float(pop_cfg["quantile"]), method="linear"))
    long_tail = {item for item, count in counts.items() if count < threshold}
    catalog_ids = set(catalog["internal_item_id"].astype(str))
    manifest_ids: set[str] = set()
    positives: set[str] = set(manifest["positive_item_id"].astype(str))
    for value in manifest["candidate_item_ids_json"].astype(str):
        manifest_ids.update(json_list(value))
    manifest_ids.update(positives)
    return {
        "train_counts": counts,
        "train_frequency_dict_sha256": frequency_dict_hash(counts),
        "expected_train_frequency_dict_sha256": str(pop_cfg["expected_train_frequency_dict_sha256"]),
        "expected_h10_mostpop_hit_sum": float(pop_cfg["expected_h10_mostpop_hit_sum"]),
        "expected_h10_mostpop_hr_at_5": float(pop_cfg["expected_h10_mostpop_hr_at_5"]),
        "expected_h10_mostpop_hit_vector_sha256": str(pop_cfg["expected_h10_mostpop_hit_vector_sha256"]),
        "mostpop_classification": str(pop_cfg["mostpop_classification"]),
        "serendipity_classification": str(pop_cfg["serendipity_classification"]),
        "aplt_classification": str(pop_cfg["aplt_classification"]),
        "candidate_semantics": str(pop_cfg["candidate_semantics"]),
        "upstream_paper_exact_source_status": str(pop_cfg["upstream_paper_exact_source_status"]),
        "long_tail_items": long_tail,
        "threshold": threshold,
        "train_rows": int(len(train)),
        "positive_count_items": int(len(counts)),
        "interactions_path": interactions_path,
        "interactions_scope": interactions_scope,
        "interactions_sha256": interactions_sha,
        "catalog_path": catalog_path,
        "catalog_scope": catalog_scope,
        "catalog_sha256": catalog_sha,
        "frozen_h10_candidate_manifest_sha256": frozen_candidate_manifest_hash(manifest),
        "catalog_coverage_count": int(sum(1 for item in manifest_ids if item in catalog_ids)),
        "candidate_positive_unique_ids": int(len(manifest_ids)),
        "candidate_positive_positive_train_count": int(sum(1 for item in manifest_ids if counts.get(item, 0) > 0)),
        "candidate_positive_zero_train_count": int(sum(1 for item in manifest_ids if counts.get(item, 0) <= 0)),
    }



def mostpop_top_ids(candidate_ids: Sequence[str], train_counts: Mapping[str, int]) -> list[str]:
    freqs = np.array([int(train_counts.get(str(item), 0)) for item in candidate_ids])
    order = np.argsort(-freqs)
    return [str(candidate_ids[int(index)]) for index in order[:10]]



def build_per_user_metrics(status: pd.DataFrame, popularity: Mapping[str, Any]) -> pd.DataFrame:
    counts = popularity["train_counts"]
    long_tail = popularity["long_tail_items"]
    rows: list[dict[str, Any]] = []
    for row in status.to_dict("records"):
        candidate_ids = json_list(row["candidate_item_ids_json"])
        top5 = json_list(row["top5_item_ids_json"])
        positive = str(row["positive_item_id"])
        mostpop = mostpop_top_ids(candidate_ids, counts)
        mostpop_hit = 1.0 if positive in mostpop[:5] else 0.0
        aplt = float(len(set(top5).intersection(long_tail)) / 5.0) if top5 else 0.0
        hr = float(row["hr_at_5"])
        ser = float(hr * (1.0 - mostpop_hit))
        rows.append(
            {
                "request_id": str(row["request_id"]),
                "dataset": DATASET,
                "user_id": str(row["user_id"]),
                "history_length": int(row["history_length"]),
                "recommender": RECOMMENDER,
                "condition": str(row["condition"]),
                "profile_generator": str(row["profile_generator"]),
                "planned": 1,
                "terminal": int(row["terminal"]),
                "strict_valid": int(row["strict_valid"]),
                "hit_at_5": hr,
                "ndcg_at_5": float(row["ndcg_at_5"]),
                "aplt_at_5": aplt,
                "serendipity_at_5": ser,
                "mostpop_hit_at_5": mostpop_hit,
                "mostpop_top5_item_ids_json": stable_json(mostpop[:5]),
                "top5_item_ids_json": str(row["top5_item_ids_json"]),
                "positive_item_id": positive,
                "candidate_list_hash": str(row["candidate_list_hash"]),
                "metric_source": "figure6_index_rankings_invalid_zero_upstream_aplt_serendipity",
            }
        )
    return pd.DataFrame(rows)


def build_aggregate_metrics(per_user: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for (history_length, condition), group in per_user.groupby(["history_length", "condition"], sort=True):
        planned = int(group["planned"].sum())
        strict = int(group["strict_valid"].sum())
        rows.append(
            {
                "dataset": DATASET,
                "recommender": RECOMMENDER,
                "profile_generator": PROFILE_GENERATOR,
                "history_length": int(history_length),
                "condition": condition,
                "requests": planned,
                "strict_valid": strict,
                "strict_validity_rate": strict / planned if planned else 0.0,
                "hr_at_5": float(group["hit_at_5"].sum() / planned) if planned else 0.0,
                "ndcg_at_5": float(group["ndcg_at_5"].sum() / planned) if planned else 0.0,
                "aplt_at_5": float(group["aplt_at_5"].sum() / planned) if planned else 0.0,
                "serendipity_at_5": float(group["serendipity_at_5"].sum() / planned) if planned else 0.0,
                "denominator_policy": DENOMINATOR_POLICY,
                "metric_source": "figure6_index_rankings_invalid_zero_upstream_aplt_serendipity",
            }
        )
    return pd.DataFrame(rows)


def build_paired_contributions(per_user: pd.DataFrame) -> pd.DataFrame:
    index = per_user.set_index(["history_length", "condition", "user_id"])
    rows: list[dict[str, Any]] = []
    history_rows = per_user.loc[per_user["condition"].eq("history_only")].copy()
    for base in history_rows.to_dict("records"):
        history_length = int(base["history_length"])
        user_id = str(base["user_id"])
        h = index.loc[(history_length, "history_only", user_id)]
        for comparison, treatment in TREATMENTS:
            t = index.loc[(history_length, treatment, user_id)]
            for metric in METRIC_COLUMNS:
                h_value = float(h[metric if metric != "hr_at_5" else "hit_at_5"] if metric == "hr_at_5" else h[metric])
                t_value = float(t[metric if metric != "hr_at_5" else "hit_at_5"] if metric == "hr_at_5" else t[metric])
                rows.append(
                    {
                        "dataset": DATASET,
                        "recommender": RECOMMENDER,
                        "profile_generator": PROFILE_GENERATOR,
                        "history_length": history_length,
                        "user_id": user_id,
                        "comparison": comparison,
                        "metric": metric,
                        "history_value": h_value,
                        "treatment_value": t_value,
                        "delta": t_value - h_value,
                        "denominator_policy": DENOMINATOR_POLICY,
                    }
                )
    return pd.DataFrame(rows)


def build_matched_deltas(contrib: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for (history_length, comparison, metric), group in contrib.groupby(["history_length", "comparison", "metric"], sort=True):
        rows.append(
            {
                "dataset": DATASET,
                "recommender": RECOMMENDER,
                "profile_generator": PROFILE_GENERATOR,
                "history_length": int(history_length),
                "comparison": comparison,
                "metric": metric,
                "paired_n": int(len(group)),
                "history_mean": float(group["history_value"].mean()),
                "treatment_mean": float(group["treatment_value"].mean()),
                "mean_delta": float(group["delta"].mean()),
                "denominator_policy": DENOMINATOR_POLICY,
                "metric_source": "figure6_per_user_decomposable",
            }
        )
    return pd.DataFrame(rows)


def build_bootstrap(contrib: pd.DataFrame, config: Mapping[str, Any]) -> pd.DataFrame:
    stats = config["statistics"]
    resamples = int(stats["bootstrap_resamples"])
    seed = int(stats["bootstrap_seed"])
    low = float(stats["bootstrap_ci_lower"])
    high = float(stats["bootstrap_ci_upper"])
    rng = np.random.default_rng(seed)
    rows: list[dict[str, Any]] = []
    for (history_length, comparison, metric), group in contrib.groupby(["history_length", "comparison", "metric"], sort=True):
        values = group["delta"].astype(float).to_numpy()
        sample_idx = rng.integers(0, len(values), size=(resamples, len(values)))
        boot = values[sample_idx].mean(axis=1)
        ci_low, ci_high = np.quantile(boot, [low, high], method="linear")
        if ci_low > 0:
            decision = "CI_SUPPORTED_POSITIVE"
        elif ci_high < 0:
            decision = "CI_SUPPORTED_NEGATIVE"
        else:
            decision = "NON_SIGNIFICANT_CI_INCLUDES_ZERO"
        rows.append(
            {
                "dataset": DATASET,
                "recommender": RECOMMENDER,
                "profile_generator": PROFILE_GENERATOR,
                "history_length": int(history_length),
                "comparison": comparison,
                "metric": metric,
                "paired_n": int(len(values)),
                "mean_delta": float(values.mean()),
                "ci_lower": float(ci_low),
                "ci_upper": float(ci_high),
                "bootstrap_resamples": resamples,
                "bootstrap_seed": seed,
                "ci_method": "two_sided_percentile_numpy_linear",
                "decision": decision,
                "p_value": "",
            }
        )
    return pd.DataFrame(rows)


def build_matching_audit(manifest: pd.DataFrame, profile_manifest: pd.DataFrame, context_audit: pd.DataFrame) -> pd.DataFrame:
    profile_hashes = profile_manifest.set_index(["history_length", "user_id"])["profile_hash"].to_dict()
    context_index = context_audit.set_index(["history_length", "user_id"]).to_dict("index")
    rows: list[dict[str, Any]] = []
    for (history_length, user_id), group in manifest.groupby(["history_length", "user_id"], sort=True):
        by_cond = group.set_index("condition").to_dict("index")
        candidate_values = {cond: str(row["candidate_item_ids_json"]) for cond, row in by_cond.items()}
        hash_values = {cond: str(row["candidate_list_hash"]) for cond, row in by_cond.items()}
        positives = {cond: str(row["positive_item_id"]) for cond, row in by_cond.items()}
        positions = {cond: str(row["positive_candidate_position"]) for cond, row in by_cond.items()}
        prompts_hidden = all(str(row["positive_label_hidden"]) == "true" for row in by_cond.values())
        expected_profile_hash = str(profile_hashes[(int(history_length), str(user_id))])
        profile_lineage = all(str(row["profile_hash"]) == expected_profile_hash for cond, row in by_cond.items() if cond in {"profile_only", "profile_plus_history"})
        context = context_index[(int(history_length), str(user_id))]
        passed = (
            set(by_cond) == set(CONDITIONS)
            and len(set(candidate_values.values())) == 1
            and len(set(hash_values.values())) == 1
            and len(set(positives.values())) == 1
            and len(set(positions.values())) == 1
            and prompts_hidden
            and profile_lineage
            and str(context["candidate_membership_order_matches_h10_primary"]) == "true"
            and str(context["candidate_hash_matches_h10_primary"]) == "true"
            and str(context["positive_target_title_matches_h10_primary"]) == "true"
        )
        rows.append(
            {
                "dataset": DATASET,
                "recommender": RECOMMENDER,
                "history_length": int(history_length),
                "user_id": str(user_id),
                "conditions_present": stable_json(sorted(by_cond)),
                "same_candidate_membership_order_across_conditions": bool_text(len(set(candidate_values.values())) == 1),
                "same_candidate_hash_across_conditions": bool_text(len(set(hash_values.values())) == 1),
                "same_positive_item_across_conditions": bool_text(len(set(positives.values())) == 1),
                "same_positive_candidate_position_across_conditions": bool_text(len(set(positions.values())) == 1),
                "candidate_membership_order_matches_h10_primary": str(context["candidate_membership_order_matches_h10_primary"]),
                "candidate_hash_matches_h10_primary": str(context["candidate_hash_matches_h10_primary"]),
                "positive_target_title_matches_h10_primary": str(context["positive_target_title_matches_h10_primary"]),
                "positive_hidden_from_prompt": bool_text(prompts_hidden),
                "profile_user_lineage_exact": bool_text(profile_lineage),
                "profile_hash": expected_profile_hash,
                "matching_status": "PASS" if passed else "FAIL",
            }
        )
    return pd.DataFrame(rows)


def build_h10_exact_reuse_audit(profile_manifest: pd.DataFrame, ranking_manifest: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for row in profile_manifest.loc[profile_manifest["history_length"].astype(int).eq(10)].to_dict("records"):
        rows.append(
            {
                "evidence_type": "profile",
                "history_length": 10,
                "user_id": str(row["user_id"]),
                "condition": "profile_generation",
                "reuse_class": str(row["profile_reuse_class"]),
                "source_request_id": str(row["source_profile_request_id"]),
                "source_file": str(row["source_profile_file"]),
                "source_sha256": str(row["source_profile_sha256"]),
                "output_destination": str(row["output_destination"]),
                "exact_reuse_status": "PASS" if str(row["profile_reuse_class"]) == PROFILE_REUSE and str(row["source_profile_file"]) else "FAIL",
            }
        )
    for row in ranking_manifest.loc[ranking_manifest["history_length"].astype(int).eq(10)].to_dict("records"):
        rows.append(
            {
                "evidence_type": "ranking",
                "history_length": 10,
                "user_id": str(row["user_id"]),
                "condition": str(row["condition"]),
                "reuse_class": str(row["reuse_class"]),
                "source_request_id": str(row["exact_reuse_source_request_id"]),
                "source_file": str(row["exact_reuse_source_file"]),
                "source_sha256": str(row["exact_reuse_source_sha256"]),
                "output_destination": str(row["output_destination"]),
                "exact_reuse_status": "PASS" if str(row["reuse_class"]) == RANKING_REUSE and str(row["exact_reuse_source_file"]) else "FAIL",
            }
        )
    return pd.DataFrame(rows)


def build_h10_reconciliation(root: Path, config: Mapping[str, Any], profile_manifest: pd.DataFrame, status: pd.DataFrame, metrics: pd.DataFrame, primary_material: Mapping[str, Any]) -> pd.DataFrame:
    tolerance = float(config["gates"]["h10_reconciliation_tolerance"])
    rows: list[dict[str, Any]] = []
    primary_profiles = primary_material["profiles"]
    fig_profiles = profile_manifest.loc[profile_manifest["history_length"].astype(int).eq(10)].set_index("user_id").to_dict("index")
    profile_matches = sum(1 for user_id, source in primary_profiles.items() if str(fig_profiles[str(user_id)]["profile_hash"]) == str(source["profile_hash"]))
    rows.append({"check_id": "H10_PROFILE_HASHES", "status": "PASS" if profile_matches == 200 else "FAIL", "expected": 200, "observed": profile_matches, "max_abs_error": 0.0})

    fig_status = status.loc[status["history_length"].astype(int).eq(10)].set_index(["user_id", "condition"]).to_dict("index")
    primary_status = primary_material["status_by_key"]
    exact_rows = 0
    for key, source in primary_status.items():
        current = fig_status.get(key, {})
        same = (
            str(current.get("candidate_item_ids_json", "")) == str(source.get("candidate_item_ids_json", ""))
            and str(current.get("top5_item_ids_json", "")) == str(source.get("top5_item_ids_json", ""))
            and abs(float(current.get("hr_at_5", 0.0)) - float(source.get("hr_at_5", 0.0))) <= tolerance
            and abs(float(current.get("ndcg_at_5", 0.0)) - float(source.get("ndcg_at_5", 0.0))) <= tolerance
        )
        exact_rows += int(same)
    rows.append({"check_id": "H10_RANKING_OUTPUTS_AND_TOP5", "status": "PASS" if exact_rows == 600 else "FAIL", "expected": 600, "observed": exact_rows, "max_abs_error": 0.0})

    primary_metrics = primary_material["metrics"]
    max_error = 0.0
    metric_checks = 0
    for condition in CONDITIONS:
        p = primary_metrics.loc[
            primary_metrics["dataset"].eq(DATASET)
            & primary_metrics["recommender"].eq(RECOMMENDER)
            & primary_metrics["condition"].eq(condition)
        ]
        f = metrics.loc[metrics["history_length"].astype(int).eq(10) & metrics["condition"].eq(condition)]
        if len(p) != 1 or len(f) != 1:
            max_error = float("inf")
            continue
        for metric in ("hr_at_5", "ndcg_at_5"):
            metric_checks += 1
            max_error = max(max_error, abs(float(p.iloc[0][metric]) - float(f.iloc[0][metric])))
    rows.append({"check_id": "H10_AGGREGATE_HR_NDCG", "status": "PASS" if metric_checks == 6 and max_error <= tolerance else "FAIL", "expected": "max_error<=1e-12 over 6 aggregates", "observed": metric_checks, "max_abs_error": max_error})
    return pd.DataFrame(rows)


def build_aplt_validation(config: Mapping[str, Any], manifest: pd.DataFrame, popularity: Mapping[str, Any]) -> pd.DataFrame:
    expected_train_rows = int(config["popularity"]["expected_train_rows"])
    expected_items = int(config["popularity"]["expected_positive_count_items"])
    expected_threshold = float(config["popularity"]["expected_threshold"])
    coverage_ok = int(popularity["catalog_coverage_count"]) == int(popularity["candidate_positive_unique_ids"])
    rows = [
        {
            "check_id": "APLT_SOURCE_TRAIN_ROWS",
            "status": "PASS" if int(popularity["train_rows"]) == expected_train_rows else "FAIL",
            "expected": expected_train_rows,
            "observed": int(popularity["train_rows"]),
            "provenance": str(popularity["interactions_path"]),
        },
        {
            "check_id": "APLT_SOURCE_POSITIVE_COUNT_ITEMS",
            "status": "PASS" if int(popularity["positive_count_items"]) == expected_items else "FAIL",
            "expected": expected_items,
            "observed": int(popularity["positive_count_items"]),
            "provenance": str(popularity["interactions_sha256"]),
        },
        {
            "check_id": "APLT_LONG_TAIL_THRESHOLD",
            "status": "PASS" if abs(float(popularity["threshold"]) - expected_threshold) <= 1e-12 else "FAIL",
            "expected": expected_threshold,
            "observed": float(popularity["threshold"]),
            "provenance": "np.quantile(train_freq_value, 0.8, method=linear)",
        },
        {
            "check_id": "APLT_ITEM_MAPPING_COVERAGE",
            "status": "PASS" if coverage_ok else "FAIL",
            "expected": int(popularity["candidate_positive_unique_ids"]),
            "observed": int(popularity["catalog_coverage_count"]),
            "provenance": str(popularity["catalog_path"]),
        },
        {
            "check_id": "APLT_NO_TITLE_OR_FUZZY_MAPPING",
            "status": "PASS",
            "expected": "internal_item_id only",
            "observed": "internal_item_id only",
            "provenance": "upstream calACLT semantics",
        },
    ]
    return pd.DataFrame(rows)



def hit_vector_hash(values: Iterable[Any]) -> str:
    return sha256_text(stable_json([int(float(value)) for value in values])).lower()


def build_serendipity_validation(per_user: pd.DataFrame, popularity: Mapping[str, Any]) -> pd.DataFrame:
    h10_unique = per_user.loc[
        per_user["history_length"].astype(int).eq(10)
    ].drop_duplicates("user_id").sort_values("user_id", key=lambda col: pd.to_numeric(col, errors="raise"))
    hit_sum = float(h10_unique["mostpop_hit_at_5"].sum())
    hit_hash = hit_vector_hash(h10_unique["mostpop_hit_at_5"].tolist())
    invariant = per_user.groupby("user_id")["mostpop_hit_at_5"].nunique().max() == 1
    rows = [
        {
            "check_id": "MOSTPOP_H10_HIT_SUM_LOCAL_ADAPTED",
            "status": "PASS" if abs(hit_sum - float(popularity["expected_h10_mostpop_hit_sum"])) <= 1e-12 else "FAIL",
            "expected": float(popularity["expected_h10_mostpop_hit_sum"]),
            "observed": hit_sum,
            "provenance": f"SOURCE_B_LOCAL + {popularity["candidate_semantics"]}",
        },
        {
            "check_id": "MOSTPOP_H10_HIT_VECTOR_SHA256_LOCAL_ADAPTED",
            "status": "PASS" if hit_hash == str(popularity["expected_h10_mostpop_hit_vector_sha256"]) else "FAIL",
            "expected": str(popularity["expected_h10_mostpop_hit_vector_sha256"]),
            "observed": hit_hash,
            "provenance": "user-sorted H10 canonical B2 MostPop hit vector",
        },
        {
            "check_id": "MOSTPOP_FREQUENCY_DICT_SHA256_LOCAL_ADAPTED",
            "status": "PASS" if str(popularity["train_frequency_dict_sha256"]) == str(popularity["expected_train_frequency_dict_sha256"]) else "FAIL",
            "expected": str(popularity["expected_train_frequency_dict_sha256"]),
            "observed": str(popularity["train_frequency_dict_sha256"]),
            "provenance": "data/reconstructed/plan_c/amazon_beauty/interactions.csv split=train internal_item_id Counter",
        },
        {
            "check_id": "MOSTPOP_FROZEN_CANDIDATE_MANIFEST_SHA256_LOCAL_ADAPTED",
            "status": "PASS" if bool(str(popularity["frozen_h10_candidate_manifest_sha256"])) else "FAIL",
            "expected": "non-empty deterministic H10 candidate/positive manifest hash",
            "observed": str(popularity["frozen_h10_candidate_manifest_sha256"]),
            "provenance": "H10 history_only candidate_item_ids_json + positive_item_id + candidate_list_hash",
        },
        {
            "check_id": "MOSTPOP_VECTOR_INVARIANT_ACROSS_HISTORY_LENGTHS",
            "status": "PASS" if invariant else "FAIL",
            "expected": "one value per user",
            "observed": bool_text(bool(invariant)),
            "provenance": "candidate universe/order invariant across H for local Figure6 slice",
        },
        {
            "check_id": "SERENDIPITY_PER_USER_DECOMPOSABLE_LOCAL_ADAPTED",
            "status": "PASS",
            "expected": "LLM hit@5 * (1 - local adapted MostPop hit@5)",
            "observed": "per-user contributions materialized",
            "provenance": f"paper-aligned formula with {popularity["serendipity_classification"]} classification",
        },
    ]
    return pd.DataFrame(rows)



def build_figure_data(metrics: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for row in metrics.to_dict("records"):
        for metric in METRIC_COLUMNS:
            rows.append(
                {
                    "dataset": DATASET,
                    "recommender": RECOMMENDER,
                    "profile_generator": PROFILE_GENERATOR,
                    "history_length": int(row["history_length"]),
                    "condition": str(row["condition"]),
                    "condition_label": CONDITION_LABELS[str(row["condition"])],
                    "metric": metric,
                    "value": float(row[metric]),
                }
            )
    return pd.DataFrame(rows)


def generate_figure(root: Path, config: Mapping[str, Any], figure_data: pd.DataFrame) -> list[str]:
    metric_labels = {
        "hr_at_5": "HR@5",
        "ndcg_at_5": "NDCG@5",
        "aplt_at_5": "APLT@5",
        "serendipity_at_5": "Serendipity@5",
    }
    fig, axes = plt.subplots(2, 2, figsize=(10, 7), sharex=True)
    axes_flat = axes.ravel()
    history_lengths = sorted(figure_data["history_length"].astype(int).unique())
    for axis, metric in zip(axes_flat, METRIC_COLUMNS):
        subset = figure_data.loc[figure_data["metric"].eq(metric)].copy()
        for condition in CONDITIONS:
            line = subset.loc[subset["condition"].eq(condition)].sort_values("history_length")
            axis.plot(line["history_length"].astype(int), line["value"].astype(float), marker="o", label=CONDITION_LABELS[condition])
        axis.set_title(metric_labels[metric])
        axis.set_xticks(history_lengths)
        axis.grid(True, alpha=0.25)
    for axis in axes_flat[2:]:
        axis.set_xlabel("History length")
    axes_flat[0].legend(loc="best", frameon=False)
    fig.suptitle("RQ5 Figure 6 History-Length Slice: Beauty / Qwen2")
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    paths = [output_path(root, config, key) for key in ("figure_png", "figure_pdf", "figure_svg")]
    for path in paths:
        path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(path, dpi=200 if path.suffix == ".png" else None)
    plt.close(fig)
    return [path.as_posix() for path in paths]


def build_execution_accounting(config: Mapping[str, Any], profile_manifest: pd.DataFrame, profile_status_frame: pd.DataFrame, ranking_manifest: pd.DataFrame, status: pd.DataFrame, profile_calls_now: int, ranking_calls_now: int) -> pd.DataFrame:
    frozen = config["frozen_accounting"]
    rows = [
        ("profiles_target", frozen["target_profiles"], len(profile_manifest)),
        ("profiles_reused_h10", frozen["exact_reused_profiles"], int(profile_manifest["profile_reuse_class"].eq(PROFILE_REUSE).sum())),
        ("profiles_new_required", frozen["new_profile_calls"], int(profile_manifest["profile_reuse_class"].eq(PROFILE_NEW).sum())),
        ("profiles_terminal", frozen["target_profiles"], int(profile_status_frame["terminal"].sum())),
        ("profiles_present", frozen["target_profiles"], int(profile_status_frame["profile_present"].sum())),
        ("profile_calls_executed_this_invocation", frozen["new_profile_calls"], profile_calls_now),
        ("rankings_logical", frozen["logical_rankings"], len(ranking_manifest)),
        ("rankings_reused_h10", frozen["exact_reused_rankings"], int(ranking_manifest["reuse_class"].eq(RANKING_REUSE).sum())),
        ("rankings_new_required", frozen["new_ranking_calls"], int(ranking_manifest["reuse_class"].eq(RANKING_NEW).sum())),
        ("rankings_terminal", frozen["logical_rankings"], int(status["terminal"].sum())),
        ("rankings_strict_valid", ">=4704", int(status["strict_valid"].sum())),
        ("ranking_calls_executed_this_invocation", frozen["new_ranking_calls"], ranking_calls_now),
    ]
    return pd.DataFrame([{"item": item, "expected": expected, "observed": observed, "status": "PASS" if str(expected) == str(observed) or str(expected).startswith(">=") else "FAIL"} for item, expected, observed in rows])


def protected_dirty_paths(root: Path) -> list[str]:
    completed = subprocess.run(["git", "diff", "--name-only", "--", *PROTECTED_PATHS], cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if completed.returncode != 0:
        return ["GIT_DIFF_FAILED:" + completed.stderr.strip()]
    return [line.strip().replace("\\", "/") for line in completed.stdout.splitlines() if line.strip()]


def validation_row(check_id: str, passed: bool, expected: Any, observed: Any) -> dict[str, str]:
    return {"check_id": check_id, "status": "PASS" if passed else "FAIL", "expected": str(expected), "observed": str(observed)}


def build_validation(config: Mapping[str, Any], preflight: pd.DataFrame, profile_manifest: pd.DataFrame, profile_status_frame: pd.DataFrame, ranking_manifest: pd.DataFrame, status: pd.DataFrame, matching: pd.DataFrame, h10_reuse: pd.DataFrame, h10_reconciliation: pd.DataFrame, deltas: pd.DataFrame, bootstrap: pd.DataFrame, aplt_validation: pd.DataFrame, ser_validation: pd.DataFrame, figure_paths: Sequence[str], protected_paths: Sequence[str]) -> pd.DataFrame:
    frozen = config["frozen_accounting"]
    overall_rate = float(status["strict_valid"].sum() / status["planned"].sum()) if not status.empty else 0.0
    by_hc = status.groupby(["history_length", "condition"], as_index=False)[["planned", "strict_valid"]].sum()
    by_hc["rate"] = by_hc["strict_valid"] / by_hc["planned"]
    rows = [
        validation_row("BACKEND-PREFLIGHT", bool(not preflight.empty and preflight["status"].eq("PASS").all()), "qwen2 PASS", preflight[["model", "status"]].to_dict("records") if not preflight.empty else []),
        validation_row("PROFILE-COUNT", len(profile_manifest) == int(frozen["target_profiles"]), frozen["target_profiles"], len(profile_manifest)),
        validation_row("PROFILE-REUSE-H10", int(profile_manifest["profile_reuse_class"].eq(PROFILE_REUSE).sum()) == int(frozen["exact_reused_profiles"]), frozen["exact_reused_profiles"], int(profile_manifest["profile_reuse_class"].eq(PROFILE_REUSE).sum())),
        validation_row("PROFILE-NEW-COUNT", int(profile_manifest["profile_reuse_class"].eq(PROFILE_NEW).sum()) == int(frozen["new_profile_calls"]), frozen["new_profile_calls"], int(profile_manifest["profile_reuse_class"].eq(PROFILE_NEW).sum())),
        validation_row("PROFILE-COMPLETION", int(profile_status_frame["profile_present"].sum()) == int(frozen["target_profiles"]), frozen["target_profiles"], int(profile_status_frame["profile_present"].sum())),
        validation_row("RANKING-LOGICAL-COUNT", len(ranking_manifest) == int(frozen["logical_rankings"]), frozen["logical_rankings"], len(ranking_manifest)),
        validation_row("RANKING-REUSE-H10", int(ranking_manifest["reuse_class"].eq(RANKING_REUSE).sum()) == int(frozen["exact_reused_rankings"]), frozen["exact_reused_rankings"], int(ranking_manifest["reuse_class"].eq(RANKING_REUSE).sum())),
        validation_row("RANKING-NEW-COUNT", int(ranking_manifest["reuse_class"].eq(RANKING_NEW).sum()) == int(frozen["new_ranking_calls"]), frozen["new_ranking_calls"], int(ranking_manifest["reuse_class"].eq(RANKING_NEW).sum())),
        validation_row("RANKING-TERMINAL", int(status["terminal"].sum()) == int(frozen["logical_rankings"]), frozen["logical_rankings"], int(status["terminal"].sum())),
        validation_row("BACKEND-FAILURES-ZERO", int(status["backend_failure"].sum()) == 0 and int(profile_status_frame["backend_failure"].sum()) == 0, 0, int(status["backend_failure"].sum()) + int(profile_status_frame["backend_failure"].sum())),
        validation_row("STRICT-VALIDITY-OVERALL", overall_rate >= float(config["gates"]["min_overall_strict_validity_rate"]), f">={config['gates']['min_overall_strict_validity_rate']}", overall_rate),
        validation_row("STRICT-VALIDITY-BY-HISTORY-CONDITION", bool(not by_hc.empty and by_hc["rate"].ge(float(config["gates"]["min_history_condition_strict_validity_rate"])).all()), f">={config['gates']['min_history_condition_strict_validity_rate']}", by_hc.to_dict("records")),
        validation_row("MATCHING-AUDIT", bool(len(matching) == 1600 and matching["matching_status"].eq("PASS").all()), "1600 PASS rows", f"rows={len(matching)} failures={int(matching['matching_status'].ne('PASS').sum()) if not matching.empty else 'NA'}"),
        validation_row("H10-EXACT-REUSE-AUDIT", bool(len(h10_reuse) == 800 and h10_reuse["exact_reuse_status"].eq("PASS").all()), "800 PASS rows", f"rows={len(h10_reuse)} failures={int(h10_reuse['exact_reuse_status'].ne('PASS').sum()) if not h10_reuse.empty else 'NA'}"),
        validation_row("H10-NUMERIC-RECONCILIATION", bool(not h10_reconciliation.empty and h10_reconciliation["status"].eq("PASS").all()), "all PASS", h10_reconciliation.to_dict("records") if not h10_reconciliation.empty else []),
        validation_row("MATCHED-DELTAS", bool(len(deltas) == 64 and deltas["paired_n"].astype(int).eq(200).all()), "64 rows paired_n=200", f"rows={len(deltas)}"),
        validation_row("BOOTSTRAP", bool(len(bootstrap) == 64 and bootstrap["paired_n"].astype(int).eq(200).all() and bootstrap["bootstrap_resamples"].astype(int).eq(10000).all() and bootstrap["bootstrap_seed"].astype(int).eq(20260901).all() and bootstrap["p_value"].astype(str).eq("").all() and set(bootstrap["decision"]).issubset(DECISIONS)), "64 bootstrap rows, seed 20260901, no p-values", f"rows={len(bootstrap)} decisions={bootstrap['decision'].value_counts().to_dict() if not bootstrap.empty else {}}"),
        validation_row("APLT-CONTRACT", bool(not aplt_validation.empty and aplt_validation["status"].eq("PASS").all()), "all PASS", aplt_validation.to_dict("records") if not aplt_validation.empty else []),
        validation_row("SERENDIPITY-CONTRACT", bool(not ser_validation.empty and ser_validation["status"].eq("PASS").all()), "all PASS", ser_validation.to_dict("records") if not ser_validation.empty else []),
        validation_row("FIGURE-GENERATED", all(project_path(Path.cwd(), path).exists() if not Path(path).is_absolute() else Path(path).exists() for path in figure_paths), "png/pdf/svg", list(figure_paths)),
        validation_row("PROTECTED-PATH-CHECK", len(protected_paths) == 0, "no protected tracked diff", list(protected_paths)),
    ]
    return pd.DataFrame(rows)


def frame_to_markdown(frame: pd.DataFrame) -> str:
    if frame.empty:
        return "_empty_"
    text_frame = frame.fillna("").astype(str)
    headers = list(text_frame.columns)
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    for row in text_frame.values.tolist():
        lines.append("| " + " | ".join(str(cell).replace("|", "\\|").replace("\n", " ") for cell in row) + " |")
    return "\n".join(lines)


def render_report(manifest: Mapping[str, Any], validation: pd.DataFrame, metrics: pd.DataFrame) -> str:
    return "\n".join(
        [
            "# RQ5 Figure6 History-Length Slice Full",
            "",
            f"- Phase: `{PHASE_ID}`",
            f"- Validation passed: `{str(manifest['validation_passed']).lower()}`",
            f"- Profile accounting: `{manifest['profile_accounting']}`",
            f"- Ranking accounting: `{manifest['ranking_accounting']}`",
            f"- Bootstrap decisions: `{manifest['bootstrap_decision_counts']}`",
            "- MostPop classification: `LOCAL_ADAPTED_MOSTPOP`",
            "- Serendipity classification: `LOCAL_ADAPTED_MOSTPOP_SERENDIPITY`",
            "- APLT classification: `LOCAL_ADAPTED_ONLY`",
            "- HR@5/NDCG@5 derive directly from matched local protocol outputs.",
            "- APLT and Serendipity are paper-aligned adapted metrics.",
            "- Upstream paper-exact popularity source is not reconstructible locally because `data/beauty/sequential_data.txt` and `data/beauty/negative_samples.txt` are absent.",
            "- MostPop is computed on the local train split and the same frozen shuffled candidate universe/order supplied to the recommender, with the positive located by exact item ID.",
            "",
            "## Metrics",
            "",
            frame_to_markdown(metrics[["history_length", "condition", "requests", "strict_validity_rate", "hr_at_5", "ndcg_at_5", "aplt_at_5", "serendipity_at_5"]]),
            "",
            "## Validation",
            "",
            frame_to_markdown(validation),
            "",
        ]
    )


def build_manifest_payload(config_path: Path, preflight: pd.DataFrame, profile_manifest: pd.DataFrame, profile_status_frame: pd.DataFrame, ranking_manifest: pd.DataFrame, status: pd.DataFrame, metrics: pd.DataFrame, deltas: pd.DataFrame, bootstrap: pd.DataFrame, validation: pd.DataFrame, profile_calls_now: int, ranking_calls_now: int, figure_paths: Sequence[str]) -> dict[str, Any]:
    return {
        "phase": PHASE_ID,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "config_path": config_path.as_posix(),
        "profile_accounting": {
            "target_profiles": int(len(profile_manifest)),
            "reused_h10_profiles": int(profile_manifest["profile_reuse_class"].eq(PROFILE_REUSE).sum()),
            "new_profiles_required": int(profile_manifest["profile_reuse_class"].eq(PROFILE_NEW).sum()),
            "profile_terminal": int(profile_status_frame["terminal"].sum()),
            "profile_present": int(profile_status_frame["profile_present"].sum()),
            "profile_calls_executed_this_invocation": int(profile_calls_now),
        },
        "ranking_accounting": {
            "logical_rankings": int(len(ranking_manifest)),
            "reused_h10_rankings": int(ranking_manifest["reuse_class"].eq(RANKING_REUSE).sum()),
            "new_rankings_required": int(ranking_manifest["reuse_class"].eq(RANKING_NEW).sum()),
            "ranking_terminal": int(status["terminal"].sum()),
            "strict_valid": int(status["strict_valid"].sum()),
            "ranking_calls_executed_this_invocation": int(ranking_calls_now),
        },
        "backend_preflight": preflight.to_dict("records"),
        "metrics": metrics.to_dict("records"),
        "matched_deltas": deltas.to_dict("records"),
        "bootstrap_decision_counts": bootstrap["decision"].value_counts().sort_index().to_dict() if not bootstrap.empty else {},
        "figure_paths": list(figure_paths),
        "validation_passed": bool(not validation.empty and validation["status"].eq("PASS").all()),
        "validation_failures": validation.loc[validation["status"].ne("PASS"), "check_id"].tolist() if not validation.empty else [],
        "mostpop_classification": "LOCAL_ADAPTED_MOSTPOP",
        "serendipity_classification": "LOCAL_ADAPTED_MOSTPOP_SERENDIPITY",
        "aplt_classification": "LOCAL_ADAPTED_ONLY",
    }


def run_figure6(root: Path, config_path: Path, *, execute: bool, allow_api_calls: bool) -> dict[str, Any]:
    config = load_config(config_path)
    preflight = backend_preflight(config)
    write_csv(preflight, output_path(root, config, "backend_preflight"))
    require_preflight(preflight)
    if execute and not allow_api_calls:
        raise RuntimeError("--allow-api-calls is required for Figure6 local Ollama execution")

    primary_material = load_primary_material(root, config)
    contexts, context_audit = build_contexts(root, config, primary_material)
    profile_manifest = build_profile_manifest(root, config, preflight, contexts, primary_material)
    write_csv(profile_manifest, output_path(root, config, "profile_manifest"))
    profile_calls_now = execute_profiles(root, config, profile_manifest, execute=execute)
    profile_status_frame = profile_status(root, profile_manifest)
    require_profiles_complete(profile_status_frame, int(config["frozen_accounting"]["target_profiles"]))
    profile_manifest = materialize_profile_hashes(profile_manifest, profile_status_frame)
    write_csv(profile_manifest, output_path(root, config, "profile_manifest"))
    write_csv(profile_status_frame, output_path(root, config, "profile_execution_status"))
    profile_by_key = completed_profiles(root, profile_manifest)

    ranking_manifest = build_ranking_manifest(root, config, preflight, contexts, profile_manifest, profile_by_key, primary_material)
    write_csv(ranking_manifest, output_path(root, config, "ranking_manifest"))
    ranking_calls_now = execute_rankings(root, config, ranking_manifest, execute=execute)
    status = ranking_status(root, ranking_manifest)
    write_csv(status, output_path(root, config, "ranking_execution_status"))

    popularity = load_popularity(root, config, ranking_manifest)
    per_user = build_per_user_metrics(status, popularity)
    metrics = build_aggregate_metrics(per_user)
    contrib = build_paired_contributions(per_user)
    deltas = build_matched_deltas(contrib)
    bootstrap = build_bootstrap(contrib, config)
    matching = build_matching_audit(ranking_manifest, profile_manifest, context_audit)
    h10_reuse = build_h10_exact_reuse_audit(profile_manifest, ranking_manifest)
    h10_reconciliation = build_h10_reconciliation(root, config, profile_manifest, status, metrics, primary_material)
    aplt_validation = build_aplt_validation(config, ranking_manifest, popularity)
    ser_validation = build_serendipity_validation(per_user, popularity)
    figure_data = build_figure_data(metrics)
    figure_paths = generate_figure(root, config, figure_data)
    protected_paths = protected_dirty_paths(root)
    execution_accounting = build_execution_accounting(config, profile_manifest, profile_status_frame, ranking_manifest, status, profile_calls_now, ranking_calls_now)
    validation = build_validation(config, preflight, profile_manifest, profile_status_frame, ranking_manifest, status, matching, h10_reuse, h10_reconciliation, deltas, bootstrap, aplt_validation, ser_validation, figure_paths, protected_paths)

    write_csv(execution_accounting, output_path(root, config, "execution_accounting"))
    write_csv(matching, output_path(root, config, "matching_audit"))
    write_csv(h10_reuse, output_path(root, config, "h10_exact_reuse_audit"))
    write_csv(h10_reconciliation, output_path(root, config, "h10_reconciliation"))
    write_csv(per_user, output_path(root, config, "per_user_metrics"))
    write_csv(metrics, output_path(root, config, "metrics"))
    write_csv(deltas, output_path(root, config, "matched_deltas"))
    write_csv(bootstrap, output_path(root, config, "bootstrap_results"))
    write_csv(aplt_validation, output_path(root, config, "aplt_provenance"))
    write_csv(ser_validation, output_path(root, config, "mostpop_serendipity_provenance"))
    write_csv(figure_data, output_path(root, config, "figure_data"))
    write_csv(validation, output_path(root, config, "validation"))

    manifest = build_manifest_payload(config_path, preflight, profile_manifest, profile_status_frame, ranking_manifest, status, metrics, deltas, bootstrap, validation, profile_calls_now, ranking_calls_now, figure_paths)
    write_json(output_path(root, config, "manifest"), manifest)
    output_path(root, config, "report").parent.mkdir(parents=True, exist_ok=True)
    output_path(root, config, "report").write_text(render_report(manifest, validation, metrics), encoding="utf-8")
    return {
        "config": config,
        "preflight": preflight,
        "profile_manifest": profile_manifest,
        "profile_status": profile_status_frame,
        "ranking_manifest": ranking_manifest,
        "status": status,
        "per_user": per_user,
        "metrics": metrics,
        "deltas": deltas,
        "bootstrap": bootstrap,
        "matching": matching,
        "h10_reuse": h10_reuse,
        "h10_reconciliation": h10_reconciliation,
        "aplt_validation": aplt_validation,
        "serendipity_validation": ser_validation,
        "validation": validation,
        "manifest": manifest,
    }


def print_summary(result: Mapping[str, Any]) -> None:
    manifest = result["manifest"]
    validation = result["validation"]
    print(f"FINAL_VERDICT={'PASS' if manifest['validation_passed'] else 'FAIL'}")
    print(f"PROFILE_ACCOUNTING={manifest['profile_accounting']}")
    print(f"RANKING_ACCOUNTING={manifest['ranking_accounting']}")
    print(f"STRICT_VALIDITY={manifest['ranking_accounting']['strict_valid']}/{manifest['ranking_accounting']['logical_rankings']}")
    print(f"BOOTSTRAP_DECISIONS={manifest['bootstrap_decision_counts']}")
    print(f"VALIDATION_FAILURES={validation.loc[validation['status'].ne('PASS'), 'check_id'].tolist() if not validation.empty else []}")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG))
    parser.add_argument("--project-root", default=".")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--allow-api-calls", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    root = Path(args.project_root).resolve()
    config_path = project_path(root, args.config)
    try:
        result = run_figure6(root, config_path, execute=bool(args.execute), allow_api_calls=bool(args.allow_api_calls))
    except Exception as exc:
        print(f"FIGURE6_HISTORY_LENGTH_SLICE_FULL_ERROR={type(exc).__name__}: {exc}")
        return 2
    print_summary(result)
    return 0 if result["manifest"]["validation_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
