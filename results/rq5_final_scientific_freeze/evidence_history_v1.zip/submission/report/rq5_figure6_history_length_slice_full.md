# RQ5 Figure6 History-Length Slice Full

- Phase: `FIGURE6_HISTORY_LENGTH_SLICE_FULL`
- Validation passed: `true`
- Profile accounting: `{'target_profiles': 1600, 'reused_h10_profiles': 200, 'new_profiles_required': 1400, 'profile_terminal': 1600, 'profile_present': 1600, 'profile_calls_executed_this_invocation': 1400}`
- Ranking accounting: `{'logical_rankings': 4800, 'reused_h10_rankings': 600, 'new_rankings_required': 4200, 'ranking_terminal': 4800, 'strict_valid': 4794, 'ranking_calls_executed_this_invocation': 4200}`
- Bootstrap decisions: `{'CI_SUPPORTED_NEGATIVE': 1, 'NON_SIGNIFICANT_CI_INCLUDES_ZERO': 63}`
- MostPop classification: `LOCAL_ADAPTED_MOSTPOP`
- Serendipity classification: `LOCAL_ADAPTED_MOSTPOP_SERENDIPITY`
- APLT classification: `LOCAL_ADAPTED_ONLY`
- HR@5/NDCG@5 derive directly from matched local protocol outputs.
- APLT and Serendipity are paper-aligned adapted metrics.
- Upstream paper-exact popularity source is not reconstructible locally because `data/beauty/sequential_data.txt` and `data/beauty/negative_samples.txt` are absent.
- MostPop is computed on the local train split and the same frozen shuffled candidate universe/order supplied to the recommender, with the positive located by exact item ID.

## Metrics

| history_length | condition | requests | strict_validity_rate | hr_at_5 | ndcg_at_5 | aplt_at_5 | serendipity_at_5 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | history_only | 200 | 1.0 | 0.285 | 0.1804591436385652 | 0.061 | 0.24 |
| 1 | profile_only | 200 | 0.99 | 0.295 | 0.195933259303637 | 0.062 | 0.24 |
| 1 | profile_plus_history | 200 | 0.995 | 0.31 | 0.1966471386081252 | 0.062 | 0.25 |
| 2 | history_only | 200 | 1.0 | 0.32 | 0.203937057236108 | 0.0579999999999999 | 0.26 |
| 2 | profile_only | 200 | 0.995 | 0.295 | 0.1916292012176285 | 0.065 | 0.245 |
| 2 | profile_plus_history | 200 | 1.0 | 0.33 | 0.2054591436385651 | 0.061 | 0.27 |
| 3 | history_only | 200 | 1.0 | 0.3 | 0.1941498461028507 | 0.063 | 0.245 |
| 3 | profile_only | 200 | 1.0 | 0.355 | 0.2153999097262442 | 0.063 | 0.295 |
| 3 | profile_plus_history | 200 | 0.995 | 0.32 | 0.1870647278556015 | 0.064 | 0.27 |
| 4 | history_only | 200 | 1.0 | 0.29 | 0.1955893495887295 | 0.066 | 0.24 |
| 4 | profile_only | 200 | 1.0 | 0.31 | 0.1911137924064225 | 0.06 | 0.25 |
| 4 | profile_plus_history | 200 | 1.0 | 0.305 | 0.1922155820666779 | 0.066 | 0.265 |
| 5 | history_only | 200 | 1.0 | 0.32 | 0.1987646432418087 | 0.065 | 0.265 |
| 5 | profile_only | 200 | 1.0 | 0.285 | 0.1787503282440384 | 0.068 | 0.235 |
| 5 | profile_plus_history | 200 | 1.0 | 0.3 | 0.185171756965563 | 0.066 | 0.25 |
| 10 | history_only | 200 | 1.0 | 0.33 | 0.2146715814258181 | 0.061 | 0.27 |
| 10 | profile_only | 200 | 1.0 | 0.325 | 0.2058649913848291 | 0.063 | 0.26 |
| 10 | profile_plus_history | 200 | 1.0 | 0.295 | 0.1886226957904321 | 0.062 | 0.245 |
| 15 | history_only | 200 | 1.0 | 0.325 | 0.2116525535975761 | 0.064 | 0.275 |
| 15 | profile_only | 200 | 1.0 | 0.34 | 0.2123278472506554 | 0.066 | 0.28 |
| 15 | profile_plus_history | 200 | 1.0 | 0.34 | 0.203290527576737 | 0.062 | 0.285 |
| 20 | history_only | 200 | 1.0 | 0.31 | 0.1972039711879428 | 0.059 | 0.24 |
| 20 | profile_only | 200 | 0.995 | 0.33 | 0.2073637254073387 | 0.066 | 0.265 |
| 20 | profile_plus_history | 200 | 1.0 | 0.29 | 0.183255433695577 | 0.064 | 0.24 |

## Validation

| check_id | status | expected | observed |
| --- | --- | --- | --- |
| BACKEND-PREFLIGHT | PASS | qwen2 PASS | [{'model': 'qwen2:7b-instruct', 'status': 'PASS'}] |
| PROFILE-COUNT | PASS | 1600 | 1600 |
| PROFILE-REUSE-H10 | PASS | 200 | 200 |
| PROFILE-NEW-COUNT | PASS | 1400 | 1400 |
| PROFILE-COMPLETION | PASS | 1600 | 1600 |
| RANKING-LOGICAL-COUNT | PASS | 4800 | 4800 |
| RANKING-REUSE-H10 | PASS | 600 | 600 |
| RANKING-NEW-COUNT | PASS | 4200 | 4200 |
| RANKING-TERMINAL | PASS | 4800 | 4800 |
| BACKEND-FAILURES-ZERO | PASS | 0 | 0 |
| STRICT-VALIDITY-OVERALL | PASS | >=0.98 | 0.99875 |
| STRICT-VALIDITY-BY-HISTORY-CONDITION | PASS | >=0.95 | [{'history_length': 1, 'condition': 'history_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 1, 'condition': 'profile_only', 'planned': 200, 'strict_valid': 198, 'rate': 0.99}, {'history_length': 1, 'condition': 'profile_plus_history', 'planned': 200, 'strict_valid': 199, 'rate': 0.995}, {'history_length': 2, 'condition': 'history_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 2, 'condition': 'profile_only', 'planned': 200, 'strict_valid': 199, 'rate': 0.995}, {'history_length': 2, 'condition': 'profile_plus_history', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 3, 'condition': 'history_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 3, 'condition': 'profile_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 3, 'condition': 'profile_plus_history', 'planned': 200, 'strict_valid': 199, 'rate': 0.995}, {'history_length': 4, 'condition': 'history_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 4, 'condition': 'profile_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 4, 'condition': 'profile_plus_history', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 5, 'condition': 'history_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 5, 'condition': 'profile_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 5, 'condition': 'profile_plus_history', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 10, 'condition': 'history_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 10, 'condition': 'profile_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 10, 'condition': 'profile_plus_history', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 15, 'condition': 'history_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 15, 'condition': 'profile_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 15, 'condition': 'profile_plus_history', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 20, 'condition': 'history_only', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}, {'history_length': 20, 'condition': 'profile_only', 'planned': 200, 'strict_valid': 199, 'rate': 0.995}, {'history_length': 20, 'condition': 'profile_plus_history', 'planned': 200, 'strict_valid': 200, 'rate': 1.0}] |
| MATCHING-AUDIT | PASS | 1600 PASS rows | rows=1600 failures=0 |
| H10-EXACT-REUSE-AUDIT | PASS | 800 PASS rows | rows=800 failures=0 |
| H10-NUMERIC-RECONCILIATION | PASS | all PASS | [{'check_id': 'H10_PROFILE_HASHES', 'status': 'PASS', 'expected': 200, 'observed': 200, 'max_abs_error': 0.0}, {'check_id': 'H10_RANKING_OUTPUTS_AND_TOP5', 'status': 'PASS', 'expected': 600, 'observed': 600, 'max_abs_error': 0.0}, {'check_id': 'H10_AGGREGATE_HR_NDCG', 'status': 'PASS', 'expected': 'max_error<=1e-12 over 6 aggregates', 'observed': 6, 'max_abs_error': 5.551115123125783e-17}] |
| MATCHED-DELTAS | PASS | 64 rows paired_n=200 | rows=64 |
| BOOTSTRAP | PASS | 64 bootstrap rows, seed 20260901, no p-values | rows=64 decisions={'NON_SIGNIFICANT_CI_INCLUDES_ZERO': 63, 'CI_SUPPORTED_NEGATIVE': 1} |
| APLT-CONTRACT | PASS | all PASS | [{'check_id': 'APLT_SOURCE_TRAIN_ROWS', 'status': 'PASS', 'expected': 176139, 'observed': 176139, 'provenance': 'C:\\Users\\Bartolo\\Desktop\\PROGETTI\\IRP_BeyondUtility_Project\\data\\reconstructed\\plan_c\\amazon_beauty\\interactions.csv'}, {'check_id': 'APLT_SOURCE_POSITIVE_COUNT_ITEMS', 'status': 'PASS', 'expected': 12092, 'observed': 12092, 'provenance': 'd2a7801a024349063cff7c455e872eed6e8eb0132324ed8b710be1ff9a0e9478'}, {'check_id': 'APLT_LONG_TAIL_THRESHOLD', 'status': 'PASS', 'expected': 17.0, 'observed': 17.0, 'provenance': 'np.quantile(train_freq_value, 0.8, method=linear)'}, {'check_id': 'APLT_ITEM_MAPPING_COVERAGE', 'status': 'PASS', 'expected': 3378, 'observed': 3378, 'provenance': 'C:\\Users\\Bartolo\\Desktop\\PROGETTI\\IRP_BeyondUtility_Project\\data\\reconstructed\\plan_c\\amazon_beauty\\catalog.csv'}, {'check_id': 'APLT_NO_TITLE_OR_FUZZY_MAPPING', 'status': 'PASS', 'expected': 'internal_item_id only', 'observed': 'internal_item_id only', 'provenance': 'upstream calACLT semantics'}] |
| SERENDIPITY-CONTRACT | PASS | all PASS | [{'check_id': 'MOSTPOP_H10_HIT_SUM_LOCAL_ADAPTED', 'status': 'PASS', 'expected': 47.0, 'observed': 47.0, 'provenance': 'SOURCE_B_LOCAL + executed_frozen_shuffled_candidate_order_positive_by_exact_item_id'}, {'check_id': 'MOSTPOP_H10_HIT_VECTOR_SHA256_LOCAL_ADAPTED', 'status': 'PASS', 'expected': '13475792797319adac8484b66f0b2283de9897b28a44a28b750386d3acec1216', 'observed': '13475792797319adac8484b66f0b2283de9897b28a44a28b750386d3acec1216', 'provenance': 'user-sorted H10 canonical B2 MostPop hit vector'}, {'check_id': 'MOSTPOP_FREQUENCY_DICT_SHA256_LOCAL_ADAPTED', 'status': 'PASS', 'expected': 'ff17012f6f6e0028d4930cdf95986c8e27978550514202c22451f480e9dbeb27', 'observed': 'ff17012f6f6e0028d4930cdf95986c8e27978550514202c22451f480e9dbeb27', 'provenance': 'data/reconstructed/plan_c/amazon_beauty/interactions.csv split=train internal_item_id Counter'}, {'check_id': 'MOSTPOP_FROZEN_CANDIDATE_MANIFEST_SHA256_LOCAL_ADAPTED', 'status': 'PASS', 'expected': 'non-empty deterministic H10 candidate/positive manifest hash', 'observed': 'f746c4df609867cf6acd459d3f136e2bc1cbae7e67391ea6f2d927fcfbe5c6ca', 'provenance': 'H10 history_only candidate_item_ids_json + positive_item_id + candidate_list_hash'}, {'check_id': 'MOSTPOP_VECTOR_INVARIANT_ACROSS_HISTORY_LENGTHS', 'status': 'PASS', 'expected': 'one value per user', 'observed': 'true', 'provenance': 'candidate universe/order invariant across H for local Figure6 slice'}, {'check_id': 'SERENDIPITY_PER_USER_DECOMPOSABLE_LOCAL_ADAPTED', 'status': 'PASS', 'expected': 'LLM hit@5 * (1 - local adapted MostPop hit@5)', 'observed': 'per-user contributions materialized', 'provenance': 'paper-aligned formula with LOCAL_ADAPTED_MOSTPOP_SERENDIPITY classification'}] |
| FIGURE-GENERATED | PASS | png/pdf/svg | ['C:/Users/Bartolo/Desktop/PROGETTI/IRP_BeyondUtility_Submission_Worktree/results/plots/fig_rq5_history_length_profile_conditions.png', 'C:/Users/Bartolo/Desktop/PROGETTI/IRP_BeyondUtility_Submission_Worktree/results/plots/fig_rq5_history_length_profile_conditions.pdf', 'C:/Users/Bartolo/Desktop/PROGETTI/IRP_BeyondUtility_Submission_Worktree/results/plots/fig_rq5_history_length_profile_conditions.svg'] |
| PROTECTED-PATH-CHECK | PASS | no protected tracked diff | [] |
